from __future__ import annotations

import logging
import sys
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication

from app.app_info import OFFICIAL_ICON_PATH
from app.main_window import MainWindow
from database.database import TimesheetDatabase


def configure_logging() -> None:
    log_dir = Path.home() / "AppData" / "Local" / "PersonalNightShiftWorkingHoursRecord" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(filename=log_dir / "app.log", level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")


def main() -> int:
    configure_logging()
    QApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon(str(OFFICIAL_ICON_PATH)))
    window = MainWindow(TimesheetDatabase())
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
