from pathlib import Path

from app.updater import create_macos_installer_script, create_windows_installer_script


def test_windows_installer_script_replaces_and_relaunches(tmp_path: Path) -> None:
    update = tmp_path / "update.zip"
    install_dir = tmp_path / "install"
    exe = install_dir / "PersonalNightShiftWorkingHoursRecord.exe"
    install_dir.mkdir()
    update.write_text("zip", encoding="utf-8")
    exe.write_text("exe", encoding="utf-8")

    script = create_windows_installer_script(update, install_dir, exe, 12345)
    text = script.read_text(encoding="utf-8")

    assert "Expand-Archive" in text
    assert "robocopy $sourceDir $installDir /MIR" in text
    assert "Start-Process -FilePath $relaunchPath" in text


def test_macos_installer_script_replaces_and_reopens_app(tmp_path: Path) -> None:
    update = tmp_path / "update.zip"
    app = tmp_path / "Personal Night-Shift Working Hours Record.app"
    update.write_text("zip", encoding="utf-8")

    script = create_macos_installer_script(update, app, 12345)
    text = script.read_text(encoding="utf-8")

    assert "/usr/bin/ditto -x -k" in text
    assert 'rm -rf "$app_path"' in text
    assert '/usr/bin/open "$app_path"' in text
