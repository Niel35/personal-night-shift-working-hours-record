from __future__ import annotations

import pytest

from app.updater import UpdateError, fetch_update_info, is_newer_version, platform_download_url


def test_version_compare_handles_semver_lengths() -> None:
    assert is_newer_version("1.1.1", "1.1.0")
    assert is_newer_version("1.2", "1.1.9")
    assert not is_newer_version("1.1.0", "1.1")


def test_update_url_must_be_configured() -> None:
    with pytest.raises(UpdateError):
        fetch_update_info("")


def test_platform_download_url_prefers_current_platform(monkeypatch) -> None:
    monkeypatch.setattr("app.updater.platform_key", lambda: "macos")
    data = {
        "latest_version": "1.1.1",
        "download_url": "https://example.com/windows.zip",
        "downloads": {
            "windows": {"download_url": "https://example.com/windows.zip"},
            "macos": {"download_url": "https://example.com/macos.zip"},
        },
    }

    assert platform_download_url(data) == "https://example.com/macos.zip"
