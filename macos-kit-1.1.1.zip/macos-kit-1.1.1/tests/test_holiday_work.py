from __future__ import annotations

from datetime import date

from calculations.salary_engine import calculate_day
from tests.test_daily_calculations import money, row


def test_7_holiday_work() -> None:
    result = calculate_day(row(date(2026, 7, 20), "23:00", "07:00", "03:00", "04:00", "Holiday Work"))
    assert result.worked_minutes == 420
    assert result.overtime_minutes == 0
    assert result.holiday_minutes == 420
    assert result.late_night_minutes == 300
    money(result.base_pay, "8750.00")
    money(result.holiday_premium_pay, "3062.50")
    money(result.late_night_pay, "1562.50")
    money(result.total_pay_exact, "13375.00")
