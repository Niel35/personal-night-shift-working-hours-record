import sys
from datetime import date, time

from PySide6.QtWidgets import QApplication

from app.main_window import MainWindow
from app.monthly_sheet import MonthlySheet
from calculations.models import ContractSettings, DailyInput
from database.database import TimesheetDatabase


def app():
    return QApplication.instance() or QApplication(sys.argv)


def test_calculated_row_preserves_user_notes():
    app()
    sheet = MonthlySheet()
    row = DailyInput(
        work_date=date(2026, 7, 1),
        status="Work",
        actual_in=time(18, 0),
        actual_out=time(4, 0),
        total_break_hours=1,
        notes="Bring badge tomorrow.",
    )

    sheet.build_month(2026, 7, [row], ContractSettings())

    assert sheet.table.item(0, 13).text() == "Bring badge tomorrow."


def test_clearing_note_only_row_deletes_saved_note(tmp_path):
    app()
    window = MainWindow(TimesheetDatabase(tmp_path / "timesheet.db"))
    window.sheet.record_month.setDate(date(2026, 7, 1))
    window.load_month()

    window.sheet.table.item(0, 13).setText("ascjsdvkdsjvf")
    window.autosave_row(0)
    assert window.db.records_for_month(2026, 7)[0].notes == "ascjsdvkdsjvf"

    window.sheet.table.item(0, 13).setText("")
    window.autosave_row(0)
    window.load_month()

    assert window.db.records_for_month(2026, 7) == []
    assert window.sheet.table.item(0, 13).text() == ""
