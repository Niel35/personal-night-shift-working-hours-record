from __future__ import annotations

from datetime import date

from tests.test_daily_calculations import money, row
from calculations.salary_engine import calculate_day


def test_6_saturday() -> None:
    result = calculate_day(row(date(2026, 7, 25), "19:00", "04:00", "23:00", "00:00"))
    assert result.saturday_minutes == 480
    money(result.saturday_allowance, "400.00")
    money(result.total_pay_exact, "11962.50")


def test_contract_weekend_allowance_includes_sunday() -> None:
    result = calculate_day(row(date(2026, 7, 26), "19:00", "04:00", "23:00", "00:00"))
    assert result.saturday_minutes == 480
    money(result.saturday_allowance, "400.00")
    money(result.total_pay_exact, "11962.50")
