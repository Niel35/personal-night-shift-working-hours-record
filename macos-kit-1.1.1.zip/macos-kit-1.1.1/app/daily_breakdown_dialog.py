from __future__ import annotations

from PySide6.QtWidgets import QDialog, QLabel, QTableWidget, QTableWidgetItem, QVBoxLayout

from calculations.formatting import hours_minutes
from calculations.models import DailyInput, DailyResult
from calculations.rounding import money2


def h(minutes: int) -> str:
    return hours_minutes(minutes)


class DailyBreakdownDialog(QDialog):
    def __init__(self, row: DailyInput, result: DailyResult, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Daily Salary Breakdown")
        self.resize(900, 420)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(f"Shift: {row.work_date.isoformat()} {row.actual_in or ''} to {row.actual_out or ''}"))
        table = QTableWidget(len(result.segments), 8)
        table.setHorizontalHeaderLabels(["Segment Start", "Segment End", "Paid Time", "Classification", "Base %", "Additional %", "Effective %", "Segment Salary"])
        for r, seg in enumerate(result.segments):
            values = [
                seg.start.strftime("%Y-%m-%d %H:%M"), seg.end.strftime("%Y-%m-%d %H:%M"), h(seg.paid_minutes),
                seg.classification, f"{seg.base_percentage}%", seg.additional_percentage,
                f"{seg.effective_percentage}%", f"{money2(seg.segment_salary):,.2f}円",
            ]
            for c, value in enumerate(values):
                table.setItem(r, c, QTableWidgetItem(str(value)))
        layout.addWidget(table)
