NAVY = "#071a3d"
HEADER_BLUE = "#155d9c"
LABEL_BLUE = "#e5f2ff"
INPUT_YELLOW = "#fff6cf"
CALC_BLUE = "#edf7ff"
SALARY_GREEN = "#def7e7"
GRID = "#9fb5cc"

APP_STYLESHEET = f"""
QMainWindow {{
    background: #eef4fa;
    font-family: "Segoe UI Variable", "Segoe UI";
    color: #102033;
}}
QStatusBar {{
    background: #fbfdff;
    color: #29445f;
    border-top: 1px solid #c7d6e4;
    padding: 5px 10px;
}}
QToolTip {{
    background: #ffffff;
    color: #102033;
    border: 1px solid #8fb2d4;
    border-radius: 6px;
    padding: 6px 8px;
}}
QScrollArea {{
    border: 0;
    background: #eef4fa;
}}
QToolBar {{
    background: #f8fafc;
    border-bottom: 1px solid #c6d3df;
    spacing: 4px;
    padding: 5px;
}}
QToolButton, QPushButton {{
    background: #1662a8;
    color: white;
    padding: 7px 12px;
    border: 1px solid #0f528d;
    border-radius: 6px;
    font-weight: 700;
}}
QToolButton:hover, QPushButton:hover {{ background: #0f5798; }}
QToolButton:pressed, QPushButton:pressed {{ background: #0a4073; }}
QPushButton:focus {{
    border: 2px solid #77b7ff;
    padding: 6px 11px;
}}
QLineEdit, QDateEdit, QTimeEdit, QComboBox, QTextEdit {{
    border: 1px solid {GRID};
    border-radius: 6px;
    padding: 6px 8px;
    background: {INPUT_YELLOW};
    selection-background-color: #2563eb;
    selection-color: white;
}}
QLineEdit:focus, QDateEdit:focus, QTimeEdit:focus, QComboBox:focus, QTextEdit:focus {{
    border: 2px solid #1f77c8;
    padding: 5px 7px;
}}
QLineEdit:read-only {{
    background: #edf4fa;
    color: #516376;
}}
QComboBox::drop-down {{
    border: 0;
    width: 22px;
}}
QComboBox::down-arrow {{
    width: 10px;
    height: 10px;
}}
QComboBox QAbstractItemView {{
    background: #ffffff;
    color: #102033;
    border: 1px solid #8fb2d4;
    border-radius: 6px;
    padding: 4px;
    outline: 0;
    selection-background-color: #d7ecff;
    selection-color: #071a3d;
}}
QTableWidget {{
    gridline-color: #d5e3f0;
    background: white;
    alternate-background-color: #fbfdff;
    font-family: "Segoe UI Variable", "Segoe UI";
    font-size: 9pt;
    selection-background-color: #d7ecff;
    selection-color: #102033;
    border: 1px solid #b9cce0;
    border-top: 0px;
    border-top-left-radius: 0px;
    border-top-right-radius: 0px;
    border-bottom-left-radius: 10px;
    border-bottom-right-radius: 10px;
}}
QHeaderView::section {{
    background: #135f9d;
    color: white;
    border: 0;
    border-right: 1px solid #2d76ae;
    border-bottom: 1px solid #0d4f87;
    padding: 9px 6px;
    font-weight: 800;
}}
QHeaderView::section:first {{
    border-left: 4px solid #135f9d;
    border-top-left-radius: 10px;
    padding-left: 3px;
}}
QHeaderView::section:last {{
    border-top-right-radius: 10px;
}}
QTableWidget::item {{
    padding: 6px;
    border: 0;
}}
QTableWidget::item:selected {{
    background: #cfe7ff;
    color: #061a33;
}}
QScrollBar:vertical {{
    background: #edf4fa;
    width: 12px;
    margin: 0;
    border: 0;
}}
QScrollBar::handle:vertical {{
    background: #9eb8d3;
    border-radius: 6px;
    min-height: 28px;
}}
QScrollBar::handle:vertical:hover {{
    background: #7fa3c7;
}}
QScrollBar:horizontal {{
    background: #edf4fa;
    height: 12px;
    margin: 0;
    border: 0;
}}
QScrollBar::handle:horizontal {{
    background: #9eb8d3;
    border-radius: 6px;
    min-width: 28px;
}}
QScrollBar::handle:horizontal:hover {{
    background: #7fa3c7;
}}
QScrollBar::add-line, QScrollBar::sub-line {{
    width: 0;
    height: 0;
    border: 0;
    background: transparent;
}}
QScrollBar#timesheetVerticalScroll {{
    background: transparent;
    width: 12px;
    margin: 0;
    border: 0;
}}
QScrollBar#timesheetVerticalScroll::handle:vertical {{
    background: transparent;
    border-radius: 6px;
    min-height: 28px;
}}
QScrollBar#timesheetVerticalScroll[hoverActive="true"] {{
    background: #edf4fa;
}}
QScrollBar#timesheetVerticalScroll::add-page:vertical,
QScrollBar#timesheetVerticalScroll::sub-page:vertical {{
    background: transparent;
}}
QScrollBar#timesheetVerticalScroll[hoverActive="true"]::add-page:vertical,
QScrollBar#timesheetVerticalScroll[hoverActive="true"]::sub-page:vertical {{
    background: #edf4fa;
}}
QScrollBar#timesheetVerticalScroll[hoverActive="true"]::handle:vertical {{
    background: #9eb8d3;
}}
QScrollBar#timesheetVerticalScroll[hoverActive="true"]::handle:vertical:hover {{
    background: #7fa3c7;
}}
"""
