from __future__ import annotations

from datetime import date, datetime, time, timedelta
from decimal import Decimal

from .models import BreakInterval, DailyInput


def minutes_to_decimal_hours(minutes: int) -> Decimal:
    return (Decimal(minutes) / Decimal("60")).quantize(Decimal("0.000001"))


def datetime_pair(row: DailyInput) -> tuple[datetime | None, datetime | None]:
    if row.actual_in is None or row.actual_out is None:
        return None, None
    start = datetime.combine(row.work_date, row.actual_in)
    end = datetime.combine(row.work_date, row.actual_out)
    if end <= start:
        end += timedelta(days=1)
    return start, end


def interval_datetimes(row: DailyInput, start: datetime, end: datetime) -> list[tuple[datetime, datetime]]:
    intervals: list[tuple[datetime, datetime]] = []
    for item in row.breaks:
        b_start = datetime.combine(row.work_date, item.start)
        if b_start < start:
            b_start += timedelta(days=1)
        b_end = datetime.combine(row.work_date, item.end)
        if b_end <= b_start:
            b_end += timedelta(days=1)
        intervals.append((b_start, b_end))
    if not intervals and row.total_break_hours and row.total_break_hours > 0:
        minutes = int(row.total_break_hours * Decimal("60"))
        auto_start = min(start + timedelta(hours=4), end)
        intervals.append((auto_start, min(auto_start + timedelta(minutes=minutes), end)))
    return sorted(intervals, key=lambda pair: pair[0])


def paid_intervals(start: datetime, end: datetime, breaks: list[tuple[datetime, datetime]]) -> list[tuple[datetime, datetime]]:
    intervals = [(start, end)]
    for b_start, b_end in breaks:
        next_items: list[tuple[datetime, datetime]] = []
        for i_start, i_end in intervals:
            if b_end <= i_start or b_start >= i_end:
                next_items.append((i_start, i_end))
            else:
                if b_start > i_start:
                    next_items.append((i_start, min(b_start, i_end)))
                if b_end < i_end:
                    next_items.append((max(b_end, i_start), i_end))
        intervals = next_items
    return [(s, e) for s, e in intervals if e > s]


def split_points(start: datetime, end: datetime) -> list[datetime]:
    points: list[datetime] = []
    day = start.date() - timedelta(days=1)
    while day <= end.date() + timedelta(days=1):
        for value in (time(0, 0), time(5, 0), time(22, 0)):
            point = datetime.combine(day, value)
            if start < point < end:
                points.append(point)
        day += timedelta(days=1)
    return points


def split_interval(start: datetime, end: datetime, points: list[datetime]) -> list[tuple[datetime, datetime]]:
    ordered = [start] + sorted({p for p in points if start < p < end}) + [end]
    return [(ordered[i], ordered[i + 1]) for i in range(len(ordered) - 1)]
