@echo off
setlocal
cd /d "%~dp0"
python -m pip install -r requirements.txt
python -m pytest
python -m PyInstaller night_shift_salary_recorder.spec --clean --noconfirm
echo.
echo Build complete. Check dist\PersonalNightShiftWorkingHoursRecord
