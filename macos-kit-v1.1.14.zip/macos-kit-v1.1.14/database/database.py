from __future__ import annotations

import sqlite3
from datetime import date, datetime, time, timedelta
from decimal import Decimal
from pathlib import Path

from calculations.models import (
    DEFAULT_WEEKLY_DAY_TYPES,
    BreakInterval,
    ContractSettings,
    DailyInput,
    DailyResult,
)
from calculations.salary_engine import calculate_day, summarize_month
from calculations.time_segments import datetime_pair
from .migrations import SCHEMA


def app_data_dir() -> Path:
    root = Path.home() / "AppData" / "Local" / "PersonalNightShiftWorkingHoursRecord"
    root.mkdir(parents=True, exist_ok=True)
    return root


class TimesheetDatabase:
    def __init__(self, path: str | Path | None = None) -> None:
        self.path = Path(path) if path else app_data_dir() / "timesheet.db"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path)
        self.conn.row_factory = sqlite3.Row
        self.initialize()

    def initialize(self) -> None:
        self.conn.executescript(SCHEMA)
        work_record_columns = {
            row["name"]
            for row in self.conn.execute("PRAGMA table_info(work_records)").fetchall()
        }
        if "saturday_allowance" in work_record_columns:
            self.conn.execute("ALTER TABLE work_records DROP COLUMN saturday_allowance")
        if "holiday_minutes" in work_record_columns:
            self.conn.execute("ALTER TABLE work_records DROP COLUMN holiday_minutes")
        if self.conn.execute("SELECT COUNT(*) FROM contract_settings").fetchone()[0] == 0:
            self.save_settings(ContractSettings(), recalculate=False)
        self.conn.commit()

    def settings(self) -> ContractSettings:
        row = self.conn.execute("SELECT * FROM contract_settings WHERE id=1").fetchone()
        assert row is not None
        return ContractSettings(
            base_hourly_wage=Decimal(row["base_hourly_wage"]),
            standard_daily_hours=Decimal(row["standard_daily_hours"]),
            standard_weekly_hours=Decimal(row["standard_weekly_hours"]),
            overtime_premium=Decimal(row["overtime_premium"]),
            late_night_premium=Decimal(row["late_night_premium"]),
            late_night_start=time.fromisoformat(row["late_night_start"]),
            late_night_end=time.fromisoformat(row["late_night_end"]),
            holiday_premium=Decimal(row["holiday_premium"]),
            over_60_total_premium=Decimal(row["over_60_total_premium"]),
            monthly_overtime_warning=Decimal(row["monthly_overtime_warning"]),
            annual_overtime_limit=Decimal(row["annual_overtime_limit"]),
            saturday_allowance_per_hour=Decimal(row["saturday_allowance_per_hour"]),
            payroll_week_start=int(row["payroll_week_start"]),
            rounding_method=row["rounding_method"],
            apply_overtime_to_holiday_work=bool(row["apply_overtime_to_holiday_work"]),
            weekly_day_types=DEFAULT_WEEKLY_DAY_TYPES,
        )

    def save_settings(self, settings: ContractSettings, recalculate: bool = True) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO contract_settings VALUES (1,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                str(settings.base_hourly_wage),
                str(settings.standard_daily_hours),
                str(settings.standard_weekly_hours),
                str(settings.overtime_premium),
                str(settings.late_night_premium),
                settings.late_night_start.isoformat(timespec="minutes"),
                settings.late_night_end.isoformat(timespec="minutes"),
                str(settings.holiday_premium),
                str(settings.over_60_total_premium),
                str(settings.monthly_overtime_warning),
                str(settings.annual_overtime_limit),
                str(settings.saturday_allowance_per_hour),
                settings.payroll_week_start,
                settings.rounding_method,
                int(settings.apply_overtime_to_holiday_work),
            ),
        )
        self.conn.commit()
        if recalculate:
            self.recalculate_all()

    def save_month_notes(self, month: str, name: str, np_no: str, project: str, personal: str, check: str) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO monthly_notes VALUES (?,?,?,?,?,?,?)",
            (month, name, np_no or "4026", project, personal, check, datetime.now().isoformat(timespec="seconds")),
        )
        self.conn.commit()

    def month_notes(self, month: str) -> dict[str, str]:
        row = self.conn.execute("SELECT * FROM monthly_notes WHERE month=?", (month,)).fetchone()
        if row:
            return dict(row)
        return {"month": month, "name": "", "np_no": "4026", "work_project": "", "personal_notes": "", "month_end_check": ""}

    def upsert_record(self, row: DailyInput) -> int:
        settings = self.settings()
        result = calculate_day(row, settings)
        now = datetime.now().isoformat(timespec="seconds")
        start_dt, end_dt = datetime_pair(row)
        existing = self.conn.execute("SELECT id, created_at FROM work_records WHERE work_date=?", (row.work_date.isoformat(),)).fetchone()
        payload = (
            row.work_date.isoformat(), row.status, row.schedule_ref,
            row.actual_in.isoformat(timespec="minutes") if row.actual_in else None,
            row.actual_out.isoformat(timespec="minutes") if row.actual_out else None,
            start_dt.isoformat(timespec="minutes") if start_dt else None,
            end_dt.isoformat(timespec="minutes") if end_dt else None,
            str(row.total_break_hours) if row.total_break_hours is not None else None,
            result.worked_minutes, result.regular_minutes, result.overtime_minutes, result.late_night_minutes,
            result.saturday_minutes, result.over_60_minutes,
            str(result.base_pay), str(result.premium_pay), str(result.total_pay_display),
            row.bike, row.notes,
        )
        if existing:
            record_id = int(existing["id"])
            self.conn.execute(
                """
                UPDATE work_records SET work_date=?, status=?, schedule_ref=?, actual_in=?, actual_out=?,
                actual_in_dt=?, actual_out_dt=?, total_break_hours=?, worked_minutes=?, regular_minutes=?,
                overtime_minutes=?, late_night_minutes=?, saturday_minutes=?, over_60_minutes=?,
                daily_base_pay=?, daily_premium_pay=?, daily_total_pay=?, bike=?, notes=?,
                updated_at=? WHERE id=?
                """,
                payload + (now, record_id),
            )
        else:
            cur = self.conn.execute(
                """
                INSERT INTO work_records
                (work_date,status,schedule_ref,actual_in,actual_out,actual_in_dt,actual_out_dt,total_break_hours,
                worked_minutes,regular_minutes,overtime_minutes,late_night_minutes,saturday_minutes,
                over_60_minutes,daily_base_pay,daily_premium_pay,daily_total_pay,bike,notes,created_at,updated_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                payload + (now, now),
            )
            record_id = int(cur.lastrowid)
        self.conn.execute("DELETE FROM break_intervals WHERE work_record_id=?", (record_id,))
        for index, item in enumerate(row.breaks):
            self.conn.execute(
                "INSERT INTO break_intervals (work_record_id,start_time,end_time,sort_order) VALUES (?,?,?,?)",
                (record_id, item.start.isoformat(timespec="minutes"), item.end.isoformat(timespec="minutes"), index),
            )
        self.conn.commit()
        self.recalculate_month(row.work_date.year, row.work_date.month)
        return record_id

    def clear_month(self, year: int, month: int) -> None:
        self.conn.execute("DELETE FROM work_records WHERE substr(work_date,1,7)=?", (f"{year:04d}-{month:02d}",))
        self.conn.commit()

    def delete_record_for_date(self, work_date: date) -> None:
        self.conn.execute("DELETE FROM work_records WHERE work_date=?", (work_date.isoformat(),))
        self.conn.commit()

    def records_for_month(self, year: int, month: int) -> list[DailyInput]:
        rows = self.conn.execute("SELECT * FROM work_records WHERE substr(work_date,1,7)=? ORDER BY work_date", (f"{year:04d}-{month:02d}",)).fetchall()
        return [self._row_to_daily(row) for row in rows]

    def all_records(self) -> list[DailyInput]:
        rows = self.conn.execute("SELECT * FROM work_records ORDER BY work_date").fetchall()
        return [self._row_to_daily(row) for row in rows]

    def month_start_week_context(
        self,
        year: int,
        month: int,
        settings: ContractSettings | None = None,
    ) -> dict[date, tuple[int, int]]:
        settings = settings or self.settings()
        month_start = date(year, month, 1)
        week_start = month_start - timedelta(
            days=(month_start.weekday() - settings.payroll_week_start) % 7
        )
        if week_start == month_start:
            return {}
        rows = self.conn.execute(
            "SELECT * FROM work_records WHERE work_date>=? AND work_date<? ORDER BY work_date",
            (week_start.isoformat(), month_start.isoformat()),
        ).fetchall()
        worked_minutes = 0
        workdays = 0
        for db_row in rows:
            row = self._row_to_daily(db_row)
            result = calculate_day(
                row,
                settings,
                prior_week_worked_minutes=worked_minutes,
                force_statutory_holiday=(
                    row.status in {"Work", "Saturday Work", "Sunday Work", "Holiday Work"}
                    and workdays >= 6
                ),
            )
            worked_minutes += max(
                0,
                result.worked_minutes
                - result.daily_overtime_minutes
                - result.holiday_minutes,
            )
            if result.worked_minutes > 0:
                workdays += 1
        return {week_start: (worked_minutes, workdays)}

    def monthly_results(self, year: int, month: int):
        settings = self.settings()
        return summarize_month(
            self.records_for_month(year, month),
            settings,
            self.month_start_week_context(year, month, settings),
        )

    def recalculate_month(self, year: int, month: int) -> None:
        settings = self.settings()
        rows, _ = summarize_month(
            self.records_for_month(year, month),
            settings,
            self.month_start_week_context(year, month, settings),
        )
        for row, result in rows:
            if row.record_id:
                self.conn.execute(
                    """
                    UPDATE work_records SET worked_minutes=?, regular_minutes=?, overtime_minutes=?,
                    late_night_minutes=?, saturday_minutes=?, over_60_minutes=?,
                    daily_base_pay=?, daily_premium_pay=?, daily_total_pay=?, updated_at=? WHERE id=?
                    """,
                    (
                        result.worked_minutes, result.regular_minutes, result.overtime_minutes, result.late_night_minutes,
                        result.saturday_minutes, result.over_60_minutes,
                        str(result.base_pay), str(result.premium_pay),
                        str(result.total_pay_display), datetime.now().isoformat(timespec="seconds"), row.record_id,
                    ),
                )
        self.conn.commit()

    def recalculate_all(self) -> None:
        months = self.conn.execute("SELECT DISTINCT substr(work_date,1,7) ym FROM work_records").fetchall()
        for row in months:
            year, month = map(int, row["ym"].split("-"))
            self.recalculate_month(year, month)

    def _row_to_daily(self, row: sqlite3.Row) -> DailyInput:
        breaks = self.conn.execute("SELECT * FROM break_intervals WHERE work_record_id=? ORDER BY sort_order,id", (row["id"],)).fetchall()
        return DailyInput(
            record_id=int(row["id"]),
            work_date=date.fromisoformat(row["work_date"]),
            status=row["status"],
            schedule_ref=row["schedule_ref"],
            actual_in=time.fromisoformat(row["actual_in"]) if row["actual_in"] else None,
            actual_out=time.fromisoformat(row["actual_out"]) if row["actual_out"] else None,
            total_break_hours=Decimal(row["total_break_hours"]) if row["total_break_hours"] else None,
            breaks=[BreakInterval(time.fromisoformat(b["start_time"]), time.fromisoformat(b["end_time"])) for b in breaks],
            bike=row["bike"],
            notes=row["notes"],
        )
