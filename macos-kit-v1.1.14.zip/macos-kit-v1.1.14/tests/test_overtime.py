from __future__ import annotations

from datetime import date, time
from decimal import Decimal

from calculations.models import DailyInput
from calculations.salary_engine import calculate_day, summarize_month
from database.database import TimesheetDatabase


def reported_week_rows() -> list[DailyInput]:
    shifts = [
        (date(2026, 8, 31), time(20, 0), time(5, 31)),
        (date(2026, 9, 1), time(19, 15), time(7, 17)),
        (date(2026, 9, 2), time(20, 30), time(5, 39)),
        (date(2026, 9, 3), time(21, 15), time(5, 17)),
        (date(2026, 9, 4), time(21, 45), time(5, 9)),
    ]
    return [
        DailyInput(
            work_date=work_date,
            status="Work",
            actual_in=actual_in,
            actual_out=actual_out,
            total_break_hours=Decimal("1"),
        )
        for work_date, actual_in, actual_out in shifts
    ]


def test_weekly_overtime_beyond_40_without_double_counting() -> None:
    result = calculate_day(
        DailyInput(date(2026, 7, 24), "Work", actual_in=time(9, 0), actual_out=time(17, 0)),
        prior_week_worked_minutes=39 * 60,
    )
    assert result.weekly_overtime_minutes == 7 * 60
    assert result.daily_overtime_minutes == 0


def test_daily_overtime_does_not_trigger_weekly_overtime_again() -> None:
    results, totals = summarize_month(reported_week_rows())
    friday = results[-1][1]

    assert [result.daily_overtime_minutes for _row, result in results] == [
        31,
        182,
        9,
        0,
        0,
    ]
    assert friday.weekly_overtime_minutes == 0
    assert friday.overtime_minutes == 0
    assert totals.overtime_minutes == 222


def test_cross_month_week_context_excludes_daily_overtime(tmp_path) -> None:
    db = TimesheetDatabase(tmp_path / "timesheet.db")
    for row in reported_week_rows():
        db.upsert_record(row)

    september_results, september_totals = db.monthly_results(2026, 9)
    friday = september_results[-1][1]

    assert friday.weekly_overtime_minutes == 0
    assert friday.overtime_minutes == 0
    assert september_totals.overtime_minutes == 191
