from __future__ import annotations

import sys
from pathlib import Path

APP_NAME = "Personal Night-Shift Working Hours Record"
APP_VERSION = "1.1.5"

UPDATE_MANIFEST_URL = (
    "https://github.com/Niel35/personal-night-shift-working-hours-record/"
    "releases/latest/download/update.json"
)


def resource_path(relative_path: str) -> Path:
    base_path = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[1]))
    return base_path / relative_path


OFFICIAL_LOGO_PATH = resource_path("resources/official_logo.png")
OFFICIAL_HEADER_LOGO_PATH = resource_path("resources/official_header_logo_4k.png")
OFFICIAL_ICON_PATH = resource_path(
    "resources/official_app_icon.icns"
    if sys.platform == "darwin"
    else "resources/official_app_icon.ico"
)
USER_EDITION_FLAG_PATH = resource_path("resources/user_edition.flag")
IS_USER_EDITION = USER_EDITION_FLAG_PATH.exists()
