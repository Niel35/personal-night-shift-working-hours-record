#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

APP_VERSION="$(python3 - <<'PY'
from app.app_info import APP_VERSION
print(APP_VERSION)
PY
)"
APP_BUNDLE="dist/Personal Night-Shift Working Hours Record.app"
RELEASE_DIR="release_packages/macos_user_install/v${APP_VERSION}"
PKG_ROOT="build/macos-pkg-root"
PKG_SCRIPTS="build/macos-pkg-scripts"
PKG_PATH="${RELEASE_DIR}/PersonalNightShiftWorkingHoursRecord-macOS-Installer-${APP_VERSION}.pkg"
ICONSET_DIR="resources/official_app_icon.iconset"
USER_FLAG="resources/user_edition.flag"
USER_FLAG_CREATED=0

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "This macOS release must be built on macOS."
  echo "PyInstaller cannot create a working .app from Windows."
  exit 1
fi

cleanup() {
  if [[ "${USER_FLAG_CREATED}" == "1" ]]; then
    rm -f "${USER_FLAG}"
  fi
}
trap cleanup EXIT

if [[ ! -d ".venv-macos" ]]; then
  python3 -m venv .venv-macos
fi
source .venv-macos/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

python - <<'PY'
from pathlib import Path
from PIL import Image

source = Path("resources/official_app_icon.png")
with Image.open(source) as image:
    if image.size != (1024, 1024):
        raise SystemExit(f"{source} must be exactly 1024x1024 pixels, got {image.size}.")
    if image.mode != "RGBA":
        raise SystemExit(f"{source} must use RGBA color, got {image.mode}.")
    corners = (
        image.getpixel((0, 0)),
        image.getpixel((1023, 0)),
        image.getpixel((0, 1023)),
        image.getpixel((1023, 1023)),
    )
    if any(pixel[3] != 0 for pixel in corners):
        raise SystemExit(f"{source} must have transparent outer corners for macOS.")
PY

rm -rf "${ICONSET_DIR}"
mkdir -p "${ICONSET_DIR}"
sips -z 16 16 resources/official_app_icon.png --out "${ICONSET_DIR}/icon_16x16.png" >/dev/null
sips -z 32 32 resources/official_app_icon.png --out "${ICONSET_DIR}/icon_16x16@2x.png" >/dev/null
sips -z 32 32 resources/official_app_icon.png --out "${ICONSET_DIR}/icon_32x32.png" >/dev/null
sips -z 64 64 resources/official_app_icon.png --out "${ICONSET_DIR}/icon_32x32@2x.png" >/dev/null
sips -z 128 128 resources/official_app_icon.png --out "${ICONSET_DIR}/icon_128x128.png" >/dev/null
sips -z 256 256 resources/official_app_icon.png --out "${ICONSET_DIR}/icon_128x128@2x.png" >/dev/null
sips -z 256 256 resources/official_app_icon.png --out "${ICONSET_DIR}/icon_256x256.png" >/dev/null
sips -z 512 512 resources/official_app_icon.png --out "${ICONSET_DIR}/icon_256x256@2x.png" >/dev/null
sips -z 512 512 resources/official_app_icon.png --out "${ICONSET_DIR}/icon_512x512.png" >/dev/null
sips -z 1024 1024 resources/official_app_icon.png --out "${ICONSET_DIR}/icon_512x512@2x.png" >/dev/null
iconutil -c icns "${ICONSET_DIR}" -o resources/official_app_icon.icns
test -s resources/official_app_icon.icns
rm -rf "${ICONSET_DIR}"

if [[ ! -f "${USER_FLAG}" ]]; then
  : > "${USER_FLAG}"
  USER_FLAG_CREATED=1
fi

python -m compileall app calculations database exports backup tests sample_data
QT_QPA_PLATFORM=offscreen python -m pytest
python -m PyInstaller night_shift_salary_recorder_macos.spec --clean --noconfirm

rm -rf "${RELEASE_DIR}"
mkdir -p "${RELEASE_DIR}"

rm -rf "${PKG_ROOT}" "${PKG_SCRIPTS}"
mkdir -p "${PKG_ROOT}/Applications" "${PKG_SCRIPTS}"
ditto "${APP_BUNDLE}" "${PKG_ROOT}/Applications/Personal Night-Shift Working Hours Record.app"

cat > "${PKG_SCRIPTS}/postinstall" <<'SH'
#!/bin/bash
set -eu

APP_PATH="/Applications/Personal Night-Shift Working Hours Record.app"
CONSOLE_USER="$(stat -f '%Su' /dev/console)"

case "${CONSOLE_USER}" in
  ""|root|loginwindow|_mbsetupuser)
    exit 0
    ;;
esac

USER_HOME="$(dscl . -read "/Users/${CONSOLE_USER}" NFSHomeDirectory | awk '{print $2}')"
DESKTOP_PATH="${USER_HOME}/Desktop"
SHORTCUT_PATH="${DESKTOP_PATH}/Personal Night-Shift Working Hours Record.app"

mkdir -p "${DESKTOP_PATH}"

# Preserve a real user file, but refresh a shortcut created by this installer.
if [[ -L "${SHORTCUT_PATH}" ]]; then
  rm -f "${SHORTCUT_PATH}"
fi
if [[ ! -e "${SHORTCUT_PATH}" ]]; then
  ln -s "${APP_PATH}" "${SHORTCUT_PATH}"
  chown -h "${CONSOLE_USER}:$(id -gn "${CONSOLE_USER}")" "${SHORTCUT_PATH}"
fi

# The app owns its future in-place updates after this administrator-approved install.
chown -R "${CONSOLE_USER}:$(id -gn "${CONSOLE_USER}")" "${APP_PATH}"

exit 0
SH
chmod 755 "${PKG_SCRIPTS}/postinstall"

pkgbuild \
  --root "${PKG_ROOT}" \
  --scripts "${PKG_SCRIPTS}" \
  --install-location "/" \
  --identifier "com.personalnightshift.workinghoursrecord" \
  --version "${APP_VERSION}" \
  "${PKG_PATH}"

ditto -c -k --sequesterRsrc --keepParent "${APP_BUNDLE}" "${RELEASE_DIR}/PersonalNightShiftWorkingHoursRecord-macOS-${APP_VERSION}.zip"
hdiutil create -volname "Personal Night-Shift Working Hours Record" \
  -srcfolder "${APP_BUNDLE}" \
  -ov -format UDZO \
  "${RELEASE_DIR}/PersonalNightShiftWorkingHoursRecord-macOS-${APP_VERSION}.dmg"

echo "macOS user release created:"
echo "${PKG_PATH}"
echo "${RELEASE_DIR}/PersonalNightShiftWorkingHoursRecord-macOS-${APP_VERSION}.dmg"
echo "${RELEASE_DIR}/PersonalNightShiftWorkingHoursRecord-macOS-${APP_VERSION}.zip"
