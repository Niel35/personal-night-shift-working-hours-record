import sys

from PySide6.QtCore import QEvent, Qt
from PySide6.QtGui import QKeyEvent
from PySide6.QtWidgets import QApplication

from app.monthly_sheet import COMPACT_SCREEN_MAX_WIDTH, MonthlySheet, uses_compact_layout


def test_common_13_inch_macbook_width_uses_compact_layout():
    assert uses_compact_layout(1280)
    assert uses_compact_layout(1440)


def test_large_desktop_keeps_standard_layout():
    assert not uses_compact_layout(COMPACT_SCREEN_MAX_WIDTH + 1)
    assert not uses_compact_layout(1920)


def test_arrow_keys_move_between_status_rows():
    app = QApplication.instance() or QApplication(sys.argv)
    sheet = MonthlySheet()
    sheet.show()
    sheet._set_combo(0, 2, ["", "Work", "Employer Leave"], "Work")
    sheet._set_combo(1, 2, ["", "Work", "Employer Leave"], "Employer Leave")
    first_combo = sheet.combo_widget(0, 2)
    second_combo = sheet.combo_widget(1, 2)
    assert first_combo is not None
    assert second_combo is not None

    first_combo.setFocus()
    app.processEvents()
    QApplication.sendEvent(first_combo, QKeyEvent(QEvent.KeyPress, Qt.Key_Down, Qt.NoModifier))
    app.processEvents()

    assert sheet.table.currentRow() == 1
    assert sheet.table.currentColumn() == 2
    assert second_combo.hasFocus()
