from __future__ import annotations

import pytest

from app.updater import (
    UpdateError,
    UpdateInfo,
    download_update,
    fetch_update_info,
    is_newer_version,
    platform_download,
    platform_download_url,
)


def test_version_compare_handles_semver_lengths() -> None:
    assert is_newer_version("1.1.1", "1.1.0")
    assert is_newer_version("1.2", "1.1.9")
    assert not is_newer_version("1.1.0", "1.1")


def test_update_url_must_be_configured() -> None:
    with pytest.raises(UpdateError):
        fetch_update_info("")


def test_platform_download_url_prefers_current_platform(monkeypatch) -> None:
    monkeypatch.setattr("app.updater.platform_key", lambda: "macos")
    data = {
        "latest_version": "1.1.1",
        "download_url": "https://example.com/windows.zip",
        "downloads": {
            "windows": {"download_url": "https://example.com/windows.zip"},
            "macos": {"download_url": "https://example.com/macos.zip"},
        },
    }

    assert platform_download_url(data) == "https://example.com/macos.zip"


def test_platform_download_rejects_package_for_another_platform(monkeypatch) -> None:
    monkeypatch.setattr("app.updater.platform_key", lambda: "windows")
    data = {
        "latest_version": "1.1.3",
        "download_url": "https://example.com/macos.zip",
        "downloads": {"macos": {"download_url": "https://example.com/macos.zip"}},
    }

    with pytest.raises(UpdateError, match="No update package is available for windows"):
        platform_download(data)


def test_download_update_verifies_sha256(monkeypatch, tmp_path) -> None:
    payload = b"verified update"

    class Response:
        def __enter__(self):
            return self

        def __exit__(self, *_args):
            return None

        def read(self, _size):
            if getattr(self, "used", False):
                return b""
            self.used = True
            return payload

    monkeypatch.setattr("urllib.request.urlopen", lambda *_args, **_kwargs: Response())
    info = UpdateInfo(
        latest_version="1.1.3",
        download_url="https://example.com/update.zip",
        sha256="59f19f34399b14e5f1628642e9ce341d660094ba76898e4db6b1875f525b6a6a",
    )

    assert download_update(info, tmp_path).read_bytes() == payload


def test_download_update_removes_bad_checksum(monkeypatch, tmp_path) -> None:
    payload = b"tampered update"

    class Response:
        def __enter__(self):
            return self

        def __exit__(self, *_args):
            return None

        def read(self, _size):
            if getattr(self, "used", False):
                return b""
            self.used = True
            return payload

    monkeypatch.setattr("urllib.request.urlopen", lambda *_args, **_kwargs: Response())
    info = UpdateInfo(
        latest_version="1.1.3",
        download_url="https://example.com/update.zip",
        sha256="0" * 64,
    )

    with pytest.raises(UpdateError, match="security check"):
        download_update(info, tmp_path)
    assert not list(tmp_path.iterdir())
