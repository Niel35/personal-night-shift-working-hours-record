from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import textwrap
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path

from .app_info import APP_VERSION, UPDATE_MANIFEST_URL


class UpdateError(RuntimeError):
    pass


@dataclass(frozen=True)
class UpdateInfo:
    latest_version: str
    download_url: str
    sha256: str = ""
    release_notes: str = ""
    published_at: str = ""
    mandatory: bool = False


def platform_key() -> str:
    if sys.platform == "darwin":
        return "macos"
    if sys.platform.startswith("win"):
        return "windows"
    return sys.platform


def current_install_path() -> Path:
    if not getattr(sys, "frozen", False):
        raise UpdateError("Automatic installation is available only in the installed app.")
    executable = Path(sys.executable).resolve()
    if sys.platform == "darwin":
        for parent in executable.parents:
            if parent.suffix == ".app":
                return parent
        raise UpdateError("Could not locate the current macOS app bundle.")
    return executable.parent


def version_tuple(version: str) -> tuple[int, ...]:
    parts = re.findall(r"\d+", version)
    return tuple(int(part) for part in parts) if parts else (0,)


def is_newer_version(latest: str, current: str = APP_VERSION) -> bool:
    latest_parts = version_tuple(latest)
    current_parts = version_tuple(current)
    longest = max(len(latest_parts), len(current_parts))
    latest_parts += (0,) * (longest - len(latest_parts))
    current_parts += (0,) * (longest - len(current_parts))
    return latest_parts > current_parts


def platform_download(data: dict) -> tuple[str, str]:
    downloads = data.get("downloads", {})
    entry: dict = data
    if isinstance(downloads, dict) and downloads:
        selected = downloads.get(platform_key())
        if not isinstance(selected, dict):
            raise UpdateError(f"No update package is available for {platform_key()}.")
        entry = selected
    url = entry.get("download_url") or entry.get("url")
    if not url:
        raise UpdateError(f"The update manifest has no download URL for {platform_key()}.")
    checksum = entry.get("sha256") or data.get("sha256") or ""
    return str(url), str(checksum).lower()


def platform_download_url(data: dict) -> str:
    return platform_download(data)[0]


def fetch_update_info(manifest_url: str = UPDATE_MANIFEST_URL, timeout: int = 8) -> UpdateInfo:
    if not manifest_url:
        raise UpdateError("Update URL is not configured yet.")
    request = urllib.request.Request(manifest_url, headers={"User-Agent": "PersonalNightShiftWorkingHoursRecord/" + APP_VERSION})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            payload = response.read(1024 * 1024).decode("utf-8")
    except (urllib.error.URLError, TimeoutError) as exc:
        raise UpdateError(f"Could not connect to the update server: {exc}") from exc
    try:
        data = json.loads(payload)
        download_url, checksum = platform_download(data)
        info = UpdateInfo(
            latest_version=str(data["latest_version"]),
            download_url=download_url,
            sha256=checksum,
            release_notes=str(data.get("release_notes", "")),
            published_at=str(data.get("published_at", "")),
            mandatory=bool(data.get("mandatory", False)),
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise UpdateError("The update manifest is invalid.") from exc
    if not info.download_url.startswith(("https://", "http://")):
        raise UpdateError("The update download URL must start with http:// or https://.")
    return info


def download_update(info: UpdateInfo, target_dir: Path | None = None, timeout: int = 30) -> Path:
    target_dir = target_dir or Path.home() / "Downloads"
    target_dir.mkdir(parents=True, exist_ok=True)
    url_path = urllib.parse.urlparse(info.download_url).path
    filename = Path(urllib.parse.unquote(url_path)).name or f"PersonalNightShiftWorkingHoursRecord-{info.latest_version}.zip"
    target = target_dir / filename
    partial_target = target.with_name(target.name + ".part")
    request = urllib.request.Request(info.download_url, headers={"User-Agent": "PersonalNightShiftWorkingHoursRecord/" + APP_VERSION})
    digest = hashlib.sha256()
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response, partial_target.open("wb") as file:
            while True:
                chunk = response.read(1024 * 512)
                if not chunk:
                    break
                file.write(chunk)
                digest.update(chunk)
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        partial_target.unlink(missing_ok=True)
        raise UpdateError(f"Could not download the update: {exc}") from exc
    actual_checksum = digest.hexdigest()
    if info.sha256 and actual_checksum != info.sha256:
        partial_target.unlink(missing_ok=True)
        raise UpdateError(
            "The downloaded update did not pass its security check. "
            "The file was removed; please try again."
        )
    partial_target.replace(target)
    return target


def create_windows_installer_script(update_path: Path, install_dir: Path, relaunch_path: Path, app_pid: int) -> Path:
    script_path = Path(tempfile.gettempdir()) / "PersonalNightShiftWorkingHoursRecord-update.ps1"
    extract_dir = Path(tempfile.gettempdir()) / "PersonalNightShiftWorkingHoursRecord-update-extract"
    script = f"""
    $ErrorActionPreference = 'Stop'
    $updatePath = {str(update_path)!r}
    $installDir = {str(install_dir)!r}
    $relaunchPath = {str(relaunch_path)!r}
    $extractDir = {str(extract_dir)!r}
    $appPid = {app_pid}

    try {{
      Wait-Process -Id $appPid -Timeout 30 -ErrorAction SilentlyContinue
    }} catch {{}}

    if (Test-Path -LiteralPath $extractDir) {{
      Remove-Item -LiteralPath $extractDir -Recurse -Force
    }}
    New-Item -ItemType Directory -Path $extractDir | Out-Null
    Expand-Archive -LiteralPath $updatePath -DestinationPath $extractDir -Force

    $sourceDir = Join-Path $extractDir 'PersonalNightShiftWorkingHoursRecord'
    if (!(Test-Path -LiteralPath $sourceDir)) {{
      $sourceDir = Get-ChildItem -LiteralPath $extractDir -Directory | Select-Object -First 1 -ExpandProperty FullName
    }}
    if (!(Test-Path -LiteralPath $sourceDir)) {{
      throw 'Could not find the extracted app folder.'
    }}

    robocopy $sourceDir $installDir /MIR /NFL /NDL /NJH /NJS /NP | Out-Null
    $code = $LASTEXITCODE
    if ($code -gt 7) {{
      throw "Update copy failed with robocopy code $code."
    }}

    Start-Process -FilePath $relaunchPath
    """
    script_path.write_text(textwrap.dedent(script).strip() + "\n", encoding="utf-8")
    return script_path


def create_macos_installer_script(update_path: Path, app_path: Path, app_pid: int) -> Path:
    if update_path.suffix.lower() != ".zip":
        raise UpdateError("Automatic macOS installation requires the macOS .zip update package.")
    script_path = Path(tempfile.gettempdir()) / "PersonalNightShiftWorkingHoursRecord-update.sh"
    extract_dir = Path(tempfile.gettempdir()) / "PersonalNightShiftWorkingHoursRecord-update-extract"
    script = f"""
    #!/bin/bash
    set -euo pipefail
    update_path={str(update_path)!r}
    app_path={str(app_path)!r}
    extract_dir={str(extract_dir)!r}
    app_pid={app_pid}

    while kill -0 "$app_pid" 2>/dev/null; do
      sleep 1
    done

    rm -rf "$extract_dir"
    mkdir -p "$extract_dir"
    /usr/bin/ditto -x -k "$update_path" "$extract_dir"

    new_app="$(/usr/bin/find "$extract_dir" -maxdepth 2 -name '*.app' -type d | /usr/bin/head -n 1)"
    if [ -z "$new_app" ]; then
      echo "Could not find the extracted app bundle." >&2
      exit 1
    fi

    rm -rf "$app_path"
    /bin/cp -R "$new_app" "$app_path"
    /usr/bin/open "$app_path"
    """
    script_path.write_text(textwrap.dedent(script).strip() + "\n", encoding="utf-8")
    script_path.chmod(0o755)
    return script_path


def launch_update_installer(update_path: Path) -> None:
    update_path = update_path.resolve()
    if not update_path.exists():
        raise UpdateError(f"Downloaded update was not found:\n{update_path}")
    if update_path.suffix.lower() != ".zip":
        raise UpdateError("Automatic installation requires a .zip update package.")

    install_path = current_install_path()
    if sys.platform == "darwin":
        script_path = create_macos_installer_script(update_path, install_path, os.getpid())
        subprocess.Popen(["/bin/bash", str(script_path)], close_fds=True)
        return

    if sys.platform.startswith("win"):
        relaunch_path = install_path / "PersonalNightShiftWorkingHoursRecord.exe"
        if not relaunch_path.exists():
            raise UpdateError(f"Could not find the app executable:\n{relaunch_path}")
        script_path = create_windows_installer_script(update_path, install_path, relaunch_path, os.getpid())
        subprocess.Popen(
            [
                "powershell.exe",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(script_path),
            ],
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        return

    raise UpdateError(f"Automatic installation is not supported on this platform: {sys.platform}")
