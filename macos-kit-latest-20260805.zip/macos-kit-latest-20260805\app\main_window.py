from __future__ import annotations

import logging
from datetime import date, time
from decimal import Decimal, InvalidOperation
from pathlib import Path

from PySide6.QtCore import QDate, QSettings, Qt, QTimer, QUrl
from PySide6.QtGui import QDesktopServices, QIcon, QPainter
from PySide6.QtWidgets import QApplication, QFileDialog, QMainWindow, QMessageBox, QScrollArea, QToolBar

from backup.backup_manager import backup_database, log_backup, restore_database
from calculations.models import BreakInterval, DailyInput
from calculations.salary_engine import calculate_day, summarize_month
from database.database import TimesheetDatabase
from exports.excel_export import export_month_excel
from exports.pdf_export import export_month_pdf
from exports.printing import print_direct, show_print_preview
from .break_editor_dialog import BreakEditorDialog
from .app_info import APP_NAME, APP_VERSION, OFFICIAL_ICON_PATH
from .contract_settings_dialog import ContractSettingsDialog
from .daily_breakdown_dialog import DailyBreakdownDialog
from .monthly_sheet import (
    COMPACT_SCREEN_MAX_WIDTH,
    STATUS_COLUMN,
    TARGET_DISPLAY_HEIGHT_RATIO,
    MonthlySheet,
    is_target_display,
)
from .styles import APP_STYLESHEET
from .theme import apply_theme
from .updater import UpdateError, download_update, fetch_update_info, is_newer_version, launch_update_installer

LOG = logging.getLogger(__name__)


class MainWindow(QMainWindow):
    def __init__(self, db: TimesheetDatabase) -> None:
        super().__init__()
        self.db = db
        self.setWindowTitle(f"{APP_NAME} v{APP_VERSION}")
        self.setWindowIcon(QIcon(str(OFFICIAL_ICON_PATH)))
        self.setMinimumSize(960, 640)
        self._fit_to_available_screen()
        self.preferences = QSettings("Niel35", "PersonalNightShiftWorkingHoursRecord")
        self.night_mode = self.preferences.value("appearance/night_mode", False, type=bool)
        self._appearance_timer = QTimer(self)
        self._appearance_timer.setSingleShot(True)
        self._appearance_timer.setInterval(16)
        self._appearance_timer.timeout.connect(self.apply_appearance)
        self.setStyleSheet(APP_STYLESHEET)
        self.sheet = MonthlySheet()
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll.setVerticalScrollBarPolicy(
            Qt.ScrollBarAlwaysOff if self.sheet.target_display else Qt.ScrollBarAsNeeded
        )
        self.scroll.setWidget(self.sheet)
        self.setCentralWidget(self.scroll)
        QTimer.singleShot(0, self._fit_sheet_to_viewport)
        self.sheet.record_month.setDate(QDate.currentDate())
        self.sheet.record_month.dateChanged.connect(lambda *_: self.load_month())
        self.sheet.name.editingFinished.connect(self.save_notes)
        self.sheet.project.editingFinished.connect(self.save_notes)
        self.sheet.wage_label.editingFinished.connect(self.save_hourly_wage)
        self.sheet.update_button.clicked.connect(lambda: self.check_for_updates(show_no_update=True))
        self.sheet.release_button.clicked.connect(lambda: self.check_for_updates(show_no_update=True))
        self.sheet.night_mode_button.clicked.connect(self.toggle_night_mode)
        self.sheet.personal_notes.textChanged.connect(self.save_notes)
        self.sheet.month_end_check.textChanged.connect(self.save_notes)
        self.statusBar().setVisible(False)
        self.load_month()
        self.apply_appearance()
        QTimer.singleShot(1800, lambda: self.check_for_updates(show_no_update=False))

    def apply_appearance(self) -> None:
        apply_theme(self, self.night_mode, APP_STYLESHEET)
        if self.sheet.night_mode_button.isChecked() != self.night_mode:
            self.sheet.night_mode_button.set_mode(self.night_mode)
        mode_name = "Day Mode" if self.night_mode else "Night Mode"
        self.sheet.night_mode_button.setAccessibleName(mode_name)
        self.sheet.night_mode_button.setToolTip(f"Switch to {mode_name}")

    def toggle_night_mode(self) -> None:
        self.night_mode = self.sheet.night_mode_button.isChecked()
        self.sheet.night_mode_button.set_mode(self.night_mode)
        self.sheet.night_mode_button.repaint()
        self.preferences.setValue("appearance/night_mode", self.night_mode)
        self._appearance_timer.start()
        QTimer.singleShot(500, self.preferences.sync)

    def _fit_sheet_to_viewport(self) -> None:
        if not hasattr(self, "scroll") or not hasattr(self, "sheet"):
            return
        viewport_height = self.scroll.viewport().height()
        if viewport_height > 0:
            self.sheet.setFixedHeight(viewport_height)

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        QTimer.singleShot(0, self._fit_sheet_to_viewport)

    def _fit_to_available_screen(self) -> None:
        screen = QApplication.primaryScreen()
        if not screen:
            self.resize(1280, 760)
            return
        available = screen.availableGeometry()
        physical = screen.physicalSize()
        if is_target_display(physical.width(), physical.height()):
            margin = 6
            maximum_width = available.width() - (margin * 2)
            maximum_height = available.height() - (margin * 2)
            width = min(maximum_width, int(maximum_height / TARGET_DISPLAY_HEIGHT_RATIO))
            height = round(width * TARGET_DISPLAY_HEIGHT_RATIO)
            self.resize(width, height)
            self.move(
                available.x() + (available.width() - width) // 2,
                available.y() + (available.height() - height) // 2,
            )
            return
        width_ratio = 0.99 if available.width() <= COMPACT_SCREEN_MAX_WIDTH else 0.96
        width = max(960, min(1600, int(available.width() * width_ratio)))
        height = max(640, min(1000, int(available.height() * 0.92)))
        self.resize(width, height)
        self.move(
            available.x() + (available.width() - width) // 2,
            available.y() + (available.height() - height) // 2,
        )

    def _build_toolbar(self) -> None:
        toolbar = QToolBar("Timesheet")
        toolbar.setMovable(False)
        self.addToolBar(toolbar)
        actions = [
            ("New Month", self.new_month, "Jump to the current month."),
            ("Save", self.save_month, "Save the whole visible month."),
            ("Example", self.load_example_day, "Load a sample overnight shift into the first row."),
            ("Clear Month", self.clear_month, "Delete all saved rows in the selected month."),
            ("Recalculate", self.load_month, "Reload and recalculate the selected month."),
            ("|", None, ""),
            ("Excel", self.export_excel, "Export the selected month to Excel."),
            ("PDF", self.export_pdf, "Export the selected month to A4 landscape PDF."),
            ("Preview", self.print_preview, "Open print preview."),
            ("Print", self.print_sheet, "Print the visible sheet."),
            ("|", None, ""),
            ("Settings", self.settings, "Edit wage, premium, and overtime settings."),
            ("Backup", self.backup, "Back up the SQLite database."),
            ("Restore", self.restore, "Restore a database backup."),
            ("|", None, ""),
            ("Zoom +", self.zoom_in, "Increase sheet text size."),
            ("Zoom -", self.zoom_out, "Decrease sheet text size."),
        ]
        for label, callback, tip in actions:
            if label == "|":
                toolbar.addSeparator()
                continue
            action = toolbar.addAction(label)
            action.triggered.connect(callback)

    def ym(self) -> tuple[int, int, str]:
        qd = self.sheet.record_month.date()
        return qd.year(), qd.month(), f"{qd.year():04d}-{qd.month():02d}"

    def load_month(self) -> None:
        year, month, month_key = self.ym()
        notes = self.db.month_notes(month_key)
        self.sheet.name.blockSignals(True)
        self.sheet.project.blockSignals(True)
        self.sheet.wage_label.blockSignals(True)
        self.sheet.personal_notes.blockSignals(True)
        self.sheet.month_end_check.blockSignals(True)
        self.sheet.name.setText(notes.get("name", ""))
        self.sheet.np_no.setText(notes.get("np_no", "4026"))
        self.sheet.project.setText(notes.get("work_project", ""))
        self.sheet.personal_notes.setPlainText(notes.get("personal_notes", ""))
        self.sheet.month_end_check.setPlainText(notes.get("month_end_check", ""))
        self.sheet.name.blockSignals(False)
        self.sheet.project.blockSignals(False)
        self.sheet.wage_label.blockSignals(False)
        self.sheet.personal_notes.blockSignals(False)
        self.sheet.month_end_check.blockSignals(False)
        settings = self.db.settings()
        self.sheet.set_contract_display(settings)
        self.sheet.build_month(
            year,
            month,
            self.db.records_for_month(year, month),
            settings,
            self.db.month_start_week_context(year, month, settings),
        )
        if hasattr(self, "night_mode"):
            self.apply_appearance()

    def save_hourly_wage(self) -> None:
        raw = self.sheet.wage_label.text().replace("円", "").replace(",", "").strip()
        try:
            wage = Decimal(raw)
            if wage <= 0:
                raise InvalidOperation
        except (InvalidOperation, ValueError):
            QMessageBox.warning(self, "Invalid hourly wage", "Enter a positive hourly wage, for example 1250 or 1,250.00 円.")
            self.sheet.set_contract_display(self.db.settings())
            return
        current = self.db.settings()
        if wage == current.base_hourly_wage:
            self.sheet.set_contract_display(current)
            return
        current.base_hourly_wage = wage
        self.db.save_settings(current)
        self.load_month()
        self.statusBar().showMessage(f"Hourly wage updated to {self.sheet.wage_label.text()}.", 3000)

    def save_notes(self) -> None:
        _year, _month, month_key = self.ym()
        self.db.save_month_notes(
            month_key,
            self.sheet.name.text(),
            self.sheet.np_no.text() or "4026",
            self.sheet.project.text(),
            self.sheet.personal_notes.toPlainText(),
            self.sheet.month_end_check.toPlainText(),
        )

    def autosave_from_sheet(self) -> None:
        try:
            self.save_month(show_message=False)
        except Exception:
            LOG.exception("Autosave failed")

    def autosave_row(self, row_index: int) -> None:
        year, month, _ = self.ym()
        try:
            row = self.sheet.daily_input(year, month, row_index + 1)
        except ValueError:
            return
        if self._row_has_data(row):
            self.db.upsert_record(row)
        else:
            self.db.delete_record_for_date(row.work_date)
        self.save_notes()
        self.statusBar().showMessage(f"Autosaved row {row_index + 1}.", 2500)

    def calculate_row(self, row_index: int) -> None:
        year, month, _ = self.ym()
        try:
            row = self.sheet.daily_input(year, month, row_index + 1)
        except ValueError as exc:
            QMessageBox.warning(self, "Invalid time", str(exc))
            return
        if row.status == "Work":
            combo = self.sheet.combo_widget(row_index, STATUS_COLUMN)
            if combo:
                combo.setCurrentText("Work")
        result = calculate_day(row, self.db.settings())
        if result.warnings:
            if QMessageBox.question(self, "Warnings", "\n".join(result.warnings) + "\n\nCalculate and save anyway?") != QMessageBox.Yes:
                return
        if self._row_has_data(row):
            self.db.upsert_record(row)
        else:
            self.db.delete_record_for_date(row.work_date)
        self.save_notes()
        self.load_month()
        self.statusBar().showMessage(f"Calculated row {row_index + 1}.", 2500)

    def reset_row(self, row_index: int) -> None:
        year, month, _ = self.ym()
        work_date = date(year, month, row_index + 1)
        if QMessageBox.question(self, "Reset Row", f"Clear saved data for {work_date.isoformat()}?") != QMessageBox.Yes:
            return
        self.db.delete_record_for_date(work_date)
        self.sheet.breaks_by_day.pop(row_index + 1, None)
        self.load_month()
        self.statusBar().showMessage(f"Reset row {row_index + 1}.", 2500)

    def save_month(self, show_message: bool = True) -> None:
        year, month, _ = self.ym()
        settings = self.db.settings()
        try:
            rows = self.sheet.all_inputs(year, month)
        except ValueError as exc:
            if show_message:
                QMessageBox.warning(self, "Invalid time", str(exc))
            return
        _results, totals = summarize_month(rows, settings)
        warnings = list(totals.warnings)
        for row in rows:
            warnings.extend(calculate_day(row, settings).warnings)
        if warnings and show_message:
            if QMessageBox.question(self, "Warnings", "\n".join(dict.fromkeys(warnings)) + "\n\nSave anyway?") != QMessageBox.Yes:
                return
        for row in rows:
            if self._row_has_data(row):
                self.db.upsert_record(row)
            else:
                self.db.delete_record_for_date(row.work_date)
        self.save_notes()
        self.load_month()
        if show_message:
            QMessageBox.information(self, "Saved", "Month saved.")

    def _row_has_data(self, row: DailyInput) -> bool:
        return bool(
            row.status
            or row.actual_in
            or row.actual_out
            or (row.total_break_hours is not None and row.total_break_hours > 0)
            or row.breaks
            or row.notes.strip()
        )

    def new_month(self) -> None:
        self.sheet.record_month.setDate(QDate.currentDate())

    def load_example_day(self) -> None:
        self.sheet.table.item(0, 3).setText("18:00")
        self.sheet.table.item(0, 4).setText("04:00")
        self.sheet.table.item(0, 5).setText("60")
        self.sheet.breaks_by_day[1] = [BreakInterval(time(23, 0), time(0, 0))]
        combo = self.sheet.combo_widget(0, STATUS_COLUMN)
        if combo:
            combo.setCurrentText("Work")
        self.calculate_row(0)

    def clear_month(self) -> None:
        year, month, _ = self.ym()
        if QMessageBox.question(self, "Clear Month", "Delete saved rows for this month?") == QMessageBox.Yes:
            self.db.clear_month(year, month)
            self.load_month()

    def settings(self) -> None:
        current = self.db.settings()
        dialog = ContractSettingsDialog(current, self)
        if dialog.exec():
            self.db.save_settings(dialog.settings(current))
            self.load_month()

    def check_for_updates(self, show_no_update: bool = True) -> None:
        self.statusBar().showMessage("Checking for app updates...")
        try:
            info = fetch_update_info(timeout=8 if show_no_update else 3)
        except UpdateError as exc:
            self.statusBar().showMessage("Update check unavailable.", 3500)
            LOG.info("Update check unavailable: %s", exc)
            if show_no_update:
                QMessageBox.warning(
                    self,
                    "Update Check Failed",
                    str(exc),
                )
            return
        if not is_newer_version(info.latest_version, APP_VERSION):
            self.statusBar().showMessage(f"You are using the latest version ({APP_VERSION}).", 3500)
            if show_no_update:
                QMessageBox.information(self, "No Update", f"You are using the latest version: {APP_VERSION}.")
            return
        message = (
            f"Version {info.latest_version} is available.\n\n"
            f"Current version: {APP_VERSION}\n"
            f"Published: {info.published_at or 'Not specified'}\n\n"
            f"{info.release_notes or 'No release notes provided.'}"
        )
        dialog = QMessageBox(self)
        dialog.setWindowTitle("Update Available")
        dialog.setIcon(QMessageBox.Information)
        dialog.setText(message)
        download_button = dialog.addButton("Download and Install", QMessageBox.AcceptRole)
        dialog.addButton("Later", QMessageBox.RejectRole)
        dialog.exec()
        if dialog.clickedButton() == download_button:
            self.download_app_update(info)

    def download_app_update(self, info) -> None:
        self.statusBar().showMessage("Downloading update...")
        try:
            path = download_update(info)
        except UpdateError as exc:
            self.statusBar().showMessage("Update download failed.", 3500)
            QMessageBox.warning(self, "Download Failed", str(exc))
            return
        self.statusBar().showMessage(f"Update downloaded: {path}", 6000)
        install_note = "The app will close now, install the update, then reopen automatically."
        QMessageBox.information(
            self,
            "Installing Update",
            f"The update was downloaded to:\n{path}\n\n{install_note}",
        )
        try:
            launch_update_installer(path, info.latest_version)
        except UpdateError as exc:
            self.statusBar().showMessage("Automatic installation failed.", 3500)
            QMessageBox.warning(
                self,
                "Install Failed",
                f"{exc}\n\nThe update was downloaded to:\n{path}",
            )
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
            return
        QApplication.quit()

    def rows_for_export(self):
        year, month, month_key = self.ym()
        rows, totals = self.db.monthly_results(year, month)
        return year, month, {row.work_date.day: (row, result) for row, result in rows}, totals, self.db.settings(), self.db.month_notes(month_key)

    def export_excel(self) -> None:
        self.save_month(show_message=False)
        year, month, rows, totals, settings, notes = self.rows_for_export()
        path, _ = QFileDialog.getSaveFileName(self, "Export Excel", f"personal_night_shift_{year}_{month:02d}.xlsx", "Excel (*.xlsx)")
        if path:
            export_month_excel(path, year, month, rows, totals, settings, notes)
            QMessageBox.information(self, "Exported", path)

    def export_pdf(self) -> None:
        self.save_month(show_message=False)
        year, month, rows, totals, settings, notes = self.rows_for_export()
        path, _ = QFileDialog.getSaveFileName(self, "Export PDF", f"personal_night_shift_{year}_{month:02d}.pdf", "PDF (*.pdf)")
        if path:
            export_month_pdf(path, year, month, rows, totals, settings, notes)
            QMessageBox.information(self, "Exported", path)

    def print_preview(self) -> None:
        show_print_preview(self, self.paint_for_print)

    def print_sheet(self) -> None:
        print_direct(self, self.paint_for_print)

    def paint_for_print(self, printer) -> None:
        painter = QPainter(printer)
        rect = painter.viewport()
        size = self.sheet.size()
        size.scale(rect.size(), __import__("PySide6.QtCore").QtCore.Qt.KeepAspectRatio)
        painter.setViewport(rect.x(), rect.y(), size.width(), size.height())
        painter.setWindow(self.sheet.rect())
        self.sheet.render(painter)
        painter.end()

    def backup(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Backup database", "personal_night_shift_backup.db", "SQLite DB (*.db)")
        if path:
            backup_database(self.db.path, path)
            log_backup(self.db.conn, "backup", path)

    def restore(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Restore database", "", "SQLite DB (*.db)")
        if path and QMessageBox.question(self, "Restore", "Replace the current database?") == QMessageBox.Yes:
            self.db.conn.close()
            restore_database(self.db.path, path)
            self.db = TimesheetDatabase(self.db.path)
            self.load_month()

    def zoom_in(self) -> None:
        self.sheet.zoom_factor = min(1.5, self.sheet.zoom_factor + 0.1)
        self.sheet.setStyleSheet(f"font-size: {9 * self.sheet.zoom_factor}pt;")

    def zoom_out(self) -> None:
        self.sheet.zoom_factor = max(0.75, self.sheet.zoom_factor - 0.1)
        self.sheet.setStyleSheet(f"font-size: {9 * self.sheet.zoom_factor}pt;")

    def sheet_double_clicked(self, row: int, col: int) -> None:
        year, month, _ = self.ym()
        day = row + 1
        if col == 5:
            current = self.sheet.breaks_by_day.get(day, [])
            dialog = BreakEditorDialog(current, self)
            if dialog.exec():
                self.sheet.breaks_by_day[day] = dialog.intervals()
                self.save_month(show_message=False)
        elif col in (6, 7, 8, 9, 10, 11, 12, 13):
            daily = self.sheet.daily_input(year, month, day)
            result = calculate_day(daily, self.db.settings())
            DailyBreakdownDialog(daily, result, self).exec()
