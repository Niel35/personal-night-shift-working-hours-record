from __future__ import annotations

import logging
import sys
import ctypes
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication

from app.app_info import APP_NAME, OFFICIAL_ICON_PATH
from app.main_window import MainWindow
from app.popup_guard import install_popup_guard
from database.database import TimesheetDatabase


def configure_logging() -> None:
    log_dir = Path.home() / "AppData" / "Local" / "PersonalNightShiftWorkingHoursRecord" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(filename=log_dir / "app.log", level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")


def configure_windows_taskbar_identity() -> None:
    if sys.platform != "win32":
        return
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
            "Niel35.PersonalNightShiftWorkingHoursRecord"
        )
    except (AttributeError, OSError):
        logging.getLogger(__name__).exception("Could not set the Windows taskbar identity")


def main() -> int:
    configure_logging()
    configure_windows_taskbar_identity()
    QApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationDisplayName(APP_NAME)
    app.setOrganizationName("Niel35")
    install_popup_guard(app)
    app.setWindowIcon(QIcon(str(OFFICIAL_ICON_PATH)))
    window = MainWindow(TimesheetDatabase())
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
