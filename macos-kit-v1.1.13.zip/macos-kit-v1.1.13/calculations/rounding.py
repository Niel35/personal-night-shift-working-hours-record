from __future__ import annotations

from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, ROUND_HALF_UP


def round_yen(value: Decimal, method: str) -> Decimal:
    if method == "round_down":
        return value.quantize(Decimal("1"), rounding=ROUND_FLOOR)
    if method == "round_up":
        return value.quantize(Decimal("1"), rounding=ROUND_CEILING)
    return value.quantize(Decimal("1"), rounding=ROUND_HALF_UP)


def money2(value: Decimal) -> Decimal:
    return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
