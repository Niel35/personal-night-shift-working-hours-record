from __future__ import annotations


def hours_minutes(minutes: int) -> str:
    sign = "-" if minutes < 0 else ""
    total = abs(int(minutes))
    hours, mins = divmod(total, 60)
    return f"{sign}{hours}hr {mins:02d}min"
