from __future__ import annotations

from datetime import date, datetime, time, timedelta
from decimal import Decimal

from .models import (
    NON_STATUTORY_HOLIDAY,
    STATUTORY_HOLIDAY,
    ContractSettings,
    DailyInput,
    DailyResult,
    MonthlyTotals,
    SalarySegment,
)
from .rounding import round_yen
from .time_segments import datetime_pair, interval_datetimes, minutes_to_decimal_hours, paid_intervals, split_interval, split_points

SATURDAY_WORK_STATUS = "Saturday Work"
SUNDAY_WORK_STATUS = "Sunday Work"
SUNDAY_HOLIDAY_STATUS = SUNDAY_WORK_STATUS
LEGACY_SUNDAY_HOLIDAY_STATUS = "Sunday Holiday"
WEEKEND_WORK_STATUSES = {
    SATURDAY_WORK_STATUS,
    SUNDAY_WORK_STATUS,
    LEGACY_SUNDAY_HOLIDAY_STATUS,
}
WORK_STATUSES = {
    "Work",
    "Holiday Work",
    *WEEKEND_WORK_STATUSES,
}
EMPLOYER_LEAVE_STATUS = "Employer Leave"
EMPLOYER_LEAVE_STATUSES = {EMPLOYER_LEAVE_STATUS, "Employer Leave 60%"}
PAID_LEAVE_STATUS = "Paid Leave"


def is_late_night(dt: datetime, settings: ContractSettings) -> bool:
    start = settings.late_night_start
    end = settings.late_night_end
    if start > end:
        return dt.time() >= start or dt.time() < end
    return start <= dt.time() < end


def day_type_at(dt: datetime, settings: ContractSettings) -> str:
    day_types = settings.weekly_day_types
    if len(day_types) == 7:
        return day_types[dt.weekday()]
    return (
        STATUTORY_HOLIDAY
        if dt.weekday() == settings.statutory_holiday_weekday
        else "Work Day"
    )


def is_statutory_holiday(dt: datetime, settings: ContractSettings) -> bool:
    return day_type_at(dt, settings) == STATUTORY_HOLIDAY


def validate_day(row: DailyInput, existing: list[tuple[datetime, datetime]] | None = None) -> list[str]:
    if row.status not in WORK_STATUSES:
        return []
    warnings: list[str] = []
    start, end = datetime_pair(row)
    if start is None:
        warnings.append("Clock-in is missing.")
    if end is None:
        warnings.append("Clock-out is missing.")
    if start is None or end is None:
        return warnings
    if end - start > timedelta(hours=24):
        warnings.append("Shift duration exceeds 24 hours.")
    breaks = interval_datetimes(row, start, end)
    total_break = timedelta()
    last_end: datetime | None = None
    for b_start, b_end in breaks:
        total_break += b_end - b_start
        if b_start < start or b_end > end:
            warnings.append("Break is outside the shift.")
        if last_end and b_start < last_end:
            warnings.append("Break periods overlap.")
        last_end = b_end
    if total_break >= end - start and breaks:
        warnings.append("Break is longer than the shift.")
    for ex_start, ex_end in existing or []:
        if start < ex_end and end > ex_start:
            warnings.append("Two shifts overlap or duplicate records exist.")
            break
    return list(dict.fromkeys(warnings))


def _daily_threshold_point(intervals: list[tuple[datetime, datetime]], threshold_minutes: int) -> list[datetime]:
    points: list[datetime] = []
    cumulative = 0
    for start, end in intervals:
        minutes = int((end - start).total_seconds() // 60)
        if cumulative < threshold_minutes < cumulative + minutes:
            points.append(start + timedelta(minutes=threshold_minutes - cumulative))
        cumulative += minutes
    return points


def calculate_day(
    row: DailyInput,
    settings: ContractSettings | None = None,
    prior_week_worked_minutes: int = 0,
    prior_month_overtime_minutes: int = 0,
    existing: list[tuple[datetime, datetime]] | None = None,
    force_statutory_holiday: bool = False,
) -> DailyResult:
    settings = settings or ContractSettings()
    result = DailyResult(warnings=validate_day(row, existing))
    if row.status in EMPLOYER_LEAVE_STATUSES:
        result.employer_leave_allowance = (
            settings.base_hourly_wage
            * settings.standard_daily_hours
            * settings.employer_leave_allowance_rate
        )
        result.total_pay_exact = result.employer_leave_allowance
        result.total_pay_display = round_yen(result.total_pay_exact, settings.rounding_method)
        return result
    if row.status == PAID_LEAVE_STATUS:
        result.paid_leave_pay = settings.base_hourly_wage * settings.standard_daily_hours
        result.total_pay_exact = result.paid_leave_pay
        result.total_pay_display = round_yen(result.total_pay_exact, settings.rounding_method)
        return result
    if row.status not in WORK_STATUSES:
        return result
    shift_start, shift_end = datetime_pair(row)
    if shift_start is None or shift_end is None:
        return result

    breaks = interval_datetimes(row, shift_start, shift_end)
    result.elapsed_minutes = int((shift_end - shift_start).total_seconds() // 60)
    result.break_minutes = sum(int((b_end - b_start).total_seconds() // 60) for b_start, b_end in breaks)
    intervals = paid_intervals(shift_start, shift_end, breaks)
    result.worked_minutes = sum(int((end - start).total_seconds() // 60) for start, end in intervals)

    daily_threshold = int(settings.standard_daily_hours * Decimal("60"))
    weekly_threshold = max(0, int(settings.standard_weekly_hours * Decimal("60")) - prior_week_worked_minutes)
    threshold_points = _daily_threshold_point(intervals, daily_threshold) + _daily_threshold_point(intervals, weekly_threshold)

    cumulative_day = 0
    month_ot = prior_month_overtime_minutes
    shift_day_type = settings.weekly_day_types[row.work_date.weekday()]
    for start, end in intervals:
        pieces = split_interval(start, end, split_points(start, end) + threshold_points)
        index = 0
        while index < len(pieces):
            p_start, p_end = pieces[index]
            minutes = int((p_end - p_start).total_seconds() // 60)
            scheduled_day_type = shift_day_type
            holiday = (
                row.status == "Holiday Work"
                or force_statutory_holiday
            )
            weekend_base_adjustment = row.work_date.weekday() in (5, 6) and not holiday
            non_statutory_holiday = scheduled_day_type == NON_STATUTORY_HOLIDAY
            daily_ot = not holiday and cumulative_day >= daily_threshold
            weekly_ot = not holiday and not daily_ot and (
                prior_week_worked_minutes + cumulative_day
                >= int(settings.standard_weekly_hours * Decimal("60"))
            )
            statutory_ot = daily_ot or weekly_ot
            if statutory_ot and month_ot < 3600 < month_ot + minutes:
                before = 3600 - month_ot
                split_at = p_start + timedelta(minutes=before)
                pieces[index:index + 1] = [(p_start, split_at), (split_at, p_end)]
                continue
            over60 = statutory_ot and month_ot >= 3600
            late = is_late_night(p_start, settings)
            pct = Decimal("1.00")
            additions: list[str] = []
            if holiday:
                label = "Holiday Work"
                pct += settings.holiday_premium
                additions.append("Statutory Holiday +35%")
            elif non_statutory_holiday:
                label = "Non-Statutory Holiday Work"
            else:
                label = "Regular"
            if over60:
                label = (
                    f"{label} + Overtime Above 60 Hours"
                    if holiday
                    else "Non-Statutory Holiday Overtime Above 60 Hours"
                    if non_statutory_holiday
                    else "Overtime Above 60 Hours"
                )
                pct += settings.over_60_total_premium
                additions.append("Over-60 OT +50% total")
            elif statutory_ot:
                label = (
                    f"{label} + Overtime"
                    if holiday
                    else "Non-Statutory Holiday Overtime"
                    if non_statutory_holiday
                    else "Overtime"
                )
                pct += settings.overtime_premium
                additions.append("OT +25%")
            if late:
                label = "Late Night" if label == "Regular" else f"{label} + Late Night"
                pct += settings.late_night_premium
                additions.append("Night +25%")

            hours = minutes_to_decimal_hours(minutes)
            weekend_adjustment = (
                settings.saturday_allowance_per_hour
                if weekend_base_adjustment
                else Decimal("0")
            )
            premium_base_rate = settings.base_hourly_wage
            if weekend_adjustment:
                additions.append("Weekend allowance +50 yen/hr")
            # Weekend pay is a fixed contractual allowance. Legal percentage
            # premiums continue to use the contractual base hourly wage.
            hourly = premium_base_rate * pct + weekend_adjustment
            result.segments.append(
                SalarySegment(
                    start=p_start,
                    end=p_end,
                    paid_minutes=minutes,
                    classification=label,
                    base_percentage=Decimal("100"),
                    additional_percentage=", ".join(additions),
                    effective_percentage=pct * Decimal("100"),
                    hourly_amount=hourly,
                    segment_salary=hourly * hours,
                    is_overtime=statutory_ot,
                    is_weekly_overtime=weekly_ot,
                    is_over_60=over60,
                    is_late_night=late,
                    is_holiday=holiday,
                )
            )
            if daily_ot:
                result.daily_overtime_minutes += minutes
            if weekly_ot:
                result.weekly_overtime_minutes += minutes
            if statutory_ot:
                result.overtime_minutes += minutes
                result.overtime_base_pay += hours * premium_base_rate
                result.overtime_premium_pay += (
                    hours * premium_base_rate * settings.overtime_premium
                )
                month_ot += minutes
            if over60:
                result.over_60_minutes += minutes
                result.over_60_extra_pay += (
                    hours
                    * premium_base_rate
                    * (settings.over_60_total_premium - settings.overtime_premium)
                )
            if late:
                result.late_night_minutes += minutes
                result.late_night_pay += (
                    hours * premium_base_rate * settings.late_night_premium
                )
            if weekend_base_adjustment:
                result.saturday_minutes += minutes
            if holiday:
                result.holiday_minutes += minutes
                result.holiday_premium_pay += (
                    hours * premium_base_rate * settings.holiday_premium
                )
            result.base_pay += hours * premium_base_rate
            cumulative_day += minutes
            index += 1

    result.regular_minutes = sum(
        segment.paid_minutes
        for segment in result.segments
        if not segment.is_overtime and not segment.is_holiday
    )
    # Keep every premium separate from Base Pay 100% so the table can show an
    # auditable base-plus-premiums calculation without duplicate amounts.
    result.premium_pay = (
        result.overtime_premium_pay
        + result.over_60_extra_pay
        + result.late_night_pay
        + result.holiday_premium_pay
    )
    result.total_pay_exact = (
        result.base_pay
        + result.premium_pay
        + minutes_to_decimal_hours(result.saturday_minutes)
        * settings.saturday_allowance_per_hour
    )
    result.total_pay_display = round_yen(result.total_pay_exact, settings.rounding_method)
    return result


def summarize_month(
    rows: list[DailyInput],
    settings: ContractSettings | None = None,
    initial_week_context: dict[date, tuple[int, int]] | None = None,
) -> tuple[list[tuple[DailyInput, DailyResult]], MonthlyTotals]:
    settings = settings or ContractSettings()
    ordered = sorted(rows, key=lambda r: (r.work_date, r.actual_in or time(0, 0), r.record_id or 0))
    totals = MonthlyTotals()
    initial_week_context = initial_week_context or {}
    week_worked = {
        week_start: worked_minutes
        for week_start, (worked_minutes, _workdays) in initial_week_context.items()
    }
    week_workdays = {
        week_start: workdays
        for week_start, (_worked_minutes, workdays) in initial_week_context.items()
    }
    month_ot = 0
    results: list[tuple[DailyInput, DailyResult]] = []
    for row in ordered:
        week_start = row.work_date - timedelta(days=(row.work_date.weekday() - settings.payroll_week_start) % 7)
        force_statutory_holiday = (
            row.status in WORK_STATUSES
            and week_workdays.get(week_start, 0) >= 6
        )
        result = calculate_day(
            row,
            settings,
            week_worked.get(week_start, 0),
            month_ot,
            force_statutory_holiday=force_statutory_holiday,
        )
        results.append((row, result))
        # Statutory-holiday hours receive the holiday premium and do not count
        # toward the ordinary 40-hour weekly overtime threshold.
        week_worked[week_start] = week_worked.get(week_start, 0) + max(
            0, result.worked_minutes - result.holiday_minutes
        )
        month_ot += result.overtime_minutes
        totals.worked_minutes += result.worked_minutes
        totals.regular_minutes += result.regular_minutes
        totals.overtime_minutes += result.overtime_minutes
        totals.late_night_minutes += result.late_night_minutes
        totals.saturday_minutes += result.saturday_minutes
        totals.holiday_minutes += result.holiday_minutes
        totals.over_60_minutes += result.over_60_minutes
        totals.base_pay += result.base_pay
        totals.overtime_premium_pay += result.overtime_premium_pay
        totals.over_60_extra_pay += result.over_60_extra_pay
        totals.late_night_pay += result.late_night_pay
        totals.holiday_premium_pay += result.holiday_premium_pay
        totals.premium_pay += result.premium_pay
        totals.employer_leave_allowance += result.employer_leave_allowance
        totals.paid_leave_pay += result.paid_leave_pay
        totals.total_pay += result.total_pay_exact
        if row.status in WORK_STATUSES and result.worked_minutes > 0:
            totals.workdays += 1
            week_workdays[week_start] = week_workdays.get(week_start, 0) + 1
        if row.status in EMPLOYER_LEAVE_STATUSES:
            totals.employer_leave_days += 1
        if row.status == PAID_LEAVE_STATUS:
            totals.paid_leave_days += 1
        if result.holiday_minutes > 0:
            totals.holiday_work_days += 1
    if totals.overtime_minutes > int(settings.monthly_overtime_warning * Decimal("60")):
        totals.warnings.append("Monthly overtime exceeds 45 hours.")
    if totals.overtime_minutes > 3600:
        totals.warnings.append("Monthly overtime exceeds 60 hours.")
    if totals.holiday_work_days > 4:
        totals.warnings.append("Holiday Work exceeds four days in one month.")
    totals.total_pay = round_yen(totals.total_pay, settings.rounding_method)
    return results, totals
