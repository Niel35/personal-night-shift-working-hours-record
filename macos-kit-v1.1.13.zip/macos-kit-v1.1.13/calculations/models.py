from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime, time
from decimal import Decimal


WORK_DAY = "Work Day"
STATUTORY_HOLIDAY = "Statutory Holiday"
NON_STATUTORY_HOLIDAY = "Non-Statutory Holiday"
DEFAULT_WEEKLY_DAY_TYPES = (
    WORK_DAY,
    WORK_DAY,
    WORK_DAY,
    WORK_DAY,
    WORK_DAY,
    NON_STATUTORY_HOLIDAY,
    NON_STATUTORY_HOLIDAY,
)


@dataclass(slots=True)
class ContractSettings:
    base_hourly_wage: Decimal = Decimal("1250")
    standard_daily_hours: Decimal = Decimal("8")
    standard_weekly_hours: Decimal = Decimal("40")
    overtime_premium: Decimal = Decimal("0.25")
    late_night_premium: Decimal = Decimal("0.25")
    late_night_start: time = time(22, 0)
    late_night_end: time = time(5, 0)
    holiday_premium: Decimal = Decimal("0.35")
    over_60_total_premium: Decimal = Decimal("0.50")
    monthly_overtime_warning: Decimal = Decimal("45")
    annual_overtime_limit: Decimal = Decimal("360")
    saturday_allowance_per_hour: Decimal = Decimal("50")
    statutory_holiday_weekday: int = 6
    employer_leave_allowance_rate: Decimal = Decimal("0.60")
    payroll_week_start: int = 0
    rounding_method: str = "round_final_nearest_yen"
    apply_overtime_to_holiday_work: bool = False
    weekly_day_types: tuple[str, ...] = DEFAULT_WEEKLY_DAY_TYPES


@dataclass(slots=True)
class BreakInterval:
    start: time
    end: time


@dataclass(slots=True)
class DailyInput:
    work_date: date
    status: str = ""
    schedule_ref: str = ""
    actual_in: time | None = None
    actual_out: time | None = None
    breaks: list[BreakInterval] = field(default_factory=list)
    total_break_hours: Decimal | None = None
    bike: str = ""
    notes: str = ""
    record_id: int | None = None


@dataclass(slots=True)
class SalarySegment:
    start: datetime
    end: datetime
    paid_minutes: int
    classification: str
    base_percentage: Decimal
    additional_percentage: str
    effective_percentage: Decimal
    hourly_amount: Decimal
    segment_salary: Decimal
    is_overtime: bool = False
    is_weekly_overtime: bool = False
    is_over_60: bool = False
    is_late_night: bool = False
    is_holiday: bool = False


@dataclass(slots=True)
class DailyResult:
    elapsed_minutes: int = 0
    break_minutes: int = 0
    worked_minutes: int = 0
    regular_minutes: int = 0
    daily_overtime_minutes: int = 0
    weekly_overtime_minutes: int = 0
    overtime_minutes: int = 0
    late_night_minutes: int = 0
    saturday_minutes: int = 0
    holiday_minutes: int = 0
    over_60_minutes: int = 0
    base_pay: Decimal = Decimal("0")
    overtime_base_pay: Decimal = Decimal("0")
    overtime_premium_pay: Decimal = Decimal("0")
    over_60_extra_pay: Decimal = Decimal("0")
    late_night_pay: Decimal = Decimal("0")
    holiday_premium_pay: Decimal = Decimal("0")
    employer_leave_allowance: Decimal = Decimal("0")
    paid_leave_pay: Decimal = Decimal("0")
    premium_pay: Decimal = Decimal("0")
    total_pay_exact: Decimal = Decimal("0")
    total_pay_display: Decimal = Decimal("0")
    segments: list[SalarySegment] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


@dataclass(slots=True)
class MonthlyTotals:
    worked_minutes: int = 0
    regular_minutes: int = 0
    overtime_minutes: int = 0
    late_night_minutes: int = 0
    saturday_minutes: int = 0
    holiday_minutes: int = 0
    over_60_minutes: int = 0
    base_pay: Decimal = Decimal("0")
    overtime_premium_pay: Decimal = Decimal("0")
    over_60_extra_pay: Decimal = Decimal("0")
    late_night_pay: Decimal = Decimal("0")
    holiday_premium_pay: Decimal = Decimal("0")
    premium_pay: Decimal = Decimal("0")
    employer_leave_allowance: Decimal = Decimal("0")
    paid_leave_pay: Decimal = Decimal("0")
    total_pay: Decimal = Decimal("0")
    workdays: int = 0
    employer_leave_days: int = 0
    paid_leave_days: int = 0
    holiday_work_days: int = 0
    warnings: list[str] = field(default_factory=list)
