"""Salary calculation package."""
