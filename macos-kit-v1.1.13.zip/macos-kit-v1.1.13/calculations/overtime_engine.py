"""Overtime classification is implemented in salary_engine.calculate_day."""
