"""Database rows map to calculation dataclasses in calculations.models."""
