SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS contract_settings (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    base_hourly_wage TEXT NOT NULL,
    standard_daily_hours TEXT NOT NULL,
    standard_weekly_hours TEXT NOT NULL,
    overtime_premium TEXT NOT NULL,
    late_night_premium TEXT NOT NULL,
    late_night_start TEXT NOT NULL,
    late_night_end TEXT NOT NULL,
    holiday_premium TEXT NOT NULL,
    over_60_total_premium TEXT NOT NULL,
    monthly_overtime_warning TEXT NOT NULL,
    annual_overtime_limit TEXT NOT NULL,
    saturday_allowance_per_hour TEXT NOT NULL,
    payroll_week_start INTEGER NOT NULL,
    rounding_method TEXT NOT NULL,
    apply_overtime_to_holiday_work INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS work_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    work_date TEXT NOT NULL,
    status TEXT NOT NULL,
    schedule_ref TEXT NOT NULL,
    actual_in TEXT,
    actual_out TEXT,
    actual_in_dt TEXT,
    actual_out_dt TEXT,
    total_break_hours TEXT,
    worked_minutes INTEGER NOT NULL DEFAULT 0,
    regular_minutes INTEGER NOT NULL DEFAULT 0,
    overtime_minutes INTEGER NOT NULL DEFAULT 0,
    late_night_minutes INTEGER NOT NULL DEFAULT 0,
    saturday_minutes INTEGER NOT NULL DEFAULT 0,
    over_60_minutes INTEGER NOT NULL DEFAULT 0,
    daily_base_pay TEXT NOT NULL DEFAULT '0',
    daily_premium_pay TEXT NOT NULL DEFAULT '0',
    daily_total_pay TEXT NOT NULL DEFAULT '0',
    bike TEXT NOT NULL DEFAULT '',
    notes TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE(work_date)
);

CREATE TABLE IF NOT EXISTS break_intervals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    work_record_id INTEGER NOT NULL REFERENCES work_records(id) ON DELETE CASCADE,
    start_time TEXT NOT NULL,
    end_time TEXT NOT NULL,
    sort_order INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS monthly_notes (
    month TEXT PRIMARY KEY,
    name TEXT NOT NULL DEFAULT '',
    np_no TEXT NOT NULL DEFAULT '4026',
    work_project TEXT NOT NULL DEFAULT '',
    personal_notes TEXT NOT NULL DEFAULT '',
    month_end_check TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS app_preferences (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS backups_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    action TEXT NOT NULL,
    file_path TEXT NOT NULL,
    created_at TEXT NOT NULL
);
"""
