from __future__ import annotations

import argparse
import hashlib
import json
from datetime import date
from pathlib import Path


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def release_asset_url(owner: str, repo: str, version: str, filename: str) -> str:
    return f"https://github.com/{owner}/{repo}/releases/download/v{version}/{filename}"


def build_manifest(
    owner: str,
    repo: str,
    version: str,
    windows_zip: Path,
    macos_zip: Path,
    release_notes: str,
) -> dict:
    windows_zip = windows_zip.resolve()
    macos_zip = macos_zip.resolve()
    return {
        "latest_version": version,
        "download_url": release_asset_url(owner, repo, version, windows_zip.name),
        "published_at": date.today().isoformat(),
        "mandatory": False,
        "sha256": sha256_file(windows_zip),
        "downloads": {
            "windows": {
                "download_url": release_asset_url(owner, repo, version, windows_zip.name),
                "sha256": sha256_file(windows_zip),
                "filename": windows_zip.name,
            },
            "macos": {
                "download_url": release_asset_url(owner, repo, version, macos_zip.name),
                "sha256": sha256_file(macos_zip),
                "filename": macos_zip.name,
            },
        },
        "release_notes": release_notes.strip() or f"Personal Night-Shift Working Hours Record {version} release.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Create update.json for a GitHub Release.")
    parser.add_argument("--owner", required=True, help="GitHub username or organization.")
    parser.add_argument("--repo", required=True, help="GitHub repository name.")
    parser.add_argument("--version", required=True, help="Version without the leading v, for example 1.1.1.")
    parser.add_argument("--windows-zip", required=True, type=Path, help="Windows release zip file.")
    parser.add_argument("--macos-zip", required=True, type=Path, help="macOS release zip file.")
    parser.add_argument("--notes", default="", help="Release notes shown in the app.")
    parser.add_argument("--output", default=Path("update.json"), type=Path, help="Output update.json path.")
    args = parser.parse_args()

    manifest = build_manifest(
        args.owner,
        args.repo,
        args.version,
        args.windows_zip,
        args.macos_zip,
        args.notes,
    )
    args.output.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(args.output.resolve())


if __name__ == "__main__":
    main()
