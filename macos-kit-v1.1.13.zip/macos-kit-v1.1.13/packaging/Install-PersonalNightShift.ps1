$ErrorActionPreference = "Stop"

$appName = "PersonalNightShiftWorkingHoursRecord"
$displayName = "Personal Night-Shift Working Hours Record"
$sourceRoot = Join-Path $PSScriptRoot $appName
$targetRoot = Join-Path $env:LOCALAPPDATA "Programs\$appName"
$exeName = "$appName.exe"
$targetExe = Join-Path $targetRoot $exeName

if (!(Test-Path -LiteralPath (Join-Path $sourceRoot $exeName))) {
    throw "Could not find $exeName beside this installer."
}

if (Test-Path -LiteralPath $targetRoot) {
    Remove-Item -LiteralPath $targetRoot -Recurse -Force
}

New-Item -ItemType Directory -Path (Split-Path $targetRoot) -Force | Out-Null
Copy-Item -LiteralPath $sourceRoot -Destination $targetRoot -Recurse -Force

$desktop = [Environment]::GetFolderPath("Desktop")
$shortcutPath = Join-Path $desktop "$displayName.lnk"
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $targetExe
$shortcut.WorkingDirectory = $targetRoot
$shortcut.IconLocation = $targetExe
$shortcut.Description = $displayName
$shortcut.Save()

Write-Host "$displayName installed successfully."
Write-Host "Desktop shortcut: $shortcutPath"
