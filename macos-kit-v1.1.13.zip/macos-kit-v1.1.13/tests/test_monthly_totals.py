from __future__ import annotations

from datetime import date

from calculations.salary_engine import summarize_month
from database.database import TimesheetDatabase
from tests.test_daily_calculations import row


def test_monthly_totals() -> None:
    first = row(date(2026, 7, 20), "19:00", "04:00", "23:00", "00:00")
    second = row(date(2026, 7, 21), "19:00", "04:00", "23:00", "00:00")
    rows, totals = summarize_month([first, second])
    assert rows[0][1].total_pay_exact == rows[1][1].total_pay_exact
    assert totals.worked_minutes == 960


def test_delete_record_for_date(tmp_path) -> None:
    db = TimesheetDatabase(tmp_path / "timesheet.db")
    db.upsert_record(row(date(2026, 7, 20), "19:00", "04:00", "23:00", "00:00"))
    assert len(db.records_for_month(2026, 7)) == 1
    db.delete_record_for_date(date(2026, 7, 20))
    assert db.records_for_month(2026, 7) == []
