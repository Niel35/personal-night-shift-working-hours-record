from __future__ import annotations

from datetime import date

from calculations.models import DailyInput
from calculations.salary_engine import calculate_day, summarize_month


def test_paid_leave_pays_standard_day_without_worked_hours() -> None:
    result = calculate_day(DailyInput(date(2026, 7, 24), status="Paid Leave"))

    assert result.worked_minutes == 0
    assert result.paid_leave_pay == 10000
    assert result.total_pay_exact == 10000
    assert result.total_pay_display == 10000


def test_paid_leave_counts_in_monthly_estimated_pay() -> None:
    _rows, totals = summarize_month(
        [
            DailyInput(date(2026, 7, 24), status="Paid Leave"),
            DailyInput(date(2026, 7, 25), status="Day Off"),
        ]
    )

    assert totals.worked_minutes == 0
    assert totals.workdays == 0
    assert totals.paid_leave_days == 1
    assert totals.paid_leave_pay == 10000
    assert totals.total_pay == 10000
