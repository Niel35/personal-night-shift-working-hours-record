from __future__ import annotations

from datetime import date

from calculations.salary_engine import calculate_day
from tests.test_daily_calculations import row


def test_over_60_monthly_threshold_splits_shift() -> None:
    result = calculate_day(row(date(2026, 7, 20), "18:00", "04:00", "23:00", "00:00"), prior_month_overtime_minutes=59 * 60 + 30)
    assert result.overtime_minutes == 60
    assert result.over_60_minutes == 30
    assert any(seg.is_over_60 for seg in result.segments)
