from __future__ import annotations

from datetime import date, time
from decimal import Decimal

from calculations.models import BreakInterval, ContractSettings, DailyInput
from calculations.salary_engine import calculate_day


def row(work_date: date, start: str, end: str, b_start: str, b_end: str, status: str = "Work") -> DailyInput:
    return DailyInput(
        work_date=work_date,
        status=status,
        actual_in=time.fromisoformat(start),
        actual_out=time.fromisoformat(end),
        breaks=[BreakInterval(time.fromisoformat(b_start), time.fromisoformat(b_end))],
    )


def money(actual: Decimal, expected: str) -> None:
    assert actual.quantize(Decimal("0.01")) == Decimal(expected)


def test_1_18_to_04() -> None:
    result = calculate_day(row(date(2026, 7, 20), "18:00", "04:00", "23:00", "00:00"))
    assert result.elapsed_minutes == 600
    assert result.break_minutes == 60
    assert result.worked_minutes == 540
    assert result.regular_minutes == 480
    assert result.daily_overtime_minutes == 60
    assert result.late_night_minutes == 300
    money(result.base_pay, "11250.00")
    money(result.overtime_premium_pay, "312.50")
    money(result.late_night_pay, "1562.50")
    money(result.total_pay_exact, "13125.00")


def test_2_19_to_04() -> None:
    result = calculate_day(row(date(2026, 7, 20), "19:00", "04:00", "23:00", "00:00"))
    assert result.worked_minutes == 480
    assert result.daily_overtime_minutes == 0
    assert result.late_night_minutes == 300
    money(result.base_pay, "10000.00")
    money(result.total_pay_exact, "11562.50")


def test_3_20_to_04() -> None:
    result = calculate_day(row(date(2026, 7, 20), "20:00", "04:00", "23:00", "00:00"))
    assert result.worked_minutes == 420
    assert result.late_night_minutes == 300
    money(result.total_pay_exact, "10312.50")


def test_4_2130_to_04() -> None:
    result = calculate_day(row(date(2026, 7, 20), "21:30", "04:00", "23:00", "00:00"))
    assert result.worked_minutes == 330
    assert result.late_night_minutes == 300
    money(result.total_pay_exact, "8437.50")


def test_5_23_to_07() -> None:
    result = calculate_day(row(date(2026, 7, 20), "23:00", "07:00", "03:00", "04:00"))
    assert result.worked_minutes == 420
    assert result.late_night_minutes == 300
    money(result.total_pay_exact, "10312.50")


def test_weekday_19_to_08_matches_shift_timeline() -> None:
    result = calculate_day(
        row(date(2026, 7, 20), "19:00", "08:00", "23:00", "00:00")
    )
    assert result.worked_minutes == 720
    assert result.regular_minutes == 480
    assert result.daily_overtime_minutes == 240
    assert result.late_night_minutes == 360
    assert result.holiday_minutes == 0
    money(result.base_pay, "15000.00")
    money(result.overtime_premium_pay, "1250.00")
    money(result.late_night_pay, "1875.00")
    money(result.total_pay_exact, "18125.00")
    minutes_by_rate: dict[Decimal, int] = {}
    for segment in result.segments:
        minutes_by_rate[segment.effective_percentage] = (
            minutes_by_rate.get(segment.effective_percentage, 0)
            + segment.paid_minutes
        )
    assert minutes_by_rate == {
        Decimal("100.00"): 180,
        Decimal("125.00"): 480,
        Decimal("150.00"): 60,
    }
