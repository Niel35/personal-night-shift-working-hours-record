from PySide6.QtWidgets import QApplication

from app.theme_toggle import ThemeToggle


def test_theme_toggle_has_stable_sizes_and_accessibility():
    app = QApplication.instance() or QApplication([])
    toggle = ThemeToggle()
    compact = ThemeToggle(compact=True)

    assert toggle.size().width() == 94
    assert toggle.size().height() == 42
    assert compact.size().width() == 76
    assert compact.size().height() == 34
    assert toggle.isCheckable()
    assert "Day Mode" in toggle.toolTip()


def test_theme_toggle_tracks_checked_state():
    app = QApplication.instance() or QApplication([])
    toggle = ThemeToggle()
    toggle.set_mode(True)
    assert toggle.isChecked()
    assert toggle.position == 1.0
