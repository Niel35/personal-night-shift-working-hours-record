from __future__ import annotations

import sys

from PySide6.QtCore import QEvent
from PySide6.QtWidgets import QApplication, QLabel

from app.popup_guard import PopupGuard, install_popup_guard


def app() -> QApplication:
    return QApplication.instance() or QApplication(sys.argv)


def test_popup_guard_is_installed_only_once() -> None:
    qt_app = app()
    first = install_popup_guard(qt_app)
    second = install_popup_guard(qt_app)

    assert isinstance(first, PopupGuard)
    assert second is first
    assert qt_app.property("popupGuard") is first


def test_popup_guard_blocks_all_qt_help_popup_events() -> None:
    qt_app = app()
    install_popup_guard(qt_app)
    widget = QLabel("Hover target")
    widget.setToolTip("This must never appear")

    for event_type in (QEvent.ToolTip, QEvent.WhatsThis, QEvent.QueryWhatsThis):
        event = QEvent(event_type)
        assert QApplication.sendEvent(widget, event)
        assert event.isAccepted()
