from __future__ import annotations

from calculations.models import (
    NON_STATUTORY_HOLIDAY,
    STATUTORY_HOLIDAY,
    WORK_DAY,
)
from database.database import TimesheetDatabase


def test_contract_weekly_schedule_cannot_be_overridden_by_stale_preferences(tmp_path) -> None:
    database = TimesheetDatabase(tmp_path / "schedule.db")
    settings = database.settings()

    assert settings.weekly_day_types == (
        WORK_DAY,
        WORK_DAY,
        WORK_DAY,
        WORK_DAY,
        WORK_DAY,
        NON_STATUTORY_HOLIDAY,
        NON_STATUTORY_HOLIDAY,
    )

    database.conn.execute(
        "INSERT OR REPLACE INTO app_preferences (key,value) VALUES (?,?)",
        (
            "weekly_day_types",
            '["Statutory Holiday", "Statutory Holiday", "Statutory Holiday", '
            '"Statutory Holiday", "Statutory Holiday", "Statutory Holiday", '
            '"Statutory Holiday"]',
        ),
    )
    database.conn.commit()

    assert database.settings().weekly_day_types == (
        WORK_DAY,
        WORK_DAY,
        WORK_DAY,
        WORK_DAY,
        WORK_DAY,
        NON_STATUTORY_HOLIDAY,
        NON_STATUTORY_HOLIDAY,
    )
