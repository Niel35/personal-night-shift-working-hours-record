from __future__ import annotations

from datetime import date

from calculations.salary_engine import calculate_day
from tests.test_daily_calculations import row


def test_late_night_overlaps_daily_overtime() -> None:
    result = calculate_day(row(date(2026, 7, 20), "18:00", "04:00", "23:00", "00:00"))
    assert result.segments[-1].classification == "Overtime + Late Night"
