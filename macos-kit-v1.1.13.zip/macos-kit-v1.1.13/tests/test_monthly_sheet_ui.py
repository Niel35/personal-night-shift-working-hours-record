import sys
from datetime import date, time
from decimal import Decimal

from PySide6.QtWidgets import QApplication

from app.main_window import MainWindow
from app.monthly_sheet import FORMULA_FONT_SAFETY_REDUCTION_PT, MonthlySheet
from calculations.models import BreakInterval, ContractSettings, DailyInput
from database.database import TimesheetDatabase


def app():
    return QApplication.instance() or QApplication(sys.argv)


def test_calculated_columns_share_a_font_size_that_fits_complete_formulas():
    app()
    sheet = MonthlySheet()
    row = DailyInput(
        work_date=date(2026, 7, 20),
        status="Work",
        actual_in=time(19, 0),
        actual_out=time(8, 0),
        total_break_hours=Decimal("1"),
    )
    sheet.build_month(2026, 7, [row], ContractSettings())

    delegates = [sheet.table.itemDelegateForColumn(column) for column in range(7, 14)]
    delegate = delegates[0]
    fitted_size = delegate._shared_point_size(sheet.table, sheet.table.font())

    assert all(candidate is delegate for candidate in delegates)
    assert delegate.safety_reduction == FORMULA_FONT_SAFETY_REDUCTION_PT == 0.5
    assert 5.5 <= fitted_size <= sheet.table.font().pointSizeF()


def test_calculated_row_preserves_user_notes():
    app()
    sheet = MonthlySheet()
    row = DailyInput(
        work_date=date(2026, 7, 1),
        status="Work",
        actual_in=time(18, 0),
        actual_out=time(4, 0),
        total_break_hours=1,
        notes="Bring badge tomorrow.",
    )

    sheet.build_month(2026, 7, [row], ContractSettings())

    assert sheet.table.item(0, 14).text() == "Bring badge tomorrow."


def test_overnight_row_displays_auditable_pay_breakdown():
    app()
    sheet = MonthlySheet()
    row = DailyInput(
        work_date=date(2026, 7, 20),
        status="Work",
        actual_in=time(19, 0),
        actual_out=time(8, 0),
        total_break_hours=Decimal("1"),
    )

    sheet.build_month(2026, 7, [row], ContractSettings())
    table_row = 19

    assert sheet.table.horizontalHeaderItem(7).text() == "Base Rate"
    assert sheet.table.horizontalHeaderItem(8).text() == "Base Pay\n100%"
    assert sheet.table.horizontalHeaderItem(9).text() == "Night Premium\n+25%"
    assert sheet.table.horizontalHeaderItem(10).text() == "Over Time\nPremium +25%"
    assert sheet.table.horizontalHeaderItem(11).text() == "Weekends\n+50 円"
    assert sheet.table.horizontalHeaderItem(12).text() == "Statutory Holiday\n+35%"
    assert sheet.table.horizontalHeaderItem(13).text() == "Daily Total"
    assert sheet.table.item(table_row, 7).text() == "1,250 円"
    assert sheet.table.item(table_row, 8).text() == "12hr 00min\n1,250 x 12 = 15,000 円"
    assert sheet.table.item(table_row, 9).text() == "6hr 00min\n312.50 x 6 = 1,875 円"
    assert sheet.table.item(table_row, 10).text() == "4hr 00min\n312.50 x 4 = 1,250 円"
    assert sheet.table.item(table_row, 11).text() == "—"
    assert sheet.table.item(table_row, 12).text() == "—"
    assert sheet.table.item(table_row, 13).text() == "18,125.00 円"


def test_weekend_rows_show_and_derive_explicit_work_modes():
    app()
    sheet = MonthlySheet()
    saved = [
        DailyInput(work_date=date(2026, 7, 25), status="Work"),
        DailyInput(work_date=date(2026, 7, 26), status="Work"),
    ]

    sheet.build_month(2026, 7, saved, ContractSettings())

    assert sheet.combo(24, 0) == "Saturday Work"
    assert sheet.combo(25, 0) == "Sunday Work"
    assert sheet.combo_widget(24, 0).toolTip() == ""
    assert sheet.combo_widget(25, 0).toolTip() == ""
    assert sheet.table.item(24, 1).toolTip() == ""
    assert sheet.table.item(24, 2).toolTip() == ""

    sheet.combo_widget(24, 0).setCurrentText("")
    sheet.table.item(24, 3).setText("19:00")
    sheet.table.item(24, 4).setText("08:00")
    assert sheet.daily_input(2026, 7, 25).status == "Saturday Work"

    sheet.combo_widget(25, 0).setCurrentText("")
    sheet.table.item(25, 3).setText("19:00")
    sheet.table.item(25, 4).setText("08:00")
    assert sheet.daily_input(2026, 7, 26).status == "Sunday Work"


def test_saturday_row_displays_separate_weekend_allowance_and_base_premiums():
    app()
    sheet = MonthlySheet()
    row = DailyInput(
        work_date=date(2026, 7, 25),
        status="Saturday Work",
        actual_in=time(19, 0),
        actual_out=time(8, 0),
        total_break_hours=Decimal("1"),
    )

    sheet.build_month(2026, 7, [row], ContractSettings())
    table_row = 24

    assert sheet.table.item(table_row, 7).text() == "1,250 円"
    assert sheet.table.item(table_row, 8).text() == "12hr 00min\n1,250 x 12 = 15,000 円"
    assert sheet.table.item(table_row, 9).text() == "6hr 00min\n312.50 x 6 = 1,875 円"
    assert sheet.table.item(table_row, 10).text() == "4hr 00min\n312.50 x 4 = 1,250 円"
    assert sheet.table.item(table_row, 11).text() == "12hr 00min\n50 x 12 = 600 円"
    assert sheet.table.item(table_row, 12).text() == "—"
    assert sheet.table.item(table_row, 13).text() == "18,725.00 円"
    assert sheet.summary_values["Weekend +50 円/hr"].text() == "12hr 00min\n600.00 円"


def test_weekend_and_holiday_columns_are_derived_without_database_fields(tmp_path):
    app()
    sheet = MonthlySheet()
    headers = [sheet.table.horizontalHeaderItem(col).text() for col in range(sheet.table.columnCount())]

    assert sheet.table.columnCount() == 17
    assert "Weekends\n+50 円" in headers
    assert "Statutory Holiday\n+35%" in headers
    assert "Weekend Base +50円/hr" not in sheet.summary_values

    database = TimesheetDatabase(tmp_path / "no-weekend-adjustment.db")
    columns = {
        row["name"]
        for row in database.conn.execute("PRAGMA table_info(work_records)").fetchall()
    }
    assert "saturday_allowance" not in columns
    assert "holiday_minutes" not in columns


def test_pay_cells_show_decimal_hour_formulas():
    app()
    sheet = MonthlySheet()
    row = DailyInput(
        work_date=date(2026, 7, 1),
        status="Work",
        actual_in=time(23, 30),
        actual_out=time(9, 30),
        total_break_hours=Decimal("1"),
    )

    sheet.build_month(2026, 7, [row], ContractSettings())

    assert sheet.table.item(0, 8).text() == "9hr 00min\n1,250 x 9 = 11,250 円"
    assert sheet.table.item(0, 9).text() == "4hr 30min\n312.50 x 4.5 = 1,406.25 円"
    assert sheet.table.item(0, 10).text() == "1hr 00min\n312.50 x 1 = 312.50 円"


def test_unused_calculation_cells_stay_visually_empty():
    app()
    sheet = MonthlySheet()
    day_shift = DailyInput(
        work_date=date(2026, 7, 1),
        status="Work",
        actual_in=time(9, 0),
        actual_out=time(17, 0),
        total_break_hours=Decimal("1"),
    )

    sheet.build_month(2026, 7, [day_shift], ContractSettings())

    assert sheet.table.item(0, 6).text() == "7 hr  00 min"
    assert sheet.table.item(0, 8).text()
    assert sheet.table.item(0, 9).text() == "—"
    assert sheet.table.item(0, 10).text() == "—"
    assert sheet.table.item(0, 11).text() == "—"
    assert sheet.table.item(0, 12).text() == "—"
    assert sheet.table.item(0, 13).text()
    for column in range(5, 14):
        assert sheet.table.item(1, column).text() == ""


def test_selected_status_uses_dashes_for_missing_times():
    app()
    sheet = MonthlySheet()
    leave = DailyInput(work_date=date(2026, 7, 1), status="Paid Leave")

    sheet.build_month(2026, 7, [leave], ContractSettings())

    assert sheet.table.item(0, 3).text() == "—"
    assert sheet.table.item(0, 4).text() == "—"
    assert sheet.parse_user_time("—") is None
    assert sheet.parse_user_time("–") is None
    assert sheet.parse_user_time("-") is None
    assert sheet.table.item(1, 3).text() == ""
    assert sheet.table.item(1, 4).text() == ""


def test_reopening_input_cell_replaces_text_without_visual_duplication():
    app()
    sheet = MonthlySheet()
    sheet.build_month(2026, 7, [], ContractSettings())
    sheet.table.item(0, 3).setText("20:00")
    index = sheet.table.model().index(0, 3)
    delegate = sheet.table.itemDelegateForColumn(3)

    first_editor = delegate.createEditor(sheet.table.viewport(), None, index)
    delegate.setEditorData(first_editor, index)
    assert first_editor.text() == "20:00"
    assert first_editor.selectedText() == "20:00"
    assert "background:#ffffff" in first_editor.styleSheet()

    first_editor.setText("21:15")
    delegate.setModelData(first_editor, sheet.table.model(), index)
    second_editor = delegate.createEditor(sheet.table.viewport(), None, index)
    delegate.setEditorData(second_editor, index)

    assert sheet.table.item(0, 3).text() == "21:15"
    assert second_editor.text() == "21:15"
    assert second_editor.selectedText() == "21:15"


def test_holiday_work_displays_effective_statutory_base_rate():
    app()
    sheet = MonthlySheet()
    holiday = DailyInput(
        work_date=date(2026, 7, 20),
        status="Holiday Work",
        actual_in=time(9, 0),
        actual_out=time(18, 0),
        total_break_hours=Decimal("1"),
    )

    sheet.build_month(2026, 7, [holiday], ContractSettings())

    assert sheet.table.item(19, 7).text() == "1,250 円"
    assert sheet.table.item(19, 8).text() == "8hr 00min\n1,250 x 8 = 10,000 円"
    assert sheet.table.item(19, 11).text() == "—"
    assert sheet.table.item(19, 12).text() == "8hr 00min\n437.50 x 8 = 3,500 円"
    assert sheet.table.item(19, 13).text() == "13,500.00 円"


def test_clearing_note_only_row_deletes_saved_note(tmp_path):
    app()
    window = MainWindow(TimesheetDatabase(tmp_path / "timesheet.db"))
    window.sheet.record_month.setDate(date(2026, 7, 1))
    window.load_month()

    window.sheet.table.item(0, 14).setText("ascjsdvkdsjvf")
    window.autosave_row(0)
    assert window.db.records_for_month(2026, 7)[0].notes == "ascjsdvkdsjvf"

    window.sheet.table.item(0, 14).setText("")
    window.autosave_row(0)
    window.load_month()

    assert window.db.records_for_month(2026, 7) == []
    assert window.sheet.table.item(0, 14).text() == ""
