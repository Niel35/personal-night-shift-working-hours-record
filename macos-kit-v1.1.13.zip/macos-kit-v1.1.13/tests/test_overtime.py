from __future__ import annotations

from datetime import date, time

from calculations.models import DailyInput
from calculations.salary_engine import calculate_day


def test_weekly_overtime_beyond_40_without_double_counting() -> None:
    result = calculate_day(
        DailyInput(date(2026, 7, 24), "Work", actual_in=time(9, 0), actual_out=time(17, 0)),
        prior_week_worked_minutes=39 * 60,
    )
    assert result.weekly_overtime_minutes == 7 * 60
    assert result.daily_overtime_minutes == 0
