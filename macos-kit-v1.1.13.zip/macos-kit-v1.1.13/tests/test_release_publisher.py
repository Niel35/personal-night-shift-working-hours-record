import json
import zipfile

from app import release_publisher
from app.app_info import APP_VERSION


def test_create_release_package_writes_zip_and_manifest(tmp_path, monkeypatch):
    source = tmp_path / "dist" / "PersonalNightShiftWorkingHoursRecord"
    internal = source / "_internal"
    internal.mkdir(parents=True)
    (source / "PersonalNightShiftWorkingHoursRecord.exe").write_text("exe", encoding="utf-8")
    (internal / "resource.txt").write_text("resource", encoding="utf-8")

    monkeypatch.setattr(release_publisher, "app_distribution_dir", lambda: source)

    package = release_publisher.create_release_package("Better fit on smaller screens.", tmp_path / "releases")

    assert package.zip_path.exists()
    assert package.manifest_path.exists()
    assert package.sha256

    manifest = json.loads(package.manifest_path.read_text(encoding="utf-8"))
    assert manifest["latest_version"] == APP_VERSION
    assert manifest["download_url"].endswith(f"PersonalNightShiftWorkingHoursRecord-{APP_VERSION}.zip")
    assert manifest["sha256"] == package.sha256
    assert manifest["downloads"]["windows"]["download_url"].endswith(f"PersonalNightShiftWorkingHoursRecord-{APP_VERSION}.zip")
    assert manifest["downloads"]["windows"]["sha256"] == package.sha256
    assert manifest["release_notes"] == "Better fit on smaller screens."

    with zipfile.ZipFile(package.zip_path) as archive:
        names = set(archive.namelist())
    assert "PersonalNightShiftWorkingHoursRecord/PersonalNightShiftWorkingHoursRecord.exe" in names
    assert "PersonalNightShiftWorkingHoursRecord/_internal/resource.txt" in names
    assert "PersonalNightShiftWorkingHoursRecord/_internal/resources/user_edition.flag" in names
