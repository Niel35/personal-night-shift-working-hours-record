from PySide6.QtWidgets import QApplication, QLabel, QWidget

from app.styles import APP_STYLESHEET
from app.theme import apply_theme, dark_stylesheet


def test_dark_stylesheet_converts_backgrounds_and_text_colors():
    themed = dark_stylesheet("background:#ffffff; color:#102033; border:1px solid #c8d9e8;")
    assert "background:#172431" in themed
    assert "color:#edf6ff" in themed
    assert "#395368" in themed


def test_dark_text_color_does_not_change_the_same_header_background():
    themed = dark_stylesheet("background:#0b3158; color:#0b3158;")
    assert "background:#0b3158" in themed
    assert "color:#e6f2ff" in themed


def test_theme_round_trip_restores_widget_styles():
    app = QApplication.instance() or QApplication([])
    root = QWidget()
    label = QLabel("Example", root)
    day_style = "background:#e8f3fd; color:#102033; border:1px solid #c8d9e8;"
    label.setStyleSheet(day_style)

    apply_theme(root, True, APP_STYLESHEET)
    assert "#1a3449" in label.styleSheet()
    assert "#edf6ff" in label.styleSheet()

    apply_theme(root, False, APP_STYLESHEET)
    assert label.styleSheet() == day_style
    root.close()
