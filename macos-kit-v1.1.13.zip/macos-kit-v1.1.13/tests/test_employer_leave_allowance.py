from __future__ import annotations

from datetime import date

from calculations.models import DailyInput
from calculations.salary_engine import calculate_day, summarize_month


def test_employer_leave_allowance_pays_sixty_percent_standard_day() -> None:
    result = calculate_day(DailyInput(date(2026, 7, 22), status="Employer Leave"))

    assert result.worked_minutes == 0
    assert result.employer_leave_allowance == 6000
    assert result.total_pay_exact == 6000
    assert result.total_pay_display == 6000


def test_employer_leave_allowance_counts_in_monthly_estimated_pay() -> None:
    _rows, totals = summarize_month(
        [
            DailyInput(date(2026, 7, 22), status="Employer Leave 60%"),
            DailyInput(date(2026, 7, 23), status="Absent"),
        ]
    )

    assert totals.worked_minutes == 0
    assert totals.workdays == 0
    assert totals.employer_leave_days == 1
    assert totals.employer_leave_allowance == 6000
    assert totals.total_pay == 6000
