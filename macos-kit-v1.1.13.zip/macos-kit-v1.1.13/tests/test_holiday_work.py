from __future__ import annotations

from datetime import date

from calculations.models import ContractSettings

from calculations.salary_engine import calculate_day, summarize_month
from database.database import TimesheetDatabase
from tests.test_daily_calculations import money, row


def test_7_holiday_work() -> None:
    result = calculate_day(row(date(2026, 7, 20), "23:00", "07:00", "03:00", "04:00", "Holiday Work"))
    assert result.worked_minutes == 420
    assert result.overtime_minutes == 0
    assert result.holiday_minutes == 420
    assert result.late_night_minutes == 300
    money(result.base_pay, "8750.00")
    money(result.holiday_premium_pay, "3062.50")
    money(result.late_night_pay, "1562.50")
    money(result.total_pay_exact, "13375.00")
    money(result.premium_pay, "4625.00")


def test_seventh_consecutive_workday_becomes_statutory_holiday() -> None:
    inputs = [
        row(date(2026, 7, 20 + offset), "09:00", "18:00", "12:00", "13:00", "Work")
        for offset in range(7)
    ]
    results, totals = summarize_month(inputs, ContractSettings())

    assert all(result.holiday_minutes == 0 for _row, result in results[:6])
    seventh = results[6][1]
    assert seventh.holiday_minutes == 480
    assert seventh.overtime_minutes == 0
    assert seventh.saturday_minutes == 0
    money(seventh.holiday_premium_pay, "3500.00")
    money(seventh.base_pay, "10000.00")
    assert totals.holiday_work_days == 1


def test_non_statutory_rest_day_does_not_receive_holiday_premium() -> None:
    result = calculate_day(
        row(date(2026, 7, 25), "09:00", "17:00", "12:00", "13:00", "Work"),
        ContractSettings(),
    )

    assert result.holiday_minutes == 0
    money(result.holiday_premium_pay, "0.00")


def test_non_statutory_rest_day_uses_normal_overtime_rules() -> None:
    result = calculate_day(
        row(
            date(2026, 7, 25),
            "09:00",
            "19:00",
            "12:00",
            "13:00",
            "Saturday Work",
        ),
        ContractSettings(),
    )

    assert result.worked_minutes == 540
    assert result.holiday_minutes == 0
    assert result.overtime_minutes == 60
    money(result.holiday_premium_pay, "0.00")
    money(result.overtime_premium_pay, "312.50")
    assert any(
        segment.classification == "Non-Statutory Holiday Overtime"
        for segment in result.segments
    )


def test_statutory_holiday_replaces_weekend_bonus_and_daily_overtime() -> None:
    result = calculate_day(
        row(
            date(2026, 7, 26),
            "19:00",
            "07:00",
            "23:00",
            "00:00",
            "Sunday Work",
        ),
        ContractSettings(),
        force_statutory_holiday=True,
    )

    assert result.worked_minutes == 660
    assert result.holiday_minutes == 660
    assert result.overtime_minutes == 0
    assert result.saturday_minutes == 0
    money(result.overtime_premium_pay, "0.00")
    money(result.holiday_premium_pay, "4812.50")
    money(result.late_night_pay, "1875.00")
    money(result.total_pay_display, "20438.00")
    assert not any(segment.is_overtime for segment in result.segments)


def test_seventh_day_is_detected_across_a_month_boundary(tmp_path) -> None:
    database = TimesheetDatabase(tmp_path / "cross-month.db")
    for day in range(27, 32):
        database.upsert_record(
            row(date(2026, 7, day), "09:00", "18:00", "12:00", "13:00", "Work")
        )
    database.upsert_record(
        row(date(2026, 8, 1), "09:00", "18:00", "12:00", "13:00", "Saturday Work")
    )
    database.upsert_record(
        row(date(2026, 8, 2), "19:00", "07:00", "23:00", "00:00", "Sunday Work")
    )

    results, _totals = database.monthly_results(2026, 8)
    saturday = next(result for item, result in results if item.work_date.day == 1)
    sunday = next(result for item, result in results if item.work_date.day == 2)

    assert saturday.holiday_minutes == 0
    assert saturday.saturday_minutes == 480
    assert sunday.holiday_minutes == 660
    assert sunday.saturday_minutes == 0
    assert sunday.overtime_minutes == 0
    money(sunday.holiday_premium_pay, "4812.50")
    money(sunday.late_night_pay, "1875.00")
