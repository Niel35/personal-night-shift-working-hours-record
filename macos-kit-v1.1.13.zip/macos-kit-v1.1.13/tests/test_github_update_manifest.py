from pathlib import Path
import importlib.util


MODULE_PATH = Path(__file__).resolve().parents[1] / "packaging" / "create_github_update_manifest.py"
spec = importlib.util.spec_from_file_location("create_github_update_manifest", MODULE_PATH)
github_manifest = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(github_manifest)


def test_github_update_manifest_contains_platform_urls(tmp_path: Path) -> None:
    windows_zip = tmp_path / "PersonalNightShiftWorkingHoursRecord-1.1.1.zip"
    macos_zip = tmp_path / "PersonalNightShiftWorkingHoursRecord-macOS-1.1.1.zip"
    windows_zip.write_text("windows", encoding="utf-8")
    macos_zip.write_text("macos", encoding="utf-8")

    manifest = github_manifest.build_manifest("rhyniel", "night-shift-record", "1.1.1", windows_zip, macos_zip, "Update notes")

    assert manifest["downloads"]["windows"]["download_url"] == (
        "https://github.com/rhyniel/night-shift-record/releases/download/v1.1.1/"
        "PersonalNightShiftWorkingHoursRecord-1.1.1.zip"
    )
    assert manifest["downloads"]["macos"]["download_url"] == (
        "https://github.com/rhyniel/night-shift-record/releases/download/v1.1.1/"
        "PersonalNightShiftWorkingHoursRecord-macOS-1.1.1.zip"
    )
    assert manifest["release_notes"] == "Update notes"
