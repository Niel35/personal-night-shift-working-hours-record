from __future__ import annotations

from datetime import date, time
from decimal import Decimal

from tests.test_daily_calculations import money, row
from calculations.models import ContractSettings, DailyInput
from calculations.salary_engine import calculate_day


def test_saturday_shift_keeps_starting_day_classification() -> None:
    result = calculate_day(
        row(
            date(2026, 7, 25),
            "19:00",
            "04:00",
            "23:00",
            "00:00",
            status="Saturday Work",
        )
    )
    assert result.saturday_minutes == 480
    assert result.holiday_minutes == 0
    assert result.overtime_minutes == 0
    money(result.base_pay, "10000.00")
    money(result.late_night_pay, "1562.50")
    money(result.total_pay_exact, "11962.50")


def test_normal_sunday_shift_keeps_weekend_classification_after_midnight() -> None:
    result = calculate_day(row(date(2026, 7, 26), "19:00", "04:00", "23:00", "00:00"))
    assert result.saturday_minutes == 480
    assert result.holiday_minutes == 0
    money(result.base_pay, "10000.00")
    money(result.late_night_pay, "1562.50")
    money(result.total_pay_exact, "11962.50")


def test_saturday_19_to_sunday_08_uses_saturday_overtime_rules() -> None:
    settings = ContractSettings(saturday_allowance_per_hour=Decimal("0"))
    result = calculate_day(
        DailyInput(
            work_date=date(2026, 7, 25),
            status="Work",
            actual_in=time(19, 0),
            actual_out=time(8, 0),
            total_break_hours=Decimal("1"),
        ),
        settings,
    )

    assert result.break_minutes == 60
    assert result.worked_minutes == 720
    assert result.overtime_minutes == 240
    assert result.late_night_minutes == 360
    assert result.holiday_minutes == 0
    money(result.base_pay, "15000.00")
    money(result.late_night_pay, "1875.00")
    money(result.overtime_premium_pay, "1250.00")
    money(result.holiday_premium_pay, "0.00")
    money(result.total_pay_exact, "18125.00")
    money(result.total_pay_display, "18125.00")

    minutes_by_rate: dict[Decimal, int] = {}
    for segment in result.segments:
        minutes_by_rate[segment.effective_percentage] = (
            minutes_by_rate.get(segment.effective_percentage, 0)
            + segment.paid_minutes
        )
    assert minutes_by_rate == {
        Decimal("100.00"): 180,
        Decimal("125.00"): 480,
        Decimal("150.00"): 60,
    }


def test_weekend_allowance_is_separate_from_legal_premium_base() -> None:
    result = calculate_day(
        DailyInput(
            work_date=date(2026, 7, 25),
            status="Saturday Work",
            actual_in=time(19, 0),
            actual_out=time(8, 0),
            total_break_hours=Decimal("1"),
        ),
        ContractSettings(),
    )

    money(result.base_pay, "15000.00")
    money(result.late_night_pay, "1875.00")
    money(result.overtime_premium_pay, "1250.00")
    money(result.holiday_premium_pay, "0.00")
    money(result.total_pay_exact, "18725.00")
    money(result.total_pay_display, "18725.00")

    # Base, legal premiums, and the fixed weekend allowance reconcile.
    money(
        result.base_pay
        + result.overtime_premium_pay
        + result.late_night_pay
        + Decimal(result.saturday_minutes) / Decimal("60") * Decimal("50"),
        "18725.00",
    )

    hourly_by_rate = {
        (segment.effective_percentage, segment.hourly_amount)
        for segment in result.segments
    }
    assert hourly_by_rate == {
        (Decimal("100.00"), Decimal("1300.00")),
        (Decimal("125.00"), Decimal("1612.5000")),
        (Decimal("150.00"), Decimal("1925.0000")),
    }


def test_sunday_work_keeps_weekend_adjustment_until_clock_out() -> None:
    result = calculate_day(
        DailyInput(
            work_date=date(2026, 7, 26),
            status="Sunday Work",
            actual_in=time(19, 0),
            actual_out=time(4, 0),
            total_break_hours=Decimal("1"),
        ),
        ContractSettings(),
    )

    assert result.worked_minutes == 480
    assert result.saturday_minutes == 480
    money(result.base_pay, "10000.00")
    sunday_segments = [segment for segment in result.segments if segment.start.weekday() == 6]
    assert all(segment.hourly_amount >= Decimal("1300") for segment in sunday_segments)
    assert all(segment.hourly_amount >= Decimal("1300") for segment in result.segments)


def test_friday_shift_keeps_weekday_rate_after_midnight() -> None:
    result = calculate_day(
        DailyInput(
            work_date=date(2026, 7, 24),
            status="Work",
            actual_in=time(22, 0),
            actual_out=time(2, 0),
        ),
        ContractSettings(),
    )

    assert result.saturday_minutes == 0
