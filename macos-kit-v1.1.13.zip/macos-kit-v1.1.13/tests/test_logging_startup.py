from __future__ import annotations

import logging
from pathlib import Path

import main


def test_configure_logging_falls_back_when_primary_log_is_denied(tmp_path, monkeypatch) -> None:
    primary_dir = tmp_path / "primary" / "logs"
    fallback_dir = tmp_path / "fallback" / "logs"
    primary_log = primary_dir / "app.log"
    fallback_log = fallback_dir / "app.log"
    original_file_handler = logging.FileHandler

    def file_handler(path, *args, **kwargs):
        if Path(path) == primary_log:
            raise PermissionError("denied")
        return original_file_handler(path, *args, **kwargs)

    monkeypatch.setattr(main, "app_log_dir", lambda: primary_dir)
    monkeypatch.setattr(main, "fallback_log_dir", lambda: fallback_dir)
    monkeypatch.setattr(logging, "FileHandler", file_handler)

    assert main.configure_logging() == fallback_log
    logging.getLogger(__name__).info("fallback log is writable")
    for handler in logging.getLogger().handlers:
        handler.flush()

    assert "fallback log is writable" in fallback_log.read_text(encoding="utf-8")
