@echo off
setlocal
cd /d "%~dp0"
python -m pip install -r requirements.txt
python -m pytest
python -m PyInstaller night_shift_salary_recorder.spec --clean --noconfirm --distpath "%USERPROFILE%\Documents\Codex\PNSWHR_User_v1.1.13" --workpath "%TEMP%\PNSWHR_build_v1.1.13"
echo.
echo Build complete. Check %USERPROFILE%\Documents\Codex\PNSWHR_User_v1.1.13\PersonalNightShiftWorkingHoursRecord
