from __future__ import annotations

from PySide6.QtCore import QEvent, QObject
from PySide6.QtWidgets import QApplication, QToolTip


class PopupGuard(QObject):
    """Suppress Qt help popups that can appear as black hover panels."""

    BLOCKED_EVENTS = {
        QEvent.ToolTip,
        QEvent.WhatsThis,
        QEvent.QueryWhatsThis,
    }

    def eventFilter(self, watched, event) -> bool:
        if event.type() in self.BLOCKED_EVENTS:
            QToolTip.hideText()
            event.accept()
            return True
        return super().eventFilter(watched, event)


def install_popup_guard(app: QApplication) -> PopupGuard:
    existing = app.property("popupGuard")
    if isinstance(existing, PopupGuard):
        return existing

    guard = PopupGuard(app)
    app.installEventFilter(guard)
    app.setProperty("popupGuard", guard)
    QToolTip.hideText()
    return guard
