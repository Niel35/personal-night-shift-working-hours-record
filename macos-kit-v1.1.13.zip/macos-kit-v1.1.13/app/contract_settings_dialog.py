from __future__ import annotations

from dataclasses import asdict
from datetime import time
from decimal import Decimal

from PySide6.QtCore import QTime
from PySide6.QtWidgets import QCheckBox, QComboBox, QDialog, QFormLayout, QHBoxLayout, QLineEdit, QPushButton, QTimeEdit, QVBoxLayout

from calculations.models import ContractSettings


class ContractSettingsDialog(QDialog):
    def __init__(self, settings: ContractSettings, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Contract Settings")
        self.fields: dict[str, object] = {}
        layout = QVBoxLayout(self)
        form = QFormLayout()
        for key, label in [
            ("base_hourly_wage", "Base hourly wage"),
            ("standard_daily_hours", "Standard daily hours"),
            ("standard_weekly_hours", "Standard weekly hours"),
            ("overtime_premium", "Normal overtime premium"),
            ("late_night_premium", "Late-night premium"),
            ("holiday_premium", "Legal-holiday premium"),
            ("over_60_total_premium", "Over-60 overtime premium"),
            ("monthly_overtime_warning", "Monthly overtime warning"),
            ("annual_overtime_limit", "Annual overtime limit"),
            ("saturday_allowance_per_hour", "Saturday base adjustment per hour"),
        ]:
            edit = QLineEdit(str(getattr(settings, key)))
            self.fields[key] = edit
            form.addRow(label, edit)
        for key, label in [("late_night_start", "Late-night start"), ("late_night_end", "Late-night end")]:
            edit = QTimeEdit(QTime(getattr(settings, key).hour, getattr(settings, key).minute))
            edit.setDisplayFormat("HH:mm")
            self.fields[key] = edit
            form.addRow(label, edit)
        week = QComboBox()
        week.addItems(["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"])
        week.setCurrentIndex(settings.payroll_week_start)
        self.fields["payroll_week_start"] = week
        form.addRow("Payroll week start day", week)
        rounding = QComboBox()
        rounding.addItems(["round_final_nearest_yen", "round_down", "round_up"])
        rounding.setCurrentText(settings.rounding_method)
        self.fields["rounding_method"] = rounding
        form.addRow("Salary rounding method", rounding)
        holiday_ot = QCheckBox("Apply overtime premium to Holiday Work")
        holiday_ot.setChecked(settings.apply_overtime_to_holiday_work)
        self.fields["apply_overtime_to_holiday_work"] = holiday_ot
        form.addRow("", holiday_ot)
        layout.addLayout(form)
        buttons = QHBoxLayout()
        ok = QPushButton("Save")
        cancel = QPushButton("Cancel")
        ok.clicked.connect(self.accept)
        cancel.clicked.connect(self.reject)
        buttons.addStretch()
        buttons.addWidget(ok)
        buttons.addWidget(cancel)
        layout.addLayout(buttons)

    def settings(self, current: ContractSettings) -> ContractSettings:
        data = asdict(current)
        for key, widget in self.fields.items():
            if isinstance(widget, QLineEdit):
                data[key] = Decimal(widget.text())
            elif isinstance(widget, QTimeEdit):
                data[key] = widget.time().toPython()
            elif isinstance(widget, QComboBox):
                data[key] = widget.currentIndex() if key == "payroll_week_start" else widget.currentText()
            elif isinstance(widget, QCheckBox):
                data[key] = widget.isChecked()
        return ContractSettings(**data)
