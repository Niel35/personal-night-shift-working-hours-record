from __future__ import annotations

import hashlib
import json
import sys
import zipfile
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from urllib.parse import urljoin

from .app_info import APP_NAME, APP_VERSION, UPDATE_MANIFEST_URL


class ReleaseError(RuntimeError):
    pass


@dataclass(frozen=True)
class ReleasePackage:
    folder: Path
    zip_path: Path
    manifest_path: Path
    download_url: str
    sha256: str


def default_release_root() -> Path:
    return Path.home() / "Documents" / "PersonalNightShiftWorkingHoursRecord" / "releases"


def app_distribution_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    project_root = Path(__file__).resolve().parents[1]
    dist_dir = project_root / "dist" / "PersonalNightShiftWorkingHoursRecord"
    if dist_dir.exists():
        return dist_dir
    return project_root


def inferred_download_url(filename: str) -> str:
    if UPDATE_MANIFEST_URL.startswith(("https://", "http://")):
        return urljoin(UPDATE_MANIFEST_URL.rsplit("/", 1)[0] + "/", filename)
    return f"https://your-update-server.example/{filename}"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def existing_manifest_downloads(manifest_path: Path) -> dict:
    if not manifest_path.exists():
        return {}
    try:
        data = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    downloads = data.get("downloads", {})
    return downloads if isinstance(downloads, dict) else {}


def create_release_package(release_notes: str = "", target_root: Path | None = None) -> ReleasePackage:
    source_dir = app_distribution_dir()
    exe_path = source_dir / "PersonalNightShiftWorkingHoursRecord.exe"
    if not exe_path.exists():
        raise ReleaseError(f"Could not find the built app executable in:\n{source_dir}")

    target_root = target_root or default_release_root()
    release_dir = target_root / f"v{APP_VERSION}"
    release_dir.mkdir(parents=True, exist_ok=True)

    zip_name = f"PersonalNightShiftWorkingHoursRecord-{APP_VERSION}.zip"
    zip_path = release_dir / zip_name
    manifest_path = release_dir / "update.json"

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(source_dir.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(source_dir.parent))
        archive.writestr(
            "PersonalNightShiftWorkingHoursRecord/_internal/resources/user_edition.flag",
            "",
        )

    file_hash = sha256_file(zip_path)
    download_url = inferred_download_url(zip_name)
    downloads = existing_manifest_downloads(manifest_path)
    downloads["windows"] = {
        "download_url": download_url,
        "sha256": file_hash,
        "filename": zip_name,
    }
    manifest = {
        "latest_version": APP_VERSION,
        "download_url": download_url,
        "published_at": date.today().isoformat(),
        "mandatory": False,
        "sha256": file_hash,
        "downloads": downloads,
        "release_notes": release_notes.strip() or f"{APP_NAME} {APP_VERSION} release.",
    }
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return ReleasePackage(release_dir, zip_path, manifest_path, download_url, file_hash)
