from __future__ import annotations

from PySide6.QtCore import QTime
from PySide6.QtWidgets import QDialog, QHBoxLayout, QLabel, QPushButton, QTimeEdit, QVBoxLayout, QWidget

from calculations.models import BreakInterval


class BreakRow(QWidget):
    def __init__(self, interval: BreakInterval | None = None) -> None:
        super().__init__()
        self.start = QTimeEdit()
        self.end = QTimeEdit()
        self.start.setDisplayFormat("HH:mm")
        self.end.setDisplayFormat("HH:mm")
        if interval:
            self.start.setTime(QTime(interval.start.hour, interval.start.minute))
            self.end.setTime(QTime(interval.end.hour, interval.end.minute))
        else:
            self.start.setTime(QTime(23, 0))
            self.end.setTime(QTime(0, 0))
        self.remove = QPushButton("Remove")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(QLabel("Break start"))
        layout.addWidget(self.start)
        layout.addWidget(QLabel("Break end"))
        layout.addWidget(self.end)
        layout.addWidget(self.remove)

    def interval(self) -> BreakInterval:
        return BreakInterval(self.start.time().toPython(), self.end.time().toPython())


class BreakEditorDialog(QDialog):
    def __init__(self, intervals: list[BreakInterval], parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Break Editor")
        self.rows = QVBoxLayout()
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Precise break intervals are preferred because timing affects late-night calculations."))
        layout.addLayout(self.rows)
        add = QPushButton("Add another break")
        add.clicked.connect(lambda: self.add_row())
        layout.addWidget(add)
        buttons = QHBoxLayout()
        save = QPushButton("Save breaks")
        cancel = QPushButton("Cancel")
        save.clicked.connect(self.accept)
        cancel.clicked.connect(self.reject)
        buttons.addStretch()
        buttons.addWidget(save)
        buttons.addWidget(cancel)
        layout.addLayout(buttons)
        for interval in intervals or [BreakInterval(__import__("datetime").time(23, 0), __import__("datetime").time(0, 0))]:
            self.add_row(interval)

    def add_row(self, interval: BreakInterval | None = None) -> None:
        row = BreakRow(interval)
        row.remove.clicked.connect(lambda: self.remove_row(row))
        self.rows.addWidget(row)

    def remove_row(self, row: BreakRow) -> None:
        row.setParent(None)
        row.deleteLater()

    def intervals(self) -> list[BreakInterval]:
        return [self.rows.itemAt(i).widget().interval() for i in range(self.rows.count()) if isinstance(self.rows.itemAt(i).widget(), BreakRow)]
