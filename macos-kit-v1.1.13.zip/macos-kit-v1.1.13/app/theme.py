from __future__ import annotations

import re
from functools import lru_cache

from PySide6.QtCore import QSignalBlocker, Qt
from PySide6.QtGui import QColor, QBrush
from PySide6.QtWidgets import QTableWidget, QWidget


_DARK_COLORS = {
    "#ffffff": "#172431",
    "#fbfdff": "#162330",
    "#f8fbff": "#172735",
    "#f8fafc": "#15212c",
    "#f5f9fc": "#172633",
    "#f2f8fd": "#182a39",
    "#f2f7fb": "#182936",
    "#eef5fb": "#192b3a",
    "#eef4fa": "#101923",
    "#eef3f8": "#172633",
    "#edf7ff": "#183047",
    "#edf6ff": "#183047",
    "#edf4fa": "#172735",
    "#eaf4fb": "#193044",
    "#e8f3fd": "#1a3449",
    "#e8f7ef": "#17382f",
    "#e5f2ff": "#19354b",
    "#def7e7": "#153a30",
    "#ddf7e8": "#153a30",
    "#dceeff": "#1b3b55",
    "#d7ecff": "#214863",
    "#cfe7ff": "#20445e",
    "#fff9e8": "#3b3520",
    "#fff6df": "#3d341f",
    "#fff6cf": "#3b351f",
    "#fff0f2": "#44262d",
    "#dbe7f1": "#294052",
    "#d5e3f0": "#314a5d",
    "#c9d7e5": "#3a5264",
    "#c8d9e8": "#395368",
    "#c7d6e4": "#3a5264",
    "#c6d3df": "#3a5060",
    "#c5d9ea": "#395368",
    "#c4d8ea": "#395368",
    "#bfd0df": "#3b5365",
    "#b9cce0": "#3b566c",
    "#b8cede": "#3b566c",
    "#9fd7b6": "#34705a",
    "#9fb5cc": "#466279",
    "#9eb8d3": "#557794",
    "#8fb2d4": "#4d7292",
    "#8fb0cc": "#4d708e",
}

_DARK_TEXT_COLORS = {
    "#102033": "#edf6ff",
    "#17324d": "#d9e9f7",
    "#18324b": "#d9e9f7",
    "#0b3158": "#e6f2ff",
    "#29445f": "#c9dced",
    "#48627d": "#a9c0d4",
    "#516376": "#a8bbcc",
    "#526779": "#a8bdcf",
    "#061a33": "#f4f8fc",
}

_COLOR_PATTERN = re.compile(r"#[0-9a-fA-F]{6}")
_ORIGINAL_STYLE_PROPERTY = "dayThemeStyleSheet"
_ITEM_BACKGROUND_ROLE = int(Qt.UserRole) + 70
_ITEM_FOREGROUND_ROLE = int(Qt.UserRole) + 71


@lru_cache(maxsize=512)
def dark_stylesheet(stylesheet: str) -> str:
    transformed = _COLOR_PATTERN.sub(
        lambda match: _DARK_COLORS.get(match.group(0).lower(), match.group(0)),
        stylesheet,
    )
    for source, target in _DARK_TEXT_COLORS.items():
        transformed = re.sub(
            rf"((?:^|[;{{])\s*(?:color|selection-color)\s*:\s*){re.escape(source)}\b",
            lambda match, replacement=target: match.group(1) + replacement,
            transformed,
            flags=re.IGNORECASE,
        )
    return transformed.replace("background: white", "background: #172431")


def _saved_color(item, role: int, brush: QBrush) -> str:
    saved = item.data(role)
    if saved is None:
        color = brush.color()
        saved = color.name(QColor.HexArgb)
        item.setData(role, saved)
    return str(saved)


def _apply_table_item_theme(table: QTableWidget, dark: bool) -> None:
    table.setUpdatesEnabled(False)
    model_blocker = QSignalBlocker(table.model())
    try:
        for row in range(table.rowCount()):
            for column in range(table.columnCount()):
                item = table.item(row, column)
                if item is None:
                    continue
                background = item.background()
                foreground = item.foreground()
                if background.style() != Qt.NoBrush:
                    original = QColor(_saved_color(item, _ITEM_BACKGROUND_ROLE, background))
                    color = QColor(_DARK_COLORS.get(original.name().lower(), original.name())) if dark else original
                    if background.color() != color:
                        item.setBackground(color)
                if foreground.style() != Qt.NoBrush:
                    original = QColor(_saved_color(item, _ITEM_FOREGROUND_ROLE, foreground))
                    color = QColor(_DARK_COLORS.get(original.name().lower(), original.name())) if dark else original
                    if foreground.color() != color:
                        item.setForeground(color)
    finally:
        del model_blocker
        table.setUpdatesEnabled(True)
        table.viewport().update()


def apply_theme(root: QWidget, dark: bool, base_stylesheet: str) -> None:
    root.setUpdatesEnabled(False)
    try:
        target_root_style = dark_stylesheet(base_stylesheet) if dark else base_stylesheet
        if root.styleSheet() != target_root_style:
            root.setStyleSheet(target_root_style)

        for widget in root.findChildren(QWidget):
            original = widget.property(_ORIGINAL_STYLE_PROPERTY)
            if original is None:
                original = widget.styleSheet()
                widget.setProperty(_ORIGINAL_STYLE_PROPERTY, original)

            # Empty styles inherit the root theme. Restyling those widgets one by
            # one forces hundreds of unnecessary Qt polish/layout passes.
            original_style = str(original)
            if original_style:
                target_style = dark_stylesheet(original_style) if dark else original_style
                if widget.styleSheet() != target_style:
                    widget.setStyleSheet(target_style)

            if isinstance(widget, QTableWidget):
                _apply_table_item_theme(widget, dark)
    finally:
        root.setUpdatesEnabled(True)
        root.update()
