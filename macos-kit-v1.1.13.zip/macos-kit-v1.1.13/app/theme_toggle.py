from __future__ import annotations

from PySide6.QtCore import Property, QEasingCurve, QPointF, QPropertyAnimation, QRectF, QSize, Qt
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QAbstractButton


class ThemeToggle(QAbstractButton):
    def __init__(self, compact: bool = False, parent=None) -> None:
        super().__init__(parent)
        self.setCheckable(True)
        self.setCursor(Qt.PointingHandCursor)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setAccessibleName("Night mode")
        self.setToolTip("Switch between Day Mode and Night Mode")
        self._compact = compact
        self._position = 0.0
        self._animation = QPropertyAnimation(self, b"position", self)
        self._animation.setDuration(170)
        self._animation.setEasingCurve(QEasingCurve.OutCubic)
        self.toggled.connect(self._animate)
        self.setFixedSize(76 if compact else 94, 34 if compact else 42)

    def sizeHint(self) -> QSize:
        return QSize(76 if self._compact else 94, 34 if self._compact else 42)

    def _get_position(self) -> float:
        return self._position

    def _set_position(self, value: float) -> None:
        self._position = max(0.0, min(1.0, value))
        self.update()

    position = Property(float, _get_position, _set_position)

    def _animate(self, checked: bool) -> None:
        self._animation.stop()
        self._animation.setStartValue(self._position)
        self._animation.setEndValue(1.0 if checked else 0.0)
        self._animation.start()

    def set_mode(self, checked: bool) -> None:
        self._animation.stop()
        self.blockSignals(True)
        self.setChecked(checked)
        self.blockSignals(False)
        self._set_position(1.0 if checked else 0.0)

    @staticmethod
    def _draw_sun(painter: QPainter, center: QPointF, radius: float, color: QColor) -> None:
        painter.save()
        painter.setPen(QPen(color, max(1.4, radius * 0.16), Qt.SolidLine, Qt.RoundCap))
        painter.setBrush(color)
        painter.drawEllipse(center, radius * 0.47, radius * 0.47)
        for dx, dy in ((0, -1), (1, 0), (0, 1), (-1, 0), (.7, -.7), (.7, .7), (-.7, .7), (-.7, -.7)):
            painter.drawLine(
                QPointF(center.x() + dx * radius * 0.68, center.y() + dy * radius * 0.68),
                QPointF(center.x() + dx * radius, center.y() + dy * radius),
            )
        painter.restore()

    @staticmethod
    def _draw_moon(painter: QPainter, center: QPointF, radius: float, color: QColor) -> None:
        outer = QPainterPath()
        outer.addEllipse(center, radius * 0.78, radius * 0.78)
        inner = QPainterPath()
        inner.addEllipse(QPointF(center.x() + radius * 0.42, center.y() - radius * 0.2), radius * 0.7, radius * 0.7)
        painter.save()
        painter.setPen(Qt.NoPen)
        painter.setBrush(color)
        painter.drawPath(outer.subtracted(inner))
        painter.restore()

    def paintEvent(self, event) -> None:
        del event
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        margin = 2.0
        track = QRectF(margin, margin, self.width() - margin * 2, self.height() - margin * 2)
        radius = track.height() / 2
        track_color = QColor("#10283a") if self.isChecked() else QColor("#dceeff")
        border_color = QColor("#3f6f8d") if self.isChecked() else QColor("#8fb2d4")
        painter.setPen(QPen(border_color, 1.2))
        painter.setBrush(track_color)
        painter.drawRoundedRect(track, radius, radius)

        knob_size = track.height() - 6
        left = track.left() + 3
        right = track.right() - knob_size - 3
        knob_x = left + (right - left) * self._position
        knob = QRectF(knob_x, track.top() + 3, knob_size, knob_size)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor("#ffffff") if not self.isChecked() else QColor("#e8f3fd"))
        painter.drawEllipse(knob)

        icon_radius = knob_size * 0.27
        left_center = QPointF(left + knob_size / 2, track.center().y())
        right_center = QPointF(right + knob_size / 2, track.center().y())
        sun_color = QColor("#f4a62a") if not self.isChecked() else QColor("#7793a8")
        moon_color = QColor("#2f5d91") if not self.isChecked() else QColor("#173f6b")
        self._draw_sun(painter, left_center, icon_radius, sun_color)
        self._draw_moon(painter, right_center, icon_radius, moon_color)

        if self.hasFocus():
            painter.setBrush(Qt.NoBrush)
            painter.setPen(QPen(QColor("#77b7ff"), 2))
            painter.drawRoundedRect(track.adjusted(1, 1, -1, -1), radius, radius)
