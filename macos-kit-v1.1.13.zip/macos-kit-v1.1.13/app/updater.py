from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import ssl
import subprocess
import sys
import tempfile
import textwrap
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path

import certifi

from .app_info import APP_VERSION, UPDATE_MANIFEST_URL


class UpdateError(RuntimeError):
    pass


MAX_UPDATE_DOWNLOAD_BYTES = 1024 * 1024 * 1024
MAX_UPDATE_EXPANDED_BYTES = 2 * 1024 * 1024 * 1024


def update_ssl_context() -> ssl.SSLContext:
    return ssl.create_default_context(cafile=certifi.where())


@dataclass(frozen=True)
class UpdateInfo:
    latest_version: str
    download_url: str
    sha256: str = ""
    release_notes: str = ""
    published_at: str = ""
    mandatory: bool = False


def platform_key() -> str:
    if sys.platform == "darwin":
        return "macos"
    if sys.platform.startswith("win"):
        return "windows"
    return sys.platform


def current_install_path() -> Path:
    if not getattr(sys, "frozen", False):
        raise UpdateError("Automatic installation is available only in the installed app.")
    executable = Path(sys.executable).resolve()
    if sys.platform == "darwin":
        for parent in executable.parents:
            if parent.suffix == ".app":
                return parent
        raise UpdateError("Could not locate the current macOS app bundle.")
    return executable.parent


def version_tuple(version: str) -> tuple[int, ...]:
    parts = re.findall(r"\d+", version)
    return tuple(int(part) for part in parts) if parts else (0,)


def is_newer_version(latest: str, current: str = APP_VERSION) -> bool:
    latest_parts = version_tuple(latest)
    current_parts = version_tuple(current)
    longest = max(len(latest_parts), len(current_parts))
    latest_parts += (0,) * (longest - len(latest_parts))
    current_parts += (0,) * (longest - len(current_parts))
    return latest_parts > current_parts


def platform_download(data: dict) -> tuple[str, str]:
    downloads = data.get("downloads", {})
    entry: dict = data
    if isinstance(downloads, dict) and downloads:
        selected = downloads.get(platform_key())
        if not isinstance(selected, dict):
            raise UpdateError(f"No update package is available for {platform_key()}.")
        entry = selected
    url = entry.get("download_url") or entry.get("url")
    if not url:
        raise UpdateError(f"The update manifest has no download URL for {platform_key()}.")
    checksum = entry.get("sha256") or data.get("sha256") or ""
    return str(url), str(checksum).lower()


def platform_download_url(data: dict) -> str:
    return platform_download(data)[0]


def fetch_update_info(manifest_url: str = UPDATE_MANIFEST_URL, timeout: int = 8) -> UpdateInfo:
    if not manifest_url:
        raise UpdateError("Update URL is not configured yet.")
    if not manifest_url.startswith("https://"):
        raise UpdateError("The update manifest must use a secure HTTPS URL.")
    request = urllib.request.Request(manifest_url, headers={"User-Agent": "PersonalNightShiftWorkingHoursRecord/" + APP_VERSION})
    last_error: Exception | None = None
    for attempt in range(3):
        try:
            with urllib.request.urlopen(request, timeout=timeout, context=update_ssl_context()) as response:
                payload = response.read(1024 * 1024).decode("utf-8")
            break
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            last_error = exc
            if attempt < 2:
                time.sleep(0.5 * (attempt + 1))
    else:
        raise UpdateError(f"Could not connect to the update server after 3 attempts: {last_error}") from last_error
    try:
        data = json.loads(payload)
        download_url, checksum = platform_download(data)
        info = UpdateInfo(
            latest_version=str(data["latest_version"]),
            download_url=download_url,
            sha256=checksum,
            release_notes=str(data.get("release_notes", "")),
            published_at=str(data.get("published_at", "")),
            mandatory=bool(data.get("mandatory", False)),
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise UpdateError("The update manifest is invalid.") from exc
    if not info.download_url.startswith("https://"):
        raise UpdateError("The update download URL must use secure HTTPS.")
    if not re.fullmatch(r"[0-9a-f]{64}", info.sha256):
        raise UpdateError("The update manifest is missing a valid SHA-256 security checksum.")
    return info


def download_update(info: UpdateInfo, target_dir: Path | None = None, timeout: int = 30) -> Path:
    target_dir = target_dir or Path.home() / "Downloads"
    target_dir.mkdir(parents=True, exist_ok=True)
    url_path = urllib.parse.urlparse(info.download_url).path
    filename = Path(urllib.parse.unquote(url_path)).name or f"PersonalNightShiftWorkingHoursRecord-{info.latest_version}.zip"
    target = target_dir / filename
    partial_target = target.with_name(target.name + ".part")
    request = urllib.request.Request(info.download_url, headers={"User-Agent": "PersonalNightShiftWorkingHoursRecord/" + APP_VERSION})
    last_error: Exception | None = None
    actual_checksum = ""
    for attempt in range(3):
        partial_target.unlink(missing_ok=True)
        digest = hashlib.sha256()
        downloaded = 0
        try:
            with urllib.request.urlopen(
                request,
                timeout=timeout,
                context=update_ssl_context(),
            ) as response, partial_target.open("wb") as file:
                content_length = int(response.headers.get("Content-Length", "0")) if hasattr(response, "headers") else 0
                if content_length > MAX_UPDATE_DOWNLOAD_BYTES:
                    raise UpdateError("The update package is unexpectedly large and was rejected.")
                if content_length:
                    required_space = content_length * 3
                    if shutil.disk_usage(target_dir).free < required_space:
                        raise UpdateError("There is not enough free disk space to download and install the update.")
                while True:
                    chunk = response.read(1024 * 512)
                    if not chunk:
                        break
                    downloaded += len(chunk)
                    if downloaded > MAX_UPDATE_DOWNLOAD_BYTES:
                        raise UpdateError("The update package exceeded the maximum allowed size.")
                    file.write(chunk)
                    digest.update(chunk)
            actual_checksum = digest.hexdigest()
            break
        except UpdateError:
            partial_target.unlink(missing_ok=True)
            raise
        except (urllib.error.URLError, TimeoutError, OSError, ValueError) as exc:
            last_error = exc
            partial_target.unlink(missing_ok=True)
            if attempt < 2:
                time.sleep(0.5 * (attempt + 1))
    else:
        raise UpdateError(f"Could not download the update after 3 attempts: {last_error}") from last_error
    if actual_checksum != info.sha256:
        partial_target.unlink(missing_ok=True)
        raise UpdateError(
            "The downloaded update did not pass its security check. "
            "The file was removed; please try again."
        )
    partial_target.replace(target)
    return target


def validate_update_archive(update_path: Path) -> int:
    if update_path.suffix.lower() != ".zip" or not zipfile.is_zipfile(update_path):
        raise UpdateError("The downloaded update is not a valid ZIP package.")
    expanded_size = 0
    with zipfile.ZipFile(update_path) as archive:
        entries = archive.infolist()
        if not entries:
            raise UpdateError("The downloaded update package is empty.")
        for entry in entries:
            normalized = entry.filename.replace("\\", "/")
            parts = [part for part in normalized.split("/") if part]
            if normalized.startswith("/") or ".." in parts:
                raise UpdateError("The update package contains an unsafe file path.")
            expanded_size += entry.file_size
            if expanded_size > MAX_UPDATE_EXPANDED_BYTES:
                raise UpdateError("The expanded update package is unexpectedly large.")
    if shutil.disk_usage(update_path.parent).free < expanded_size * 2 + update_path.stat().st_size:
        raise UpdateError("There is not enough free disk space to safely install the update.")
    return expanded_size


def create_windows_installer_script(
    update_path: Path,
    install_dir: Path,
    relaunch_path: Path,
    app_pid: int,
    expected_version: str = "",
) -> Path:
    script_path = Path(tempfile.gettempdir()) / "PersonalNightShiftWorkingHoursRecord-update.ps1"
    extract_dir = Path(tempfile.gettempdir()) / "PersonalNightShiftWorkingHoursRecord-update-extract"
    backup_dir = install_dir.with_name(install_dir.name + ".previous")
    log_path = Path.home() / "AppData" / "Local" / "PersonalNightShiftWorkingHoursRecord" / "update.log"
    script = f"""
    $ErrorActionPreference = 'Stop'
    $updatePath = {str(update_path)!r}
    $installDir = {str(install_dir)!r}
    $relaunchPath = {str(relaunch_path)!r}
    $extractDir = {str(extract_dir)!r}
    $backupDir = {str(backup_dir)!r}
    $logPath = {str(log_path)!r}
    $expectedVersion = {expected_version!r}
    $appPid = {app_pid}

    New-Item -ItemType Directory -Path (Split-Path $logPath) -Force | Out-Null
    Start-Transcript -Path $logPath -Append | Out-Null
    try {{
      try {{ Wait-Process -Id $appPid -Timeout 60 -ErrorAction SilentlyContinue }} catch {{}}
      if (Test-Path -LiteralPath $extractDir) {{ Remove-Item -LiteralPath $extractDir -Recurse -Force }}
      New-Item -ItemType Directory -Path $extractDir | Out-Null
      Expand-Archive -LiteralPath $updatePath -DestinationPath $extractDir -Force

      $sourceDir = Join-Path $extractDir 'PersonalNightShiftWorkingHoursRecord'
      if (!(Test-Path -LiteralPath $sourceDir)) {{
        $sourceDir = Get-ChildItem -LiteralPath $extractDir -Directory | Select-Object -First 1 -ExpandProperty FullName
      }}
      $sourceExe = Join-Path $sourceDir 'PersonalNightShiftWorkingHoursRecord.exe'
      if (!(Test-Path -LiteralPath $sourceExe)) {{ throw 'The update package has no app executable.' }}

      if (Test-Path -LiteralPath $backupDir) {{ Remove-Item -LiteralPath $backupDir -Recurse -Force }}
      Copy-Item -LiteralPath $installDir -Destination $backupDir -Recurse
      robocopy $sourceDir $installDir /MIR /NFL /NDL /NJH /NJS /NP | Out-Null
      if ($LASTEXITCODE -gt 7) {{ throw "Update copy failed with robocopy code $LASTEXITCODE." }}
      if (!(Test-Path -LiteralPath $relaunchPath)) {{ throw 'The installed app executable is missing.' }}
      Start-Process -FilePath $relaunchPath
    }} catch {{
      if (Test-Path -LiteralPath $backupDir) {{
        if (Test-Path -LiteralPath $installDir) {{ Remove-Item -LiteralPath $installDir -Recurse -Force }}
        Move-Item -LiteralPath $backupDir -Destination $installDir
        if (Test-Path -LiteralPath $relaunchPath) {{ Start-Process -FilePath $relaunchPath }}
      }}
      throw
    }} finally {{
      Stop-Transcript | Out-Null
    }}
    """
    script_path.write_text(textwrap.dedent(script).strip() + "\n", encoding="utf-8")
    return script_path


def create_macos_installer_script(
    update_path: Path,
    app_path: Path,
    app_pid: int,
    expected_version: str = "",
) -> Path:
    if update_path.suffix.lower() != ".zip":
        raise UpdateError("Automatic macOS installation requires the macOS .zip update package.")
    script_path = Path(tempfile.gettempdir()) / "PersonalNightShiftWorkingHoursRecord-update.sh"
    privileged_script_path = Path(tempfile.gettempdir()) / "PersonalNightShiftWorkingHoursRecord-update-privileged.sh"
    extract_dir = Path(tempfile.gettempdir()) / "PersonalNightShiftWorkingHoursRecord-update-extract"
    staged_app = app_path.with_name(app_path.stem + ".new.app")
    backup_app = app_path.with_name(app_path.stem + ".previous.app")
    log_path = Path.home() / "Library" / "Logs" / "PersonalNightShiftWorkingHoursRecord" / "update.log"
    privileged_script = f"""
    #!/bin/bash
    set -euo pipefail
    app_path={str(app_path)!r}
    staged_app={str(staged_app)!r}
    backup_app={str(backup_app)!r}

    rollback() {{
      status=$?
      trap - EXIT
      if [ "$status" -ne 0 ] && [ -d "$backup_app" ]; then
        echo "Update failed; restoring the previous app."
        rm -rf "$app_path"
        mv "$backup_app" "$app_path"
      fi
      exit "$status"
    }}
    trap rollback EXIT

    rm -rf "$backup_app"
    mv "$app_path" "$backup_app"
    mv "$staged_app" "$app_path"
    test -x "$app_path/Contents/MacOS/PersonalNightShiftWorkingHoursRecord"
    trap - EXIT
    """
    privileged_script_path.write_text(
        textwrap.dedent(privileged_script).strip() + "\n",
        encoding="utf-8",
    )
    privileged_script_path.chmod(0o755)
    script = f"""
    #!/bin/bash
    set -euo pipefail
    update_path={str(update_path)!r}
    app_path={str(app_path)!r}
    extract_dir={str(extract_dir)!r}
    staged_app={str(staged_app)!r}
    backup_app={str(backup_app)!r}
    privileged_script_path={str(privileged_script_path)!r}
    log_path={str(log_path)!r}
    expected_version={expected_version!r}
    app_pid={app_pid}

    mkdir -p "$(dirname "$log_path")"
    exec >>"$log_path" 2>&1
    echo "----- update started $(date -u '+%Y-%m-%dT%H:%M:%SZ') -----"

    waited=0
    while kill -0 "$app_pid" 2>/dev/null && [ "$waited" -lt 90 ]; do
      sleep 1
      waited=$((waited + 1))
    done
    if kill -0 "$app_pid" 2>/dev/null; then
      echo "The running app did not close within 90 seconds."
      exit 1
    fi

    rm -rf "$extract_dir"
    mkdir -p "$extract_dir"
    /usr/bin/ditto -x -k "$update_path" "$extract_dir"

    new_app="$(/usr/bin/find "$extract_dir" -maxdepth 2 -name '*.app' -type d | /usr/bin/head -n 1)"
    if [ -z "$new_app" ]; then
      echo "Could not find the extracted app bundle." >&2
      exit 1
    fi
    new_executable="$new_app/Contents/MacOS/PersonalNightShiftWorkingHoursRecord"
    if [ ! -x "$new_executable" ]; then
      echo "The update package has no executable app binary." >&2
      exit 1
    fi
    if [ -n "$expected_version" ]; then
      packaged_version="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$new_app/Contents/Info.plist")"
      if [ "$packaged_version" != "$expected_version" ]; then
        echo "Expected version $expected_version but package contains $packaged_version." >&2
        exit 1
      fi
    fi

    rm -rf "$staged_app"
    /usr/bin/ditto "$new_app" "$staged_app"

    install_status=0
    if [ -w "$(dirname "$app_path")" ] && [ -w "$app_path" ]; then
      /bin/bash "$privileged_script_path" || install_status=$?
    else
      /usr/bin/osascript <<APPLESCRIPT || install_status=$?
    do shell script "/bin/bash " & quoted form of "$privileged_script_path" with administrator privileges
    APPLESCRIPT
    fi
    if [ "$install_status" -ne 0 ]; then
      echo "The update was cancelled or could not be installed." >&2
      rm -rf "$staged_app" "$extract_dir"
      exit "$install_status"
    fi

    test -x "$app_path/Contents/MacOS/PersonalNightShiftWorkingHoursRecord"
    /usr/bin/open "$app_path"
    rm -rf "$extract_dir"
    echo "Update installed successfully."
    """
    script_path.write_text(textwrap.dedent(script).strip() + "\n", encoding="utf-8")
    script_path.chmod(0o755)
    return script_path


def launch_update_installer(update_path: Path, expected_version: str = "") -> None:
    update_path = update_path.resolve()
    if not update_path.exists():
        raise UpdateError(f"Downloaded update was not found:\n{update_path}")
    validate_update_archive(update_path)

    install_path = current_install_path()
    if sys.platform == "darwin":
        script_path = create_macos_installer_script(
            update_path,
            install_path,
            os.getpid(),
            expected_version,
        )
        subprocess.Popen(["/bin/bash", str(script_path)], close_fds=True)
        return

    if sys.platform.startswith("win"):
        relaunch_path = install_path / "PersonalNightShiftWorkingHoursRecord.exe"
        if not relaunch_path.exists():
            raise UpdateError(f"Could not find the app executable:\n{relaunch_path}")
        script_path = create_windows_installer_script(
            update_path,
            install_path,
            relaunch_path,
            os.getpid(),
            expected_version,
        )
        subprocess.Popen(
            [
                "powershell.exe",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(script_path),
            ],
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        return

    raise UpdateError(f"Automatic installation is not supported on this platform: {sys.platform}")
