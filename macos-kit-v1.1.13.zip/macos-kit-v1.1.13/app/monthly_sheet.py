from __future__ import annotations

from calendar import monthrange
from datetime import date, datetime, time
from decimal import Decimal, InvalidOperation
import sys

from PySide6.QtCore import QDate, QEvent, QRect, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QFontMetrics, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QGraphicsDropShadowEffect,
    QGridLayout,
    QHeaderView,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QSizePolicy,
    QStyle,
    QStyledItemDelegate,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from calculations.models import (
    NON_STATUTORY_HOLIDAY,
    STATUTORY_HOLIDAY,
    BreakInterval,
    DailyInput,
    DailyResult,
    MonthlyTotals,
)
from calculations.formatting import hours_minutes
from calculations.salary_engine import (
    SATURDAY_WORK_STATUS,
    SUNDAY_HOLIDAY_STATUS,
    summarize_month,
)
from .theme_toggle import ThemeToggle
from .app_info import OFFICIAL_HEADER_LOGO_PATH
from .styles import GRID, LABEL_BLUE

STATUSES = [
    "",
    "Work",
    SATURDAY_WORK_STATUS,
    SUNDAY_HOLIDAY_STATUS,
    "Holiday Work",
    "Employer Leave",
    "Day Off",
    "Paid Leave",
    "Sick Leave",
    "Absent",
]
SCROLLBAR_LANE_WIDTH = 12
TABLE_CORNER_INSET = 8
TABLE_HEADER_HEIGHT = 34
COMPACT_TABLE_HEADER_HEIGHT = 34
TARGET_TABLE_HEADER_HEIGHT = 28
TARGET_TABLE_ROW_HEIGHT = 27
STANDARD_TABLE_ROW_HEIGHT = 25
TARGET_CONTROL_SIDE_GAP = 4
TARGET_STATUS_COLUMN_WIDTH = 74
TARGET_STATUS_FONT_SIZE = 6.0
STATUS_POPUP_MIN_WIDTH = 190
TARGET_PANEL_GAP_MM = 5
FORMULA_FONT_SAFETY_REDUCTION_PT = 0.5
# A 14-inch Retina MacBook Pro exposes a roughly 1512-point-wide workspace.
# Keep the compact profile active through 1600 logical pixels.
COMPACT_SCREEN_MAX_WIDTH = 1600
TARGET_DISPLAY_WIDTH_MM = 301
TARGET_DISPLAY_HEIGHT_RATIO = 0.6478
TARGET_DISPLAY_HEIGHT_MM = TARGET_DISPLAY_WIDTH_MM * TARGET_DISPLAY_HEIGHT_RATIO
TARGET_DISPLAY_LOGICAL_WIDTH = 1512
TARGET_DISPLAY_TOLERANCE_MM = 12
IS_MACOS = sys.platform == "darwin"
STATUS_COLUMN = 0
DATE_COLUMN = 1
DAY_COLUMN = 2
WEEKEND_ALLOWANCE_COLUMN = 11
HOLIDAY_PREMIUM_COLUMN = 12
DAILY_TOTAL_COLUMN = 13
NOTES_COLUMN = 14
CALCULATE_COLUMN = 15
RESET_COLUMN = 16
STANDARD_TABLE_WIDTHS = [115, 77, 66, 53, 53, 65, 88, 70, 100, 102, 100, 101, 113, 75, 89, 66, 66]
COMPACT_TABLE_WIDTHS = [96, 51, 40, 56, 56, 52, 88, 61, 86, 76, 76, 72, 82, 84, 88, 48, 48]
TABLE_INPUT = "#fff9e8"
TABLE_CALCULATED = "#f2f7fb"
TABLE_BASE_PAY = "#eaf4fb"
TABLE_PREMIUM = "#fff6df"
TABLE_PAY = "#e8f7ef"
TABLE_WEEKDAY = "#f5f9fc"
TABLE_SATURDAY = "#eef3f8"
TABLE_SUNDAY = "#fff0f2"


def is_target_display(physical_width_mm: float, physical_height_mm: float) -> bool:
    width = max(physical_width_mm, physical_height_mm)
    height = min(physical_width_mm, physical_height_mm)
    return (
        abs(width - TARGET_DISPLAY_WIDTH_MM) <= TARGET_DISPLAY_TOLERANCE_MM
        and abs(height - TARGET_DISPLAY_HEIGHT_MM) <= TARGET_DISPLAY_TOLERANCE_MM
    )


def uses_compact_layout(
    screen_width: int,
    physical_width_mm: float = 0,
    physical_height_mm: float = 0,
) -> bool:
    return (
        is_target_display(physical_width_mm, physical_height_mm)
        or screen_width <= COMPACT_SCREEN_MAX_WIDTH
    )


class MonthYearSelector(QWidget):
    dateChanged = Signal(QDate)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.month_combo = QComboBox()
        self.year_combo = QComboBox()
        self.month_combo.setObjectName("recordMonthCombo")
        self.year_combo.setObjectName("recordYearCombo")
        self.month_combo.addItems([f"{month:02d}" for month in range(1, 13)])
        current_year = date.today().year
        self.year_combo.addItems([str(year) for year in range(current_year - 10, current_year + 11)])
        self.month_combo.setFrame(False)
        self.year_combo.setFrame(False)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self.year_combo, 3)
        layout.addWidget(self.month_combo, 2)

        self.month_combo.currentIndexChanged.connect(self._emit_date_changed)
        self.year_combo.currentIndexChanged.connect(self._emit_date_changed)
        self.apply_panel_style()
        self.setDate(QDate.currentDate())

    def apply_panel_style(self) -> None:
        dense = bool(self.property("dense"))
        combo_padding = "3px 5px" if dense else "7px 8px"
        combo_font = "font-size:7pt;" if dense else ""
        selector_style = """
            MonthYearSelector {
                background: #f2f8fd;
                border: 0px;
                border-right: 1px solid #c8d9e8;
                border-bottom: 1px solid #c8d9e8;
            }
            QComboBox#recordMonthCombo, QComboBox#recordYearCombo {
                background: transparent;
                color: #102033;
                border: 0px;
                border-radius: 0px;
                margin: 0px;
                padding: {combo_padding};
                {combo_font}
                font-weight: 500;
            }
            QComboBox#recordYearCombo {
                border-right: 1px solid #d5e3f0;
            }
            QComboBox#recordMonthCombo:hover, QComboBox#recordYearCombo:hover {
                background: #e8f3fd;
            }
            QComboBox#recordMonthCombo:focus, QComboBox#recordYearCombo:focus {
                background: #e8f3fd;
                border: 0px;
            }
            QComboBox::drop-down {
                border: 0px;
                background: transparent;
                width: 22px;
            }
            QComboBox::down-arrow {
                width: 10px;
                height: 10px;
            }
            QComboBox QAbstractItemView {
                background: #ffffff;
                color: #102033;
                border: 1px solid #8fb2d4;
                border-radius: 6px;
                padding: 4px;
                selection-background-color: #d7ecff;
                selection-color: #071a3d;
                outline: 0;
            }
            """
        self.setStyleSheet(
            selector_style.replace("{combo_padding}", combo_padding).replace("{combo_font}", combo_font)
        )

    def paintEvent(self, event) -> None:
        super().paintEvent(event)
        painter = QPainter(self)
        painter.setPen(QPen(QColor("#c8d9e8"), 1))
        painter.drawLine(0, self.height() - 1, self.width(), self.height() - 1)
        painter.drawLine(self.width() - 1, 0, self.width() - 1, self.height())

    def setDate(self, selected_date) -> None:
        qdate = selected_date if isinstance(selected_date, QDate) else QDate(selected_date.year, selected_date.month, selected_date.day)
        year_text = str(qdate.year())
        if self.year_combo.findText(year_text) < 0:
            self.year_combo.addItem(year_text)
            self.year_combo.model().sort(0)
        self.year_combo.blockSignals(True)
        self.month_combo.blockSignals(True)
        self.year_combo.setCurrentText(year_text)
        self.month_combo.setCurrentText(f"{qdate.month():02d}")
        self.month_combo.blockSignals(False)
        self.year_combo.blockSignals(False)
        self._emit_date_changed()

    def date(self) -> QDate:
        return QDate(int(self.year_combo.currentText()), int(self.month_combo.currentText()), 1)

    def _emit_date_changed(self) -> None:
        self.dateChanged.emit(self.date())


class TableHeaderLabel(QLabel):
    def __init__(self, text: str, draw_right_divider: bool, parent: QWidget | None = None) -> None:
        super().__init__(text, parent)
        self.draw_right_divider = draw_right_divider

    def paintEvent(self, event) -> None:
        super().paintEvent(event)
        if not self.draw_right_divider:
            return
        painter = QPainter(self)
        painter.setPen(QPen(QColor("#2d76ae"), 1))
        x = self.width() - 1
        painter.drawLine(x, 0, x, self.height())


class NotesPreviewDelegate(QStyledItemDelegate):
    def initStyleOption(self, option, index) -> None:
        super().initStyleOption(option, index)
        option.text = option.text.replace("\r", " ").replace("\n", " ")
        option.textElideMode = Qt.ElideRight
        option.displayAlignment = Qt.AlignLeft | Qt.AlignVCenter

    def createEditor(self, parent, option, index):
        return None


class InputCellDelegate(QStyledItemDelegate):
    """Use one opaque editor so re-entered values never overlap cell text."""

    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignCenter)
        editor.setAutoFillBackground(True)
        editor.setAttribute(Qt.WA_OpaquePaintEvent, True)
        editor.setStyleSheet(
            "QLineEdit { background:#ffffff; color:#102033; "
            "border:2px solid #2f80d0; border-radius:5px; padding:1px 4px; "
            "selection-background-color:#2563eb; selection-color:#ffffff; }"
        )
        return editor

    def setEditorData(self, editor, index) -> None:
        editor.setText(str(index.data(Qt.EditRole) or ""))
        editor.selectAll()

    def setModelData(self, editor, model, index) -> None:
        model.setData(index, editor.text().strip(), Qt.EditRole)

    def updateEditorGeometry(self, editor, option, index) -> None:
        editor.setGeometry(option.rect.adjusted(1, 1, -1, -1))


class FormulaCellDelegate(QStyledItemDelegate):
    """Draw complete formula lines at the largest shared size that fits."""

    def __init__(
        self,
        parent=None,
        synchronized_columns: tuple[int, ...] = tuple(range(7, DAILY_TOTAL_COLUMN + 1)),
        safety_reduction: float = FORMULA_FONT_SAFETY_REDUCTION_PT,
    ) -> None:
        super().__init__(parent)
        self.synchronized_columns = synchronized_columns
        self.safety_reduction = safety_reduction
        self._cached_point_size: float | None = None
        self._cached_font_key: tuple | None = None
        if isinstance(parent, QTableWidget):
            parent.model().dataChanged.connect(self.invalidate_font_cache)
            parent.model().modelReset.connect(self.invalidate_font_cache)
            parent.model().layoutChanged.connect(self.invalidate_font_cache)
            parent.horizontalHeader().sectionResized.connect(self.invalidate_font_cache)
            parent.verticalHeader().sectionResized.connect(self.invalidate_font_cache)

    def invalidate_font_cache(self, *_args) -> None:
        self._cached_point_size = None
        self._cached_font_key = None

    @staticmethod
    def _fitted_point_size(
        font: QFont,
        cells: list[tuple[list[str], int, int]],
    ) -> float:
        point_size = font.pointSizeF()
        if point_size <= 0:
            point_size = 9.0
        minimum_size = 5.5
        while point_size > minimum_size:
            font.setPointSizeF(point_size)
            metrics = QFontMetrics(font)
            if all(
                all(metrics.horizontalAdvance(line) <= width for line in lines)
                and metrics.height() * len(lines) <= height
                for lines, width, height in cells
            ):
                break
            point_size = max(minimum_size, point_size - 0.25)
        return point_size

    def _shared_point_size(self, table: QTableWidget, font: QFont) -> float:
        font_key = (
            font.family(),
            font.pointSizeF(),
            font.weight(),
            font.italic(),
        )
        if self._cached_point_size is not None and self._cached_font_key == font_key:
            return self._cached_point_size

        fitting_cells: list[tuple[list[str], int, int]] = []
        model = table.model()
        for row in range(table.rowCount()):
            row_height = max(1, table.rowHeight(row) - 2)
            for column in self.synchronized_columns:
                cell_text = model.index(row, column).data(Qt.DisplayRole)
                cell_lines = str(cell_text or "").splitlines()
                if cell_lines:
                    fitting_cells.append(
                        (
                            cell_lines,
                            max(1, table.columnWidth(column) - 6),
                            row_height,
                        )
                    )

        fitted_size = self._fitted_point_size(font, fitting_cells)
        self._cached_point_size = max(5.5, fitted_size - self.safety_reduction)
        self._cached_font_key = font_key
        return self._cached_point_size

    def paint(self, painter, option, index) -> None:
        self.initStyleOption(option, index)
        lines = option.text.splitlines()
        option.text = ""
        style = option.widget.style() if option.widget else QApplication.style()
        style.drawControl(QStyle.CE_ItemViewItem, option, painter, option.widget)

        if not lines:
            return

        rect = option.rect.adjusted(3, 1, -3, -1)
        font = QFont(option.font)
        fitting_cells = [(lines, rect.width(), rect.height())]
        table = option.widget
        if (
            isinstance(table, QTableWidget)
            and index.column() in self.synchronized_columns
        ):
            point_size = self._shared_point_size(table, font)
        else:
            point_size = self._fitted_point_size(font, fitting_cells)
        font.setPointSizeF(point_size)

        painter.save()
        painter.setFont(font)
        if option.state & QStyle.State_Selected:
            painter.setPen(option.palette.highlightedText().color())
        else:
            painter.setPen(option.palette.text().color())
        line_height = max(1, rect.height() // len(lines))
        equation_lines = lines[1:] if len(lines) > 1 else []
        equation_width = (
            max(QFontMetrics(font).horizontalAdvance(line) for line in equation_lines)
            if equation_lines
            else 0
        )
        equation_left = rect.left() + max(0, (rect.width() - equation_width) // 2)
        for line_number, line in enumerate(lines):
            top = rect.top() + (line_number * line_height)
            height = (
                rect.bottom() - top + 1
                if line_number == len(lines) - 1
                else line_height
            )
            if line_number == 0 or not equation_lines:
                line_rect = QRect(rect.left(), top, rect.width(), height)
                alignment = Qt.AlignCenter
            else:
                line_rect = QRect(equation_left, top, equation_width, height)
                alignment = Qt.AlignLeft | Qt.AlignVCenter
            painter.drawText(
                line_rect,
                alignment,
                line,
            )
        painter.restore()


def item(text: str, color: str | None = None, editable: bool = False, alignment=Qt.AlignCenter) -> QTableWidgetItem:
    it = QTableWidgetItem(text)
    if color:
        it.setBackground(QColor(color))
    it.setTextAlignment(alignment)
    flags = Qt.ItemIsSelectable | Qt.ItemIsEnabled
    if editable:
        flags |= Qt.ItemIsEditable
    it.setFlags(flags)
    return it


def h(minutes: int) -> str:
    return hours_minutes(minutes)


def worked_h(minutes: int) -> str:
    hours, remaining_minutes = divmod(minutes, 60)
    return f"{hours} hr  {remaining_minutes:02d} min"


def m(minutes: int) -> str:
    return str(minutes)


def yen(value: Decimal) -> str:
    return f"{value.quantize(Decimal('0.01')):,.2f} 円"


def hours_and_yen(minutes: int, amount: Decimal) -> str:
    return f"{h(minutes)}\n{yen(amount)}"


def formula_number(value: Decimal, *, hours: bool = False) -> str:
    if hours:
        normalized = value.quantize(Decimal("0.01")).normalize()
        return f"{normalized:f}"
    rounded = value.quantize(Decimal("0.01"))
    if rounded == rounded.to_integral():
        return f"{rounded:,.0f}"
    return f"{rounded:,.2f}"


def pay_formula(rate: Decimal, minutes: int, amount: Decimal) -> str:
    if minutes <= 0 or amount == 0:
        return f"{h(minutes)}\n{yen(amount)}"
    decimal_hours = Decimal(minutes) / Decimal("60")
    return (
        f"{h(minutes)}\n"
        f"{formula_number(rate)} x {formula_number(decimal_hours, hours=True)} "
        f"= {formula_number(amount)} 円"
    )


def pay_formula_terms(
    terms: list[tuple[Decimal, int]],
    amount: Decimal,
) -> str:
    grouped: dict[Decimal, int] = {}
    for rate, minutes in terms:
        if minutes > 0 and rate:
            grouped[rate] = grouped.get(rate, 0) + minutes
    if not grouped:
        return f"0hr 00min\n{yen(amount)}"
    if len(grouped) == 1:
        rate, minutes = next(iter(grouped.items()))
        expression = (
            f"{formula_number(rate)} x "
            f"{formula_number(Decimal(minutes) / Decimal('60'), hours=True)}"
        )
    else:
        expression = "+".join(
            f"{formula_number(rate)}x"
            f"{formula_number(Decimal(minutes) / Decimal('60'), hours=True)}"
            for rate, minutes in grouped.items()
        )
    total_minutes = sum(grouped.values())
    return f"{h(total_minutes)}\n{expression} = {formula_number(amount)} 円"


def base_rate_display(
    weekend_minutes: int,
    holiday_minutes: int,
    worked_minutes: int,
    settings,
) -> str:
    base_rate = settings.base_hourly_wage
    return f"{formula_number(base_rate)} 円"


class MonthlySheet(QWidget):
    def _scaled_pixmap(self, path, width: int, height: int) -> QPixmap:
        pixmap = QPixmap(str(path))
        if pixmap.isNull():
            return pixmap
        screen = QApplication.primaryScreen()
        device_ratio = screen.devicePixelRatio() if screen else 1.0
        scaled = pixmap.scaled(
            round(width * device_ratio),
            round(height * device_ratio),
            Qt.KeepAspectRatio,
            Qt.SmoothTransformation,
        )
        scaled.setDevicePixelRatio(device_ratio)
        return scaled

    def __init__(self) -> None:
        super().__init__()
        self.breaks_by_day: dict[int, list[BreakInterval]] = {}
        self.row_dates: dict[int, date] = {}
        self.rows_by_day: dict[int, tuple[DailyInput, DailyResult]] = {}
        self._loading = False
        self.zoom_factor = 1.0
        screen = QApplication.primaryScreen()
        screen_width = screen.availableGeometry().width() if screen else 1600
        physical_size = screen.physicalSize() if screen else None
        physical_width = physical_size.width() if physical_size else 0
        physical_height = physical_size.height() if physical_size else 0
        self.target_display = is_target_display(physical_width, physical_height)
        self.compact_layout = uses_compact_layout(screen_width, physical_width, physical_height)
        self.table_header_height = (
            TARGET_TABLE_HEADER_HEIGHT
            if self.target_display
            else COMPACT_TABLE_HEADER_HEIGHT
            if self.compact_layout
            else TABLE_HEADER_HEIGHT
        )
        layout = QVBoxLayout(self)
        outer_margin = 4 if self.target_display else 8 if self.compact_layout else 18
        layout.setContentsMargins(outer_margin, outer_margin, outer_margin, outer_margin)
        self.sheet = QWidget()
        self.sheet.setObjectName("sheet")
        self.sheet.setMinimumWidth(0)
        self.sheet.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.sheet.setStyleSheet(f"#sheet {{ background: white; border: 1px solid #c9d7e5; border-radius:8px; }}")
        sheet_shadow = QGraphicsDropShadowEffect(self.sheet)
        sheet_shadow.setBlurRadius(22)
        sheet_shadow.setColor(QColor(28, 55, 83, 36))
        sheet_shadow.setOffset(0, 5)
        self.sheet.setGraphicsEffect(sheet_shadow)
        layout.addWidget(self.sheet)
        grid = QGridLayout(self.sheet)
        grid.setContentsMargins(0, 0, 0, 4 if self.target_display else 10)
        grid.setSpacing(0)

        title_panel = QWidget()
        title_panel.setFixedHeight(52 if self.target_display else 72 if self.compact_layout else 92)
        title_panel.setStyleSheet("background:#ffffff; border:0px; border-top-left-radius:8px; border-top-right-radius:8px;")
        title_outer = QHBoxLayout(title_panel)
        title_outer.setContentsMargins(
            8 if self.target_display else 14 if self.compact_layout else 24,
            2 if self.target_display else 6,
            8 if self.target_display else 14 if self.compact_layout else 24,
            2 if self.target_display else 6,
        )
        title_outer.setSpacing(0)

        header_logo = QLabel()
        header_logo.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        logo_width, logo_height = (
            (130, 46)
            if self.target_display
            else (150, 58)
            if self.compact_layout
            else (184, 76)
        )
        header_logo.setFixedSize(logo_width, logo_height)
        pixmap = self._scaled_pixmap(OFFICIAL_HEADER_LOGO_PATH, logo_width - 8, logo_height)
        if not pixmap.isNull():
            header_logo.setPixmap(pixmap)
        self.night_mode_button = ThemeToggle(self.target_display)
        title_outer.addWidget(header_logo, 0, Qt.AlignLeft | Qt.AlignVCenter)
        title_outer.addStretch(1)
        title_outer.addWidget(self.night_mode_button, 0, Qt.AlignRight | Qt.AlignVCenter)
        grid.addWidget(title_panel, 0, 0, 1, 16)

        self.name = QLineEdit()
        self.name.setAlignment(Qt.AlignCenter)
        self.name.setPlaceholderText("Worker name")
        self.record_month = MonthYearSelector()
        self.np_no = QLineEdit("4026")
        self.np_no.setAlignment(Qt.AlignCenter)
        self.np_no.setReadOnly(True)
        self.project = QLineEdit()
        self.project.setAlignment(Qt.AlignCenter)
        self.project.setPlaceholderText("Workplace or project")
        self.wage_label = QLineEdit()
        self.wage_label.setAlignment(Qt.AlignCenter)
        self.wage_label.setPlaceholderText("1,250.00 円")
        self.standard_label = QLabel()
        self.ot_label = QLabel("25%; 50% after 60 hours")
        self.update_button = QPushButton("Check Updates")
        self.update_button.setVisible(False)
        self.release_button = QPushButton("New Update")
        self.release_button.setMinimumHeight(34 if self.target_display else 42)
        self.release_button.setStyleSheet(
            "QPushButton { background:#0b4f8f; color:white; border:1px solid #083a69; "
            f"border-radius:8px; padding:{'5px 8px' if self.target_display else '9px 12px'}; "
            f"font-size:{'7pt' if self.target_display else '9pt'}; font-weight:800; }}"
            "QPushButton:hover { background:#0a467f; }"
            "QPushButton:pressed { background:#07345f; }"
        )
        self.payslip_button = QPushButton("PaySlip")
        self.payslip_button.setFlat(True)
        self.payslip_button.setCursor(Qt.PointingHandCursor)
        self.payslip_button.setMinimumHeight(24 if self.target_display else 30)
        self.payslip_button.setStyleSheet(
            "QPushButton { background:transparent; color:#155c99; border:0px; "
            f"padding:{'2px 6px' if self.target_display else '4px 8px'}; "
            f"font-size:{'7pt' if self.target_display else '9pt'}; font-weight:700; }}"
            "QPushButton:hover { color:#c51f2a; text-decoration:underline; }"
            "QPushButton:pressed { color:#07345f; }"
        )
        self.payslip_button.setVisible(IS_MACOS)
        sidebar = QWidget()
        sidebar_width = 276 if self.target_display else 290 if self.compact_layout else 390
        sidebar.setFixedWidth(sidebar_width)
        sidebar.setStyleSheet("background:transparent; border:0px;")
        sidebar_layout = QVBoxLayout(sidebar)
        sidebar_margin = 4 if self.target_display else 8 if self.compact_layout else 14
        sidebar_layout.setContentsMargins(sidebar_margin, sidebar_margin, sidebar_margin, sidebar_margin)
        sidebar_layout.setSpacing(6 if self.target_display else 10 if self.compact_layout else 14)
        self.details_summary_gap_px = (
            round(
                TARGET_PANEL_GAP_MM
                * TARGET_DISPLAY_LOGICAL_WIDTH
                / TARGET_DISPLAY_WIDTH_MM
            )
            if self.target_display
            else sidebar_layout.spacing()
        )

        details = QWidget()
        details.setObjectName("panelCard")
        panel_style = (
            "#panelCard { background:#fbfdff; border:1px solid #c8d9e8; "
            "border-top-left-radius:10px; border-top-right-radius:10px; "
            "border-bottom-left-radius:0px; border-bottom-right-radius:0px; }"
        )
        panel_title_padding = "5px 8px" if self.target_display else "9px 10px"
        panel_title_font = "font-size:7pt;" if self.target_display else ""
        panel_title_style = (
            "background:#071f46; color:white; border:0px; border-bottom:1px solid #c8d9e8; "
            "border-top-left-radius:9px; border-top-right-radius:9px; "
            "border-bottom-left-radius:0px; border-bottom-right-radius:0px; "
            f"padding:{panel_title_padding}; {panel_title_font} font-weight:800;"
        )
        panel_input_padding = "3px 5px" if self.target_display else "7px 10px"
        panel_input_font = "font-size:7pt;" if self.target_display else ""
        panel_input_focus_style = (
            "QLineEdit, QDateEdit { background:#f2f8fd; border:0px; border-right:1px solid #c8d9e8; "
            "border-bottom:1px solid #c8d9e8; "
            "border-radius:0px; "
            f"padding:{panel_input_padding}; {panel_input_font} color:#102033; }}"
            "QLineEdit:focus, QDateEdit:focus { border-right:1px solid #2f80d0; "
            f"border-bottom:2px solid #2f80d0; padding-bottom:{'2px' if self.target_display else '6px'}; }}"
            "QLineEdit:read-only { color:#48627d; background:#f2f8fd; }"
            "QDateEdit::drop-down { border:0; width:24px; background:#f2f8fd; }"
            "QDateEdit::down-arrow { width:10px; height:10px; }"
        )
        details.setStyleSheet(panel_style)
        details_grid = QGridLayout(details)
        details_grid.setContentsMargins(0, 0, 0, 0)
        details_grid.setHorizontalSpacing(0)
        details_grid.setVerticalSpacing(0)
        details_title = QLabel("Worker / Contract Details")
        details_title.setFixedHeight(self.table_header_height)
        details_title.setAlignment(Qt.AlignCenter)
        details_title.setStyleSheet(panel_title_style)
        details_grid.addWidget(details_title, 0, 0, 1, 2)
        fields = [
            ("Name", self.name),
            ("Record Month", self.record_month),
            ("NP No.", self.np_no),
            ("Work / Project", self.project),
            ("Hourly Wage", self.wage_label),
            ("Standard Hrs", self.standard_label),
            ("Over Time Premium", self.ot_label),
        ]
        for idx, (label, widget) in enumerate(fields, 1):
            detail_label = self.label(label)
            detail_label.setMinimumHeight(26 if self.target_display else 43)
            details_grid.addWidget(detail_label, idx, 0)
            if isinstance(widget, QLabel):
                widget.setAlignment(Qt.AlignCenter)
                widget.setMinimumHeight(26 if self.target_display else 43)
                widget.setStyleSheet(
                    "background:#eef5fb; border:0px; border-right:1px solid #c5d9ea; "
                    "border-bottom:1px solid #c5d9ea; border-radius:0px; "
                    f"padding:{'3px 5px' if self.target_display else '7px 10px'}; "
                    f"font-size:{'7pt' if self.target_display else '9pt'}; font-weight:800; color:#102033;"
                )
            elif isinstance(widget, MonthYearSelector):
                widget.setMinimumHeight(26 if self.target_display else 43)
                widget.setProperty("dense", self.target_display)
                widget.apply_panel_style()
            else:
                widget.setMinimumHeight(26 if self.target_display else 43)
                widget.setStyleSheet(panel_input_focus_style)
            details_grid.addWidget(widget, idx, 1)
        details_grid.setColumnMinimumWidth(0, 112 if self.compact_layout else 132)
        details_grid.setColumnStretch(1, 1)

        guidance = QWidget()
        guidance.setVisible(not self.target_display)
        guidance.setStyleSheet("background:transparent;")
        guidance_layout = QVBoxLayout(guidance)
        guidance_layout.setContentsMargins(0, 0, 0, 0)
        guidance_layout.setSpacing(4 if self.target_display else 8)
        left = QLabel("Clock-in examples: 18:00, 19:00, 20:00, 21:30\nEnter actual clock-out and break minutes, then click Calculate on that row.")
        right = QLabel(
            "Weekday rule (Mon-Fri): Base 100% + Night +25% from 22:00-05:00\n"
            "Over Time +25% after 8 paid hours; over 60 hours/month = +50% total\n"
            "Normal weekend work: Hourly Wage + 50円; premiums use the adjusted rate\n"
            "Statutory holiday: +35% replaces +50円; night work totals 160%"
        )
        for index, widget in enumerate((left, right)):
            widget.setWordWrap(True)
            widget.setMinimumHeight((48 if index == 0 else 66) if self.target_display else 72)
            widget.setStyleSheet(
                f"background:{LABEL_BLUE}; border:1px solid #c4d8ea; border-radius:8px; "
                f"padding:{'4px 6px' if self.target_display else '10px 12px'}; "
                f"font-size:{'6.5pt' if self.target_display else '9pt'}; color:#17324d;"
            )
            guidance_layout.addWidget(widget)
        if not self.target_display:
            guidance.setMaximumHeight(guidance.sizeHint().height())
        sidebar_layout.addWidget(details)

        self.summary_labels: dict[str, QLabel] = {}
        self.summary_values: dict[str, QLabel] = {}
        summary_panel = QWidget()
        summary_panel.setObjectName("panelCard")
        summary_panel.setStyleSheet(panel_style)
        summary_grid = QGridLayout(summary_panel)
        summary_grid.setContentsMargins(0, 0, 0, 0)
        summary_grid.setHorizontalSpacing(0)
        summary_grid.setVerticalSpacing(0)
        summary_title = QLabel("Monthly Totals")
        summary_title.setFixedHeight(self.table_header_height)
        summary_title.setAlignment(Qt.AlignCenter)
        summary_title.setStyleSheet(panel_title_style)
        summary_grid.addWidget(summary_title, 0, 0, 1, 2)
        summary = [
            "Total Worked",
            "Base Pay 100%",
            "Over Time Premium +25%",
            "Night Premium +25%",
            "Weekend +50 円/hr",
            "Paid Leave",
            "Employer Leave 60%",
            "Workdays",
            "Estimated Pay Total",
        ]
        summary_display = {
            "Paid Leave": "Paid Leave<br><span style='font-size:6pt; font-weight:600;'>(yūkyū)</span>",
            "Employer Leave 60%": "Employer Leave 60%<br><span style='font-size:6pt; font-weight:600;'>(kyūgyō)</span>",
        }
        for idx, label in enumerate(summary, 1):
            lab = self.label(summary_display.get(label, label))
            lab.setMinimumHeight(24 if self.target_display else 41)
            lab.setAlignment(Qt.AlignCenter)
            lab.setStyleSheet(
                "background:#e8f3fd; border:0px; border-bottom:1px solid #c8d9e8; "
                "border-left:1px solid #c8d9e8; border-right:1px solid #b8cede; "
                "border-radius:0px; "
                f"padding:{'0px 3px' if self.target_display else '1px 6px'}; "
                f"font-size:{'7pt' if self.target_display else '8pt'}; "
                "font-weight:800; color:#0b3158;"
            )
            val = QLabel("0")
            val.setAlignment(Qt.AlignCenter)
            val.setMinimumHeight(24 if self.target_display else 41)
            val.setWordWrap(True)
            value_background = "#ddf7e8" if label == "Estimated Pay Total" else "#f2f8fd"
            value_border = "#9fd7b6" if label == "Estimated Pay Total" else "#c8d9e8"
            val.setStyleSheet(
                f"background:{value_background}; border:0px; border-bottom:1px solid {value_border}; "
                "border-right:1px solid #c8d9e8; border-radius:0px; "
                f"padding:{'0px 3px' if self.target_display else '1px 4px'}; "
                f"font-size:{'6.5pt' if self.target_display else '8pt'}; font-weight:800; color:#102033;"
            )
            self.summary_labels[label] = lab
            self.summary_values[label] = val
            summary_grid.addWidget(lab, idx, 0)
            summary_grid.addWidget(val, idx, 1)
        summary_grid.setColumnMinimumWidth(0, 130 if self.compact_layout else 152)
        summary_grid.setColumnStretch(1, 1)
        if self.target_display:
            sidebar_layout.addSpacing(
                max(0, self.details_summary_gap_px - sidebar_layout.spacing())
            )
        sidebar_layout.addWidget(summary_panel)
        action_row = QWidget()
        action_row.setStyleSheet("background:transparent; border:0px;")
        action_layout = QVBoxLayout(action_row)
        action_layout.setContentsMargins(0, 0, 0, 0)
        action_layout.setSpacing(6)
        action_layout.addWidget(self.release_button)
        action_layout.addWidget(self.payslip_button)
        sidebar_layout.addWidget(action_row)
        sidebar_layout.addStretch(1)
        sidebar_layout.addWidget(guidance)
        grid.addWidget(sidebar, 1, 0, 4, 1)

        table_area = QWidget()
        table_area.setStyleSheet("background:transparent;")
        table_layout = QVBoxLayout(table_area)
        table_margin = 4 if self.target_display else 8 if self.compact_layout else 14
        table_layout.setContentsMargins(table_margin, table_margin, table_margin, table_margin)
        table_layout.setSpacing(0)

        self.table = QTableWidget(31, 17)
        table_font_size = "6pt" if self.target_display else "7pt" if self.compact_layout else "9pt"
        self.table.setObjectName("timesheetTable")
        self.table.setStyleSheet(
            f"""
            QTableWidget#timesheetTable {{
                background: #ffffff;
                alternate-background-color: #fbfdff;
                color: #18324b;
                gridline-color: #dbe7f1;
                border: 1px solid #bfd0df;
                border-top: 0px;
                border-bottom-left-radius: 10px;
                border-bottom-right-radius: 10px;
                font-size: {table_font_size};
                selection-background-color: #dceeff;
                selection-color: #0a2742;
            }}
            QTableWidget#timesheetTable::item {{
                border: 0px;
                padding: {"0px" if self.target_display else "4px"};
            }}
            QTableWidget#timesheetTable::item:hover {{
                background: #edf6ff;
            }}
            QTableWidget#timesheetTable::item:selected {{
                background: #dceeff;
                color: #0a2742;
            }}
            """
        )
        self.table.setMinimumWidth(0)
        self.table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.table.setVerticalScrollBarPolicy(
            Qt.ScrollBarAlwaysOff if self.target_display else Qt.ScrollBarAsNeeded
        )
        self.table.setViewportMargins(TABLE_CORNER_INSET, 0, 0, TABLE_CORNER_INSET)
        self.table.setMouseTracking(True)
        self.table.viewport().setMouseTracking(True)
        self.table.verticalScrollBar().setObjectName("timesheetVerticalScroll")
        self.table.verticalScrollBar().setProperty("hoverActive", False)
        self.table.viewport().installEventFilter(self)
        self.table.installEventFilter(self)
        self.table.verticalScrollBar().installEventFilter(self)
        headers = [
            "Status",
            "Date",
            "Day",
            "Time In",
            "Time Out",
            "Break Min",
            "Total Worked\nHours",
            "Base Rate",
            "Base Pay\n100%",
            "Night Premium\n+25%",
            "Over Time\nPremium +25%",
            "Weekends\n+50 円",
            "Statutory Holiday\n+35%",
            "Daily Total",
            "Notes",
            "Calculate",
            "Reset",
        ]
        header_cell_count = len(headers)
        self.header_labels = [self._table_header_label(text, idx, header_cell_count) for idx, text in enumerate(headers)]
        self.header_row = QWidget()
        self.header_row.setFixedHeight(self.table_header_height)
        self.header_row.setStyleSheet("background:#135f9d; border-top-left-radius:10px; border-top-right-radius:10px;")
        for label_widget in self.header_labels:
            label_widget.setParent(self.header_row)
        self.table.setHorizontalHeaderLabels(headers)
        self.table.verticalHeader().setVisible(False)
        self.table.setShowGrid(True)
        self.table.setAlternatingRowColors(True)
        self.table.setCornerButtonEnabled(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setWordWrap(True)
        formula_delegate = FormulaCellDelegate(self.table)
        for formula_column in range(7, DAILY_TOTAL_COLUMN + 1):
            self.table.setItemDelegateForColumn(formula_column, formula_delegate)
        input_delegate = InputCellDelegate(self.table)
        for input_column in (3, 4, 5):
            self.table.setItemDelegateForColumn(input_column, input_delegate)
        self.table.setItemDelegateForColumn(NOTES_COLUMN, NotesPreviewDelegate(self.table))
        self.table.horizontalHeader().setVisible(False)
        self.table.horizontalScrollBar().valueChanged.connect(self._sync_table_header_to_grid)
        self.table.cellChanged.connect(self._cell_changed)
        self.table.cellDoubleClicked.connect(self._double_clicked)
        table_layout.addWidget(self.header_row)
        table_layout.addWidget(self.table)
        grid.addWidget(table_area, 1, 1, 4, 15)
        self._apply_table_dimensions()
        QTimer.singleShot(0, self._apply_table_dimensions)

        self.totals_label = QLabel()
        self.totals_label.setStyleSheet(f"background:{LABEL_BLUE}; border:1px solid {GRID}; padding:8px; font-weight:700; color:#102033;")
        self.personal_notes = QTextEdit()
        self.month_end_check = QTextEdit()
        self.personal_notes.setPlaceholderText("PERSONAL NOTES")
        self.month_end_check.setPlaceholderText("MONTH-END CHECK")
        self.personal_notes.setMinimumHeight(92)
        self.month_end_check.setMinimumHeight(92)
        self.warning_label = QLabel()
        self.warning_label.setStyleSheet("color:#b45309; font-weight:600; padding:4px;")
        grid.setColumnStretch(0, 0)
        grid.setColumnStretch(1, 1)

    def label(self, text: str) -> QLabel:
        lab = QLabel(text)
        lab.setAlignment(Qt.AlignCenter)
        lab.setMinimumHeight(26 if self.target_display else 32)
        lab.setWordWrap(True)
        lab.setStyleSheet(
            "background:#e8f3fd; border:0px; border-bottom:1px solid #c8d9e8; "
            "border-left:1px solid #c8d9e8; border-right:1px solid #b8cede; "
            f"border-radius:0px; padding:{'3px 5px' if self.target_display else '8px 10px'}; "
            f"font-size:{'7pt' if self.target_display else '9pt'}; font-weight:800; color:#0b3158;"
        )
        return lab

    def _table_header_label(self, text: str, idx: int, count: int) -> QLabel:
        lab = TableHeaderLabel(text, idx < count - 1)
        lab.setAlignment(Qt.AlignCenter)
        lab.setFixedHeight(self.table_header_height)
        single_line_total_worked = self.target_display and text == "Total Worked Hours"
        lab.setWordWrap(not single_line_total_worked)
        radius_left = "border-top-left-radius:10px;" if idx == 0 else "border-top-left-radius:0px;"
        radius_right = "border-top-right-radius:10px;" if idx == count - 1 else "border-top-right-radius:0px;"
        header_font_size = (
            " font-size:6.5pt;"
            if self.target_display
            else " font-size:9pt;"
        )
        header_padding = "4px 3px" if self.target_display else "2px 3px"
        if idx <= 2:
            header_background = "#0b3158"
        elif idx <= 6:
            header_background = "#17689d"
        elif idx <= DAILY_TOTAL_COLUMN:
            header_background = "#2b6777"
        elif idx == NOTES_COLUMN:
            header_background = "#526779"
        elif idx == CALCULATE_COLUMN:
            header_background = "#187c48"
        else:
            header_background = "#ad3035"
        lab.setStyleSheet(
            f"background:{header_background}; color:white; border:0px; "
            f"{radius_left} {radius_right} padding:{header_padding}; font-weight:800;"
            + header_font_size
        )
        return lab

    def _apply_table_dimensions(self) -> None:
        available = max(1, self.table.viewport().width() - 2)
        widths = (COMPACT_TABLE_WIDTHS if self.compact_layout else STANDARD_TABLE_WIDTHS).copy()
        if self.target_display:
            widths[STATUS_COLUMN] = TARGET_STATUS_COLUMN_WIDTH
            widths[6] = 96
        status_max_width = (
            TARGET_STATUS_COLUMN_WIDTH
            if self.target_display
            else widths[STATUS_COLUMN]
        )
        if sum(widths) < available:
            extra = available - sum(widths)
            # Preserve the carefully fitted identity columns, then share spare room
            # proportionally across every work-data column so headers stay readable
            # and no single formula or Notes column becomes visually oversized.
            expandable_columns = tuple(range(3, len(widths)))
            total_weight = sum(widths[col] for col in expandable_columns)
            allocations = [
                (extra * widths[col]) // total_weight
                for col in expandable_columns
            ]
            remainder = extra - sum(allocations)
            for offset in range(remainder):
                allocations[offset % len(allocations)] += 1
            for col, addition in zip(expandable_columns, allocations):
                widths[col] += addition
        elif widths[STATUS_COLUMN] > status_max_width:
            widths[NOTES_COLUMN] += widths[STATUS_COLUMN] - status_max_width
            widths[STATUS_COLUMN] = status_max_width
        for col, width in enumerate(widths):
            self.table.setColumnWidth(col, width)
        self._sync_table_header_to_grid()
        self.table.setMinimumHeight(
            (TARGET_TABLE_ROW_HEIGHT * 31) + 6 if self.target_display else 790
        )
        self._fit_rows_to_viewport()

    def _fit_rows_to_viewport(self) -> None:
        if self.table.rowCount() <= 0:
            return
        row_count = self.table.rowCount()
        available_height = self.table.viewport().height()
        if available_height <= 0:
            return
        minimum_height = (
            TARGET_TABLE_ROW_HEIGHT
            if self.target_display
            else STANDARD_TABLE_ROW_HEIGHT
        )
        base_height = max(minimum_height, available_height // row_count)
        extra_pixels = max(0, available_height - (base_height * row_count))
        for row in range(row_count):
            self.table.setRowHeight(row, base_height + (1 if row < extra_pixels else 0))

    def _sync_table_header_to_grid(self) -> None:
        if not hasattr(self, "header_labels"):
            return
        header_widths = [self.table.columnWidth(col) for col in range(len(self.header_labels))]
        if not header_widths:
            return
        self.header_row.setFixedWidth(self.table.width())
        left = self.table.viewport().x()
        for col, width in enumerate(header_widths):
            x = left + self.table.columnViewportPosition(col)
            if col == 0:
                width += max(0, x)
                x = min(0, x)
            elif col == len(header_widths) - 1:
                width = max(width, self.header_row.width() - x)
            self.header_labels[col].setGeometry(x, 0, width, self.header_row.height())

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        if hasattr(self, "table"):
            self._apply_table_dimensions()

    def _set_timesheet_scrollbar_hover(self, active: bool) -> None:
        bar = self.table.verticalScrollBar()
        if bar.property("hoverActive") == active:
            return
        bar.setProperty("hoverActive", active)
        bar.style().unpolish(bar)
        bar.style().polish(bar)
        bar.update()

    def eventFilter(self, watched, event) -> bool:
        if hasattr(self, "table"):
            if event.type() == QEvent.KeyPress and watched.property("timesheetRow") is not None:
                row = int(watched.property("timesheetRow"))
                col = int(watched.property("timesheetColumn"))
                if not (isinstance(watched, QComboBox) and watched.view().isVisible()):
                    if self._navigate_table_from_key(row, col, event.key()):
                        event.accept()
                        return True
            bar = self.table.verticalScrollBar()
            viewport = self.table.viewport()
            if watched is viewport:
                if event.type() == QEvent.MouseMove:
                    x = event.position().x() if hasattr(event, "position") else event.pos().x()
                    self._set_timesheet_scrollbar_hover(x >= viewport.width() - 4)
                elif event.type() == QEvent.Leave and not bar.underMouse():
                    self._set_timesheet_scrollbar_hover(False)
                elif event.type() == QEvent.Resize:
                    QTimer.singleShot(0, self._apply_table_dimensions)
            elif watched is self.table and event.type() == QEvent.Resize:
                QTimer.singleShot(0, self._apply_table_dimensions)
            elif watched is bar:
                if event.type() in (QEvent.Enter, QEvent.MouseMove):
                    self._set_timesheet_scrollbar_hover(True)
                elif event.type() == QEvent.Leave and not viewport.underMouse():
                    self._set_timesheet_scrollbar_hover(False)
        return super().eventFilter(watched, event)

    def _navigate_table_from_key(self, row: int, col: int, key: int) -> bool:
        row_delta = {
            Qt.Key_Up: -1,
            Qt.Key_Down: 1,
            Qt.Key_PageUp: -10,
            Qt.Key_PageDown: 10,
        }.get(key)
        if row_delta is not None:
            target_row = max(0, min(self.table.rowCount() - 1, row + row_delta))
            target_col = col
        elif key == Qt.Key_Home:
            target_row, target_col = 0, col
        elif key == Qt.Key_End:
            target_row, target_col = self.table.rowCount() - 1, col
        elif key == Qt.Key_Left:
            target_row, target_col = row, max(0, col - 1)
        elif key == Qt.Key_Right:
            target_row, target_col = row, min(self.table.columnCount() - 1, col + 1)
        else:
            return False

        self.table.setCurrentCell(target_row, target_col)
        target_item = self.table.item(target_row, target_col)
        if target_item is not None:
            self.table.scrollToItem(target_item, QAbstractItemView.PositionAtCenter)

        target_widget = self.table.cellWidget(target_row, target_col)
        if target_widget is not None:
            focus_widget = target_widget.findChild(QComboBox) or target_widget.findChild(QPushButton)
            if focus_widget is not None:
                focus_widget.setFocus(Qt.TabFocusReason)
                return True
        self.table.setFocus(Qt.TabFocusReason)
        return True

    def set_contract_display(self, settings) -> None:
        self.wage_label.setText(yen(settings.base_hourly_wage))
        self.standard_label.setText(str(settings.standard_daily_hours))

    def build_month(
        self,
        year: int,
        month: int,
        saved: list[DailyInput],
        settings,
        initial_week_context: dict[date, tuple[int, int]] | None = None,
    ) -> None:
        self._loading = True
        self.table.setRowCount(monthrange(year, month)[1])
        saved_by_day = {row.work_date.day: row for row in saved}
        self.breaks_by_day = {day: row.breaks for day, row in saved_by_day.items()}
        monthly_inputs: list[DailyInput] = []
        for day in range(1, monthrange(year, month)[1] + 1):
            work_date = date(year, month, day)
            row = saved_by_day.get(day, DailyInput(work_date))
            self.row_dates[day - 1] = work_date
            if row.status == "Employer Leave 60%":
                row.status = "Employer Leave"
            if row.status == "Sunday Holiday":
                row.status = SUNDAY_HOLIDAY_STATUS
            if row.status == "Work" and work_date.weekday() == 5:
                row.status = SATURDAY_WORK_STATUS
            elif row.status == "Work" and work_date.weekday() == 6:
                row.status = SUNDAY_HOLIDAY_STATUS
            monthly_inputs.append(row)
            day_type = settings.weekly_day_types[work_date.weekday()]
            day_color = (
                TABLE_SUNDAY
                if day_type == STATUTORY_HOLIDAY
                else TABLE_SATURDAY
                if day_type == NON_STATUTORY_HOLIDAY
                else TABLE_WEEKDAY
            )
            date_item = item(work_date.strftime("%d-%b"), day_color)
            day_item = item(work_date.strftime("%a"), day_color)
            self._set_combo(day - 1, STATUS_COLUMN, STATUSES, row.status)
            self.table.setItem(day - 1, DATE_COLUMN, date_item)
            self.table.setItem(day - 1, DAY_COLUMN, day_item)
            self.table.setItem(day - 1, 3, item(row.actual_in.strftime("%H:%M") if row.actual_in else "", TABLE_INPUT, True))
            self.table.setItem(day - 1, 4, item(row.actual_out.strftime("%H:%M") if row.actual_out else "", TABLE_INPUT, True))
            self.table.setItem(day - 1, 5, item("", TABLE_INPUT, True))
            note_cell = item(row.notes, TABLE_INPUT, False, Qt.AlignLeft | Qt.AlignVCenter)
            self.table.setItem(day - 1, NOTES_COLUMN, note_cell)
            self._set_calculate_button(day - 1)
            self._set_reset_button(day - 1)
            self.table.setRowHeight(
                day - 1,
                TARGET_TABLE_ROW_HEIGHT if self.target_display else STANDARD_TABLE_ROW_HEIGHT,
            )
        results, totals = summarize_month(monthly_inputs, settings, initial_week_context)
        self.rows_by_day = {row.work_date.day: (row, result) for row, result in results}
        for day, (row_input, result) in self.rows_by_day.items():
            self._write_calculated(day - 1, row_input, result, settings)
        self._write_totals(totals, settings)
        self._fit_rows_to_viewport()
        QTimer.singleShot(0, self._fit_rows_to_viewport)
        self._loading = False

    def _set_combo(self, row: int, col: int, values: list[str], current: str) -> None:
        combo = QComboBox()
        combo.setProperty("timesheetRow", row)
        combo.setProperty("timesheetColumn", col)
        combo.installEventFilter(self)
        combo.addItems(values)
        combo.setCurrentText(current)
        combo_font_size = (
            ""
            if col == STATUS_COLUMN and self.target_display
            else "font-size:7pt;"
            if col == STATUS_COLUMN and self.compact_layout
            else "font-size:9pt;"
            if col == STATUS_COLUMN
            else "font-size:7pt;"
            if self.target_display
            else "font-size:8pt;"
            if self.compact_layout
            else "font-size:7pt;"
        )
        dropdown_font_size = (
            ""
            if self.target_display
            else "font-size:7pt;"
            if self.compact_layout
            else "font-size:9pt;"
        )
        combo_padding = (
            "1px 1px 1px 3px"
            if self.target_display
            else "3px 1px 3px 7px"
            if col == STATUS_COLUMN
            else "3px 1px 3px 6px"
        )
        work_date = self.row_dates.get(row)
        combo_background = (
            "#fff0f2"
            if col == STATUS_COLUMN and work_date and work_date.weekday() == 6
            else "#eef3f8"
            if col == STATUS_COLUMN and work_date and work_date.weekday() == 5
            else "#eef5fb"
        )
        combo.setStyleSheet(
            f"QComboBox {{ background:{combo_background}; color:#102033; border:1px solid #c5d9ea; "
            f"border-radius:{'5px' if self.target_display else '8px'}; "
            f"padding:{combo_padding}; "
            + combo_font_size
            + " }"
            "QComboBox:hover { border-color:#4d8bc0; }"
            "QComboBox::drop-down { border:0; width:1px; }"
            "QComboBox QAbstractItemView { background:#ffffff; color:#102033; border:1px solid #8fb2d4; "
            "border-radius:6px; padding:4px; selection-background-color:#d7ecff; selection-color:#071a3d; }"
        )
        combo.view().setStyleSheet(
            "QListView { background:#ffffff; color:#102033; border:1px solid #8fb2d4; "
            "selection-background-color:#d7ecff; selection-color:#071a3d; outline:0; "
            + dropdown_font_size
            + " }"
            "QListView::item { min-height:26px; padding:5px 8px; }"
        )
        if col == STATUS_COLUMN:
            combo.view().setMinimumWidth(STATUS_POPUP_MIN_WIDTH)
        if col == STATUS_COLUMN and work_date and work_date.weekday() == 5:
            combo.setToolTip(
                "Saturday Work normally uses Hourly Wage + 50 円 for every premium calculation."
            )
        elif col == STATUS_COLUMN and work_date and work_date.weekday() == 6:
            combo.setToolTip(
                "Sunday Work normally uses Hourly Wage + 50 円. On the seventh worked day, "
                "statutory +35% replaces +50 円; night hours total 160%."
            )
        combo.setToolTip("")
        combo.currentTextChanged.connect(lambda _=None, r=row, c=col: self.combo_changed(r, c))
        if col == STATUS_COLUMN:
            combo.setMinimumWidth(0)
            combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            holder = QWidget()
            holder.setStyleSheet("background: transparent;")
            holder_layout = QHBoxLayout(holder)
            holder_layout.setContentsMargins(
                TARGET_CONTROL_SIDE_GAP if self.target_display else 3,
                TARGET_CONTROL_SIDE_GAP if self.target_display else 0,
                TARGET_CONTROL_SIDE_GAP if self.target_display else 3,
                TARGET_CONTROL_SIDE_GAP if self.target_display else 0,
            )
            holder_layout.setSpacing(0)
            holder_layout.addWidget(combo, 1)
            self.table.setCellWidget(row, col, holder)
            if self.target_display:
                status_font = QFont(combo.font())
                status_font.setPointSizeF(TARGET_STATUS_FONT_SIZE)
                combo.setFont(status_font)
                dropdown_font = QFont(combo.view().font())
                dropdown_font.setPointSizeF(TARGET_STATUS_FONT_SIZE)
                combo.view().setFont(dropdown_font)
            return
        self.table.setCellWidget(row, col, combo)

    def _set_calculate_button(self, row: int) -> None:
        button = QPushButton("Calculate")
        button.setProperty("timesheetRow", row)
        button.setProperty("timesheetColumn", CALCULATE_COLUMN)
        button.installEventFilter(self)
        button.setStyleSheet(
            "QPushButton { background:#16803c; color:white; border:1px solid #126b34; border-radius:6px; font-weight:800;"
            + (
                " padding:1px 2px; font-size:6.5pt;"
                if self.target_display
                else " padding:4px 3px; font-size:7pt;"
                if self.compact_layout
                else " padding:1px 7px;"
            )
            + " } QPushButton:hover { background:#117333; border-color:#0d5a29; }"
            " QPushButton:pressed { background:#0d612b; }"
            " QPushButton:focus { border:2px solid #70b98b; }"
        )
        button.clicked.connect(lambda _=False, r=row: self.calculate_row_clicked(r))
        self._set_action_widget(row, CALCULATE_COLUMN, button)

    def _set_reset_button(self, row: int) -> None:
        button = QPushButton("Reset")
        button.setProperty("timesheetRow", row)
        button.setProperty("timesheetColumn", RESET_COLUMN)
        button.installEventFilter(self)
        button.setStyleSheet(
            "QPushButton { background:#c52222; color:white; border:1px solid #a91b1b; border-radius:6px; font-weight:800;"
            + (
                " padding:1px 2px; font-size:6.5pt;"
                if self.target_display
                else " padding:4px 3px; font-size:7pt;"
                if self.compact_layout
                else " padding:1px 7px;"
            )
            + " } QPushButton:hover { background:#ad1d1d; border-color:#901616; }"
            " QPushButton:pressed { background:#941818; }"
            " QPushButton:focus { border:2px solid #e38a8a; }"
        )
        button.clicked.connect(lambda _=False, r=row: self.reset_row_clicked(r))
        self._set_action_widget(row, RESET_COLUMN, button)

    def _set_action_widget(self, row: int, col: int, button: QPushButton) -> None:
        button.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        holder = QWidget()
        holder.setStyleSheet("background:transparent;")
        layout = QHBoxLayout(holder)
        layout.setContentsMargins(
            TARGET_CONTROL_SIDE_GAP if self.target_display else 3,
            TARGET_CONTROL_SIDE_GAP if self.target_display else 0,
            TARGET_CONTROL_SIDE_GAP if self.target_display else 3,
            TARGET_CONTROL_SIDE_GAP if self.target_display else 0,
        )
        layout.setSpacing(0)
        layout.addWidget(button)
        self.table.setCellWidget(row, col, holder)

    def calculate_row_clicked(self, row: int) -> None:
        window = self.window()
        if hasattr(window, "calculate_row"):
            window.calculate_row(row)

    def reset_row_clicked(self, row: int) -> None:
        window = self.window()
        if hasattr(window, "reset_row"):
            window.reset_row(row)

    def combo_changed(self, row: int, col: int) -> None:
        if self._loading:
            return
        window = self.window()
        if hasattr(window, "autosave_row"):
            window.autosave_row(row)

    def combo(self, row: int, col: int) -> str:
        combo = self.combo_widget(row, col)
        return combo.currentText() if combo else ""

    def combo_widget(self, row: int, col: int) -> QComboBox | None:
        widget = self.table.cellWidget(row, col)
        if isinstance(widget, QComboBox):
            return widget
        if widget:
            combo = widget.findChild(QComboBox)
            if isinstance(combo, QComboBox):
                return combo
        return None

    def parse_user_time(self, raw_text: str) -> time | None:
        text_value = raw_text.strip().upper().replace(" ", "")
        if not text_value or text_value in {"-", "–", "—"}:
            return None
        for fmt in ("%H:%M", "%H%M", "%I:%M%p", "%I%M%p", "%I%p"):
            try:
                return datetime.strptime(text_value, fmt).time().replace(second=0, microsecond=0)
            except ValueError:
                pass
        if ":" in text_value:
            hour_text, minute_text = text_value.split(":", 1)
            if hour_text.isdigit() and minute_text.isdigit():
                hour = int(hour_text)
                minute = int(minute_text)
                if 0 <= hour <= 23 and 0 <= minute <= 59:
                    return time(hour, minute)
        if text_value.isdigit():
            hour = int(text_value)
            if 0 <= hour <= 23:
                return time(hour, 0)
        raise ValueError(f"Invalid time: {raw_text}. Use 24-hour format like 20:30 or AM/PM like 8:30 PM.")

    def daily_input(self, year: int, month: int, day: int) -> DailyInput:
        work_date = date(year, month, day)

        def text(col: int) -> str:
            table_item = self.table.item(day - 1, col)
            return table_item.text() if table_item else ""

        break_hours = None
        if not self.breaks_by_day.get(day):
            try:
                raw = text(5).strip()
                break_hours = (Decimal(raw) / Decimal("60")) if raw else None
            except InvalidOperation:
                break_hours = None
        actual_in = self.parse_user_time(text(3))
        actual_out = self.parse_user_time(text(4))
        status = self.combo(day - 1, STATUS_COLUMN)
        if not status and (actual_in or actual_out):
            status = (
                SATURDAY_WORK_STATUS
                if work_date.weekday() == 5
                else SUNDAY_HOLIDAY_STATUS
                if work_date.weekday() == 6
                else "Work"
            )
        return DailyInput(
            work_date=work_date,
            status=status,
            schedule_ref="",
            actual_in=actual_in,
            actual_out=actual_out,
            breaks=self.breaks_by_day.get(day, []),
            total_break_hours=break_hours,
            notes=text(NOTES_COLUMN),
        )

    def all_inputs(self, year: int, month: int) -> list[DailyInput]:
        return [self.daily_input(year, month, day) for day in range(1, self.table.rowCount() + 1)]

    def _money_for_minutes(self, minutes: int, hourly_rate: Decimal) -> Decimal:
        return Decimal(minutes) * hourly_rate / Decimal("60")

    def _overtime_pay_for_minutes(self, overtime_minutes: int, over_60_minutes: int, settings) -> Decimal:
        base_pay = self._money_for_minutes(overtime_minutes, settings.base_hourly_wage)
        overtime_premium = base_pay * settings.overtime_premium
        over_60_extra = self._money_for_minutes(over_60_minutes, settings.base_hourly_wage) * (settings.over_60_total_premium - settings.overtime_premium)
        return base_pay + overtime_premium + over_60_extra

    def _calculation_note(self, result: DailyResult) -> str:
        if result.employer_leave_allowance:
            return f"Employer Leave 60%={yen(result.employer_leave_allowance)} = {yen(result.total_pay_display)}"
        if result.paid_leave_pay:
            return f"Paid Leave={yen(result.paid_leave_pay)} = {yen(result.total_pay_display)}"
        if result.worked_minutes <= 0:
            return ""
        parts = [f"Base {h(result.worked_minutes)}={yen(result.base_pay)}"]
        if result.overtime_premium_pay:
            parts.append(f"Over Time +25%={yen(result.overtime_premium_pay)}")
        if result.over_60_extra_pay:
            parts.append(f"Over 60h extra={yen(result.over_60_extra_pay)}")
        if result.late_night_pay:
            parts.append(f"Night Shift +25%={yen(result.late_night_pay)}")
        return " + ".join(parts) + f" = {yen(result.total_pay_display)}"

    def _write_calculated(self, row: int, row_input: DailyInput, result: DailyResult, settings) -> None:
        overtime_premium = result.overtime_premium_pay + result.over_60_extra_pay
        has_work = result.worked_minutes > 0
        unused = "—" if row_input.status else ""
        if row_input.status:
            for col, value in ((3, row_input.actual_in), (4, row_input.actual_out)):
                if value is None:
                    self.table.blockSignals(True)
                    self.table.item(row, col).setText("—")
                    self.table.blockSignals(False)
        overtime_terms: list[tuple[Decimal, int]] = []
        night_terms: list[tuple[Decimal, int]] = []
        holiday_terms: list[tuple[Decimal, int]] = []
        premium_base_rate = settings.base_hourly_wage
        base_pay_rate = premium_base_rate
        for segment in result.segments:
            base_rate = premium_base_rate
            if segment.is_overtime:
                overtime_rate = base_rate * (
                    settings.over_60_total_premium
                    if segment.is_over_60
                    else settings.overtime_premium
                )
                overtime_terms.append((overtime_rate, segment.paid_minutes))
            if segment.is_late_night:
                night_terms.append(
                    (
                        base_rate * settings.late_night_premium,
                        segment.paid_minutes,
                    )
                )
            if segment.is_holiday:
                holiday_terms.append(
                    (
                        base_rate * settings.holiday_premium,
                        segment.paid_minutes,
                    )
                )
        weekend_allowance = self._money_for_minutes(
            result.saturday_minutes,
            settings.saturday_allowance_per_hour,
        )
        calculated_cells = [
            (5, m(result.break_minutes) if has_work else unused, TABLE_INPUT),
            (6, worked_h(result.worked_minutes) if has_work else unused, TABLE_CALCULATED),
            (7, base_rate_display(
                result.saturday_minutes,
                result.holiday_minutes,
                result.worked_minutes,
                settings,
            ) if has_work else unused, TABLE_BASE_PAY),
            (8, pay_formula(
                base_pay_rate,
                result.worked_minutes,
                result.base_pay,
            ) if has_work else unused, TABLE_BASE_PAY),
            (9, pay_formula_terms(night_terms, result.late_night_pay)
            if result.late_night_pay
            else unused, TABLE_PREMIUM),
            (10, pay_formula_terms(overtime_terms, overtime_premium)
            if overtime_premium
            else unused, TABLE_PREMIUM),
            (WEEKEND_ALLOWANCE_COLUMN, pay_formula(
                settings.saturday_allowance_per_hour,
                result.saturday_minutes,
                weekend_allowance,
            ) if weekend_allowance else unused, TABLE_PREMIUM),
            (HOLIDAY_PREMIUM_COLUMN, pay_formula_terms(holiday_terms, result.holiday_premium_pay)
            if result.holiday_premium_pay
            else unused, TABLE_PREMIUM),
            (DAILY_TOTAL_COLUMN, yen(result.total_pay_display) if result.total_pay_display else unused, TABLE_PAY),
        ]
        for col, value, color in calculated_cells:
            self.table.blockSignals(True)
            self.table.setItem(row, col, item(value, color, col == 5))
            self.table.blockSignals(False)
    def _write_totals(self, totals: MonthlyTotals, settings) -> None:
        self.summary_values["Total Worked"].setText(h(totals.worked_minutes))
        overtime_premium = totals.overtime_premium_pay + totals.over_60_extra_pay
        self.summary_values["Base Pay 100%"].setText(
            hours_and_yen(totals.worked_minutes, totals.base_pay)
        )
        self.summary_values["Over Time Premium +25%"].setText(
            hours_and_yen(totals.overtime_minutes, overtime_premium)
        )
        self.summary_values["Night Premium +25%"].setText(
            hours_and_yen(totals.late_night_minutes, totals.late_night_pay)
        )
        weekend_adjustment = self._money_for_minutes(
            totals.saturday_minutes,
            settings.saturday_allowance_per_hour,
        )
        self.summary_values["Weekend +50 円/hr"].setText(
            hours_and_yen(totals.saturday_minutes, weekend_adjustment)
        )
        if "Paid Leave" in self.summary_values:
            self.summary_values["Paid Leave"].setText(yen(totals.paid_leave_pay))
        if "Employer Leave 60%" in self.summary_values:
            self.summary_values["Employer Leave 60%"].setText(yen(totals.employer_leave_allowance))
        self.summary_values["Workdays"].setText(str(totals.workdays))
        self.summary_values["Estimated Pay Total"].setText(yen(totals.total_pay))
        self.totals_label.setText(
            f"MONTHLY TOTALS   Total Worked {h(totals.worked_minutes)}   Over Time {h(totals.overtime_minutes)}   "
            f"Night Shift {h(totals.late_night_minutes)}   "
            f"Estimated Monthly Salary {yen(totals.total_pay)}"
        )
        self.warning_label.setText("  ".join(totals.warnings))

    def _cell_changed(self, row: int, col: int) -> None:
        if self._loading:
            return
        if col in (3, 4, 5, NOTES_COLUMN):
            if col == 5:
                self.breaks_by_day.pop(row + 1, None)
            if col == NOTES_COLUMN:
                note_cell = self.table.item(row, col)
                if note_cell is not None:
                    self.table.viewport().update()
            window = self.window()
            if hasattr(window, "autosave_row"):
                window.autosave_row(row)
            return

    def _double_clicked(self, row: int, col: int) -> None:
        if col == NOTES_COLUMN:
            self._open_notes_editor(row)
            return
        window = self.window()
        if hasattr(window, "sheet_double_clicked"):
            window.sheet_double_clicked(row, col)

    def _open_notes_editor(self, row: int) -> None:
        cell = self.table.item(row, NOTES_COLUMN)
        if cell is None:
            cell = item("", TABLE_INPUT, False, Qt.AlignLeft | Qt.AlignVCenter)
            self.table.setItem(row, NOTES_COLUMN, cell)

        dialog = QDialog(self)
        dialog.setWindowTitle(f"Notes - Day {row + 1}")
        dialog.setModal(True)
        dialog.resize(460, 300)
        dialog.setStyleSheet(
            """
            QDialog {
                background: #f8fbff;
            }
            QLabel {
                color: #002b55;
                font-weight: 700;
                font-size: 11pt;
            }
            QTextEdit {
                background: #ffffff;
                border: 1px solid #8fb0cc;
                border-radius: 8px;
                padding: 10px;
                selection-background-color: #1f6fb2;
                font-size: 11pt;
            }
            QPushButton {
                background: #155c99;
                color: white;
                border: 1px solid #0d4778;
                border-radius: 7px;
                padding: 8px 18px;
                font-weight: 700;
            }
            QPushButton:hover {
                background: #1c6fb7;
            }
            QPushButton:pressed {
                background: #0d4778;
            }
            """
        )

        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(10)

        title = QLabel("Notes")
        editor = QTextEdit()
        editor.setPlaceholderText("Write your note here...")
        editor.setPlainText(cell.text())
        editor.setFocus()

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)

        layout.addWidget(title)
        layout.addWidget(editor)
        layout.addWidget(buttons)

        if dialog.exec():
            note_text = editor.toPlainText().strip()
            cell.setText(note_text)
            self.table.viewport().update()
