from __future__ import annotations

from PySide6.QtPrintSupport import QPrintDialog, QPrintPreviewDialog, QPrinter
from PySide6.QtWidgets import QWidget


def show_print_preview(parent: QWidget, paint_callback) -> None:
    printer = QPrinter(QPrinter.HighResolution)
    printer.setPageOrientation(QPrinter.Landscape)
    dialog = QPrintPreviewDialog(printer, parent)
    dialog.paintRequested.connect(paint_callback)
    dialog.exec()


def print_direct(parent: QWidget, paint_callback) -> None:
    printer = QPrinter(QPrinter.HighResolution)
    printer.setPageOrientation(QPrinter.Landscape)
    dialog = QPrintDialog(printer, parent)
    if dialog.exec() == QPrintDialog.Accepted:
        paint_callback(printer)
