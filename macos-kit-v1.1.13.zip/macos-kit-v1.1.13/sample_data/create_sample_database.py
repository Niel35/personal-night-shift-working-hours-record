from __future__ import annotations

from datetime import date, time
from pathlib import Path

import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from calculations.models import BreakInterval, DailyInput
from database.database import TimesheetDatabase

db = TimesheetDatabase(ROOT / "sample_data" / "sample_timesheet.db")
rows = [
    DailyInput(date(2026, 7, 1), "Work", "", time(18, 0), time(4, 0), [BreakInterval(time(23, 0), time(0, 0))], notes="Example 1"),
    DailyInput(date(2026, 7, 2), "Work", "", time(19, 0), time(4, 0), [BreakInterval(time(23, 0), time(0, 0))]),
    DailyInput(date(2026, 7, 4), "Work", "", time(19, 0), time(4, 0), [BreakInterval(time(23, 0), time(0, 0))], notes="Saturday"),
    DailyInput(date(2026, 7, 5), "Holiday Work", "", time(23, 0), time(7, 0), [BreakInterval(time(3, 0), time(4, 0))], notes="Holiday Work"),
]
for row in rows:
    db.upsert_record(row)
db.save_month_notes("2026-07", "Sample Worker", "4026", "Night Shift", "Sample notes", "Reviewed.")
print(db.path)
