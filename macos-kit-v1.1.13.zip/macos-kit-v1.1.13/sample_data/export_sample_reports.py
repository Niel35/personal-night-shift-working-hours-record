from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from database.database import TimesheetDatabase
from exports.excel_export import export_month_excel
from exports.pdf_export import export_month_pdf

db = TimesheetDatabase(ROOT / "sample_data" / "sample_timesheet.db")
rows, totals = db.monthly_results(2026, 7)
rows_by_day = {row.work_date.day: (row, result) for row, result in rows}
notes = db.month_notes("2026-07")
settings = db.settings()
excel = export_month_excel(ROOT / "sample_data" / "sample_timesheet.xlsx", 2026, 7, rows_by_day, totals, settings, notes)
pdf = export_month_pdf(ROOT / "sample_data" / "sample_timesheet.pdf", 2026, 7, rows_by_day, totals, settings, notes)
print(excel)
print(pdf)
