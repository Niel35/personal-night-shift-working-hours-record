from __future__ import annotations

import shutil
import sqlite3
from datetime import datetime
from pathlib import Path


def backup_database(db_path: Path, target: str | Path) -> Path:
    target_path = Path(target)
    target_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(db_path, target_path)
    return target_path


def restore_database(db_path: Path, source: str | Path) -> None:
    shutil.copy2(Path(source), db_path)


def log_backup(conn: sqlite3.Connection, action: str, file_path: str | Path) -> None:
    conn.execute(
        "INSERT INTO backups_log (action,file_path,created_at) VALUES (?,?,?)",
        (action, str(file_path), datetime.now().isoformat(timespec="seconds")),
    )
    conn.commit()
