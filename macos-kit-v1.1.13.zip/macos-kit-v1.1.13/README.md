# Personal Night-Shift Working Hours Record

Offline Windows desktop A4 landscape monthly timesheet for a night-shift worker in Japan.

The main screen is the sheet: dark navy title bar, left-side worker/contract panel, monthly totals, light-blue labels, pale-yellow editable cells, pale-blue calculated cells, pale-green salary cells, thin spreadsheet borders, and one row per day. Enter clock-in, clock-out, and break minutes, then click the row's Calc button to fill the calculated cells.

No Commute Method, Commute Allowance, or Bike column is included.

## Run

```bat
python main.py
```

or:

```bat
run_app.bat
```

## Build

```bat
build_windows.bat
```

The executable is built into:

```text
dist\PersonalNightShiftWorkingHoursRecord
```

## Build macOS User App

macOS apps must be built on macOS. On a Mac, run:

```bash
chmod +x build_macos_user.sh
./build_macos_user.sh
```

The script creates a user edition app where the update button says `New Update`, then packages:

```text
release_packages/macos_user_install/v1.1.0/PersonalNightShiftWorkingHoursRecord-macOS-1.1.0.dmg
release_packages/macos_user_install/v1.1.0/PersonalNightShiftWorkingHoursRecord-macOS-1.1.0.zip
```

## Internet Updates with GitHub

The app includes a quiet startup update check and a user-facing `New Update` button. GitHub Releases can host the update files.

1. Create a public GitHub repository for releases.
2. Build the Windows app and the macOS app.
3. Upload these files to a GitHub Release tagged like `v1.1.1`:

```text
PersonalNightShiftWorkingHoursRecord-1.1.1.zip
PersonalNightShiftWorkingHoursRecord-macOS-1.1.1.zip
update.json
```

4. Create `update.json` for that release:

```bat
python packaging\create_github_update_manifest.py ^
  --owner YOUR_GITHUB_NAME ^
  --repo YOUR_REPO ^
  --version 1.1.1 ^
  --windows-zip path\to\PersonalNightShiftWorkingHoursRecord-1.1.1.zip ^
  --macos-zip path\to\PersonalNightShiftWorkingHoursRecord-macOS-1.1.1.zip ^
  --notes "Latest fixes and improvements." ^
  --output update.json
```

5. Set `UPDATE_MANIFEST_URL` in `app\app_info.py` to the stable GitHub URL for the latest `update.json`, then rebuild and share the app once with that URL configured.

For GitHub Releases, use this stable latest-release URL:

```text
https://github.com/YOUR_GITHUB_NAME/YOUR_REPO/releases/latest/download/update.json
```

When a newer `latest_version` is published, installed copies download the correct platform zip, close themselves, install the update, and reopen. The user's saved data stays outside the install folder.

## Database

The app stores records locally in SQLite:

```text
%USERPROFILE%\AppData\Local\PersonalNightShiftWorkingHoursRecord\timesheet.db
```

## Tests

```bat
python -m pytest
```

Tests cover all seven requested examples, overnight shifts, multiple-break-ready interval handling, daily overtime, weekly overtime, monthly over-60 overtime splitting, late-night overlap, Holiday Work, and weekend 50円/hour allowance.

## Exports

- Excel export visually matches the app sheet colors and layout.
- PDF export creates an A4 landscape one-page personal record.
- Print Preview and Print render the visible sheet in landscape.

Important: this application is for personal estimation only. Official company attendance records and payslips control the final salary.
