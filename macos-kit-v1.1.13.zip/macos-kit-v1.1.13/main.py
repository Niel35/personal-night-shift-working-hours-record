from __future__ import annotations

import logging
import os
import sys
import ctypes
import tempfile
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication

from app.app_info import APP_NAME, OFFICIAL_ICON_PATH
from app.main_window import MainWindow
from app.popup_guard import install_popup_guard
from database.database import TimesheetDatabase


APP_DATA_FOLDER = "PersonalNightShiftWorkingHoursRecord"
LOG_FORMAT = "%(asctime)s %(levelname)s %(name)s %(message)s"


def app_log_dir() -> Path:
    if sys.platform == "win32":
        local_app_data = os.environ.get("LOCALAPPDATA")
        if local_app_data:
            return Path(local_app_data) / APP_DATA_FOLDER / "logs"
        return Path.home() / "AppData" / "Local" / APP_DATA_FOLDER / "logs"
    return Path.home() / ".local" / "share" / APP_DATA_FOLDER / "logs"


def fallback_log_dir() -> Path:
    return Path(tempfile.gettempdir()) / APP_DATA_FOLDER / "logs"


def configure_logging() -> Path | None:
    root_logger = logging.getLogger()
    for handler in list(root_logger.handlers):
        root_logger.removeHandler(handler)
        handler.close()

    formatter = logging.Formatter(LOG_FORMAT)
    for log_dir in (app_log_dir(), fallback_log_dir()):
        try:
            log_dir.mkdir(parents=True, exist_ok=True)
            handler = logging.FileHandler(log_dir / "app.log", encoding="utf-8")
        except OSError:
            continue
        handler.setFormatter(formatter)
        root_logger.addHandler(handler)
        root_logger.setLevel(logging.INFO)
        return log_dir / "app.log"

    logging.basicConfig(level=logging.INFO, format=LOG_FORMAT)
    return None


def configure_windows_taskbar_identity() -> None:
    if sys.platform != "win32":
        return
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
            "Niel35.PersonalNightShiftWorkingHoursRecord"
        )
    except (AttributeError, OSError):
        logging.getLogger(__name__).exception("Could not set the Windows taskbar identity")


def main() -> int:
    configure_logging()
    configure_windows_taskbar_identity()
    QApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationDisplayName(APP_NAME)
    app.setOrganizationName("Niel35")
    install_popup_guard(app)
    app.setWindowIcon(QIcon(str(OFFICIAL_ICON_PATH)))
    window = MainWindow(TimesheetDatabase())
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
