from __future__ import annotations

from calendar import monthrange
from datetime import date, datetime, time
from decimal import Decimal, InvalidOperation

from PySide6.QtCore import QDate, QEvent, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QGraphicsDropShadowEffect,
    QGridLayout,
    QHeaderView,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QSizePolicy,
    QStyledItemDelegate,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from calculations.models import BreakInterval, DailyInput, DailyResult, MonthlyTotals
from calculations.formatting import hours_minutes
from calculations.salary_engine import summarize_month
from .app_info import IS_USER_EDITION, OFFICIAL_HEADER_LOGO_PATH
from .styles import CALC_BLUE, GRID, HEADER_BLUE, INPUT_YELLOW, LABEL_BLUE, NAVY, SALARY_GREEN

STATUSES = ["", "Work", "Holiday Work", "Employer Leave", "Day Off", "Paid Leave", "Sick Leave", "Absent"]
SCROLLBAR_LANE_WIDTH = 12
TABLE_CORNER_INSET = 8
TABLE_HEADER_HEIGHT = 34
COMPACT_TABLE_HEADER_HEIGHT = 46
# A 14-inch Retina MacBook Pro exposes a roughly 1512-point-wide workspace.
# Keep the compact profile active through 1600 logical pixels.
COMPACT_SCREEN_MAX_WIDTH = 1600
TABLE_BASE_WIDTHS = [62, 50, 118, 70, 70, 64, 102, 94, 86, 86, 76, 76, 108, 132, 102, 80]


def uses_compact_layout(screen_width: int) -> bool:
    return screen_width <= COMPACT_SCREEN_MAX_WIDTH


class MonthYearSelector(QWidget):
    dateChanged = Signal(QDate)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.month_combo = QComboBox()
        self.year_combo = QComboBox()
        self.month_combo.setObjectName("recordMonthCombo")
        self.year_combo.setObjectName("recordYearCombo")
        self.month_combo.addItems([f"{month:02d}" for month in range(1, 13)])
        current_year = date.today().year
        self.year_combo.addItems([str(year) for year in range(current_year - 10, current_year + 11)])
        self.month_combo.setFrame(False)
        self.year_combo.setFrame(False)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self.year_combo, 3)
        layout.addWidget(self.month_combo, 2)

        self.month_combo.currentIndexChanged.connect(self._emit_date_changed)
        self.year_combo.currentIndexChanged.connect(self._emit_date_changed)
        self.apply_panel_style()
        self.setDate(QDate.currentDate())

    def apply_panel_style(self) -> None:
        self.setStyleSheet(
            """
            MonthYearSelector {
                background: #f2f8fd;
                border: 0px;
                border-right: 1px solid #c8d9e8;
                border-bottom: 1px solid #c8d9e8;
            }
            QComboBox#recordMonthCombo, QComboBox#recordYearCombo {
                background: transparent;
                color: #102033;
                border: 0px;
                border-radius: 0px;
                margin: 0px;
                padding: 7px 8px;
                font-weight: 500;
            }
            QComboBox#recordYearCombo {
                border-right: 1px solid #d5e3f0;
            }
            QComboBox#recordMonthCombo:hover, QComboBox#recordYearCombo:hover {
                background: #e8f3fd;
            }
            QComboBox#recordMonthCombo:focus, QComboBox#recordYearCombo:focus {
                background: #e8f3fd;
                border: 0px;
            }
            QComboBox::drop-down {
                border: 0px;
                background: transparent;
                width: 22px;
            }
            QComboBox::down-arrow {
                width: 10px;
                height: 10px;
            }
            QComboBox QAbstractItemView {
                background: #ffffff;
                color: #102033;
                border: 1px solid #8fb2d4;
                border-radius: 6px;
                padding: 4px;
                selection-background-color: #d7ecff;
                selection-color: #071a3d;
                outline: 0;
            }
            """
        )

    def paintEvent(self, event) -> None:
        super().paintEvent(event)
        painter = QPainter(self)
        painter.setPen(QPen(QColor("#c8d9e8"), 1))
        painter.drawLine(0, self.height() - 1, self.width(), self.height() - 1)
        painter.drawLine(self.width() - 1, 0, self.width() - 1, self.height())

    def setDate(self, selected_date) -> None:
        qdate = selected_date if isinstance(selected_date, QDate) else QDate(selected_date.year, selected_date.month, selected_date.day)
        year_text = str(qdate.year())
        if self.year_combo.findText(year_text) < 0:
            self.year_combo.addItem(year_text)
            self.year_combo.model().sort(0)
        self.year_combo.blockSignals(True)
        self.month_combo.blockSignals(True)
        self.year_combo.setCurrentText(year_text)
        self.month_combo.setCurrentText(f"{qdate.month():02d}")
        self.month_combo.blockSignals(False)
        self.year_combo.blockSignals(False)
        self._emit_date_changed()

    def date(self) -> QDate:
        return QDate(int(self.year_combo.currentText()), int(self.month_combo.currentText()), 1)

    def _emit_date_changed(self) -> None:
        self.dateChanged.emit(self.date())


class TableHeaderLabel(QLabel):
    def __init__(self, text: str, draw_right_divider: bool, parent: QWidget | None = None) -> None:
        super().__init__(text, parent)
        self.draw_right_divider = draw_right_divider

    def paintEvent(self, event) -> None:
        super().paintEvent(event)
        if not self.draw_right_divider:
            return
        painter = QPainter(self)
        painter.setPen(QPen(QColor("#2d76ae"), 1))
        x = self.width() - 1
        painter.drawLine(x, 0, x, self.height())


class NotesPreviewDelegate(QStyledItemDelegate):
    def initStyleOption(self, option, index) -> None:
        super().initStyleOption(option, index)
        option.text = option.text.replace("\r", " ").replace("\n", " ")
        option.textElideMode = Qt.ElideRight
        option.displayAlignment = Qt.AlignLeft | Qt.AlignVCenter

    def createEditor(self, parent, option, index):
        return None


def item(text: str, color: str | None = None, editable: bool = False, alignment=Qt.AlignCenter) -> QTableWidgetItem:
    it = QTableWidgetItem(text)
    if color:
        it.setBackground(QColor(color))
    it.setTextAlignment(alignment)
    flags = Qt.ItemIsSelectable | Qt.ItemIsEnabled
    if editable:
        flags |= Qt.ItemIsEditable
    it.setFlags(flags)
    return it


def h(minutes: int) -> str:
    return hours_minutes(minutes)


def m(minutes: int) -> str:
    return str(minutes)


def yen(value: Decimal) -> str:
    return f"{value.quantize(Decimal('0.01')):,.2f}円"


def hours_and_yen(minutes: int, amount: Decimal) -> str:
    return f"{h(minutes)}\n{yen(amount)}"


class MonthlySheet(QWidget):
    def _scaled_pixmap(self, path, width: int, height: int) -> QPixmap:
        pixmap = QPixmap(str(path))
        if pixmap.isNull():
            return pixmap
        screen = QApplication.primaryScreen()
        device_ratio = screen.devicePixelRatio() if screen else 1.0
        scaled = pixmap.scaled(
            round(width * device_ratio),
            round(height * device_ratio),
            Qt.KeepAspectRatio,
            Qt.SmoothTransformation,
        )
        scaled.setDevicePixelRatio(device_ratio)
        return scaled

    def __init__(self) -> None:
        super().__init__()
        self.breaks_by_day: dict[int, list[BreakInterval]] = {}
        self.rows_by_day: dict[int, tuple[DailyInput, DailyResult]] = {}
        self._loading = False
        self.zoom_factor = 1.0
        screen = QApplication.primaryScreen()
        screen_width = screen.availableGeometry().width() if screen else 1600
        self.compact_layout = uses_compact_layout(screen_width)
        self.table_header_height = COMPACT_TABLE_HEADER_HEIGHT if self.compact_layout else TABLE_HEADER_HEIGHT
        layout = QVBoxLayout(self)
        outer_margin = 8 if self.compact_layout else 18
        layout.setContentsMargins(outer_margin, outer_margin, outer_margin, outer_margin)
        self.sheet = QWidget()
        self.sheet.setObjectName("sheet")
        self.sheet.setMinimumWidth(0)
        self.sheet.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.sheet.setStyleSheet(f"#sheet {{ background: white; border: 1px solid #c9d7e5; border-radius:8px; }}")
        sheet_shadow = QGraphicsDropShadowEffect(self.sheet)
        sheet_shadow.setBlurRadius(22)
        sheet_shadow.setColor(QColor(28, 55, 83, 36))
        sheet_shadow.setOffset(0, 5)
        self.sheet.setGraphicsEffect(sheet_shadow)
        layout.addWidget(self.sheet)
        grid = QGridLayout(self.sheet)
        grid.setContentsMargins(0, 0, 0, 10)
        grid.setSpacing(0)

        title_panel = QWidget()
        title_panel.setFixedHeight(72 if self.compact_layout else 92)
        title_panel.setStyleSheet("background:#ffffff; border:0px; border-top-left-radius:8px; border-top-right-radius:8px;")
        title_outer = QVBoxLayout(title_panel)
        title_outer.setContentsMargins(14 if self.compact_layout else 24, 6, 0, 6)
        title_outer.setSpacing(0)

        header_logo = QLabel()
        header_logo.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        logo_width, logo_height = ((150, 58) if self.compact_layout else (184, 76))
        header_logo.setFixedSize(logo_width, logo_height)
        pixmap = self._scaled_pixmap(OFFICIAL_HEADER_LOGO_PATH, logo_width - 8, logo_height)
        if not pixmap.isNull():
            header_logo.setPixmap(pixmap)
        title_outer.addWidget(header_logo, 0, Qt.AlignLeft | Qt.AlignVCenter)
        grid.addWidget(title_panel, 0, 0, 1, 16)

        self.name = QLineEdit()
        self.name.setAlignment(Qt.AlignCenter)
        self.name.setPlaceholderText("Worker name")
        self.record_month = MonthYearSelector()
        self.np_no = QLineEdit("4026")
        self.np_no.setAlignment(Qt.AlignCenter)
        self.np_no.setReadOnly(True)
        self.project = QLineEdit()
        self.project.setAlignment(Qt.AlignCenter)
        self.project.setPlaceholderText("Workplace or project")
        self.wage_label = QLineEdit()
        self.wage_label.setAlignment(Qt.AlignCenter)
        self.wage_label.setPlaceholderText("1,250.00円")
        self.standard_label = QLabel()
        self.ot_label = QLabel("25%; 50% after 60 hours")
        self.update_button = QPushButton("Check Updates")
        self.update_button.setVisible(False)
        self.release_button = QPushButton("New Update" if IS_USER_EDITION else "Release New Version")
        self.release_button.setMinimumHeight(42)
        self.release_button.setStyleSheet(
            "QPushButton { background:#0b4f8f; color:white; border:1px solid #083a69; "
            "border-radius:8px; padding:9px 12px; font-weight:800; }"
            "QPushButton:hover { background:#0a467f; }"
            "QPushButton:pressed { background:#07345f; }"
        )

        sidebar = QWidget()
        sidebar.setMinimumWidth(260 if self.compact_layout else 320)
        sidebar.setMaximumWidth(290 if self.compact_layout else 380)
        sidebar.setStyleSheet("background:transparent; border:0px;")
        sidebar_layout = QVBoxLayout(sidebar)
        sidebar_margin = 8 if self.compact_layout else 14
        sidebar_layout.setContentsMargins(sidebar_margin, sidebar_margin, sidebar_margin, sidebar_margin)
        sidebar_layout.setSpacing(10 if self.compact_layout else 14)

        details = QWidget()
        details.setObjectName("panelCard")
        panel_style = (
            "#panelCard { background:#fbfdff; border:1px solid #c8d9e8; "
            "border-top-left-radius:10px; border-top-right-radius:10px; "
            "border-bottom-left-radius:0px; border-bottom-right-radius:0px; }"
        )
        panel_title_style = (
            "background:#071f46; color:white; border:0px; border-bottom:1px solid #c8d9e8; "
            "border-top-left-radius:9px; border-top-right-radius:9px; "
            "border-bottom-left-radius:0px; border-bottom-right-radius:0px; padding:9px 10px; font-weight:800;"
        )
        panel_input_focus_style = (
            "QLineEdit, QDateEdit { background:#f2f8fd; border:0px; border-right:1px solid #c8d9e8; "
            "border-bottom:1px solid #c8d9e8; "
            "border-radius:0px; "
            "padding:7px 10px; color:#102033; }"
            "QLineEdit:focus, QDateEdit:focus { border-right:1px solid #2f80d0; "
            "border-bottom:2px solid #2f80d0; padding-bottom:6px; }"
            "QLineEdit:read-only { color:#48627d; background:#f2f8fd; }"
            "QDateEdit::drop-down { border:0; width:24px; background:#f2f8fd; }"
            "QDateEdit::down-arrow { width:10px; height:10px; }"
        )
        details.setStyleSheet(panel_style)
        details_grid = QGridLayout(details)
        details_grid.setContentsMargins(0, 0, 0, 0)
        details_grid.setHorizontalSpacing(0)
        details_grid.setVerticalSpacing(0)
        details_title = QLabel("Worker / Contract Details")
        details_title.setMinimumHeight(34)
        details_title.setAlignment(Qt.AlignCenter)
        details_title.setStyleSheet(panel_title_style)
        details_grid.addWidget(details_title, 0, 0, 1, 2)
        fields = [
            ("Name", self.name),
            ("Record Month", self.record_month),
            ("NP No.", self.np_no),
            ("Work / Project", self.project),
            ("Hourly Wage", self.wage_label),
            ("Standard Hrs", self.standard_label),
            ("Over Time Premium", self.ot_label),
        ]
        for idx, (label, widget) in enumerate(fields, 1):
            details_grid.addWidget(self.label(label), idx, 0)
            if isinstance(widget, QLabel):
                widget.setAlignment(Qt.AlignCenter)
                widget.setMinimumHeight(32)
                widget.setStyleSheet(
                    "background:#eef5fb; border:0px; border-right:1px solid #c5d9ea; "
                    "border-bottom:1px solid #c5d9ea; border-radius:0px; "
                    "padding:7px 10px; font-weight:800; color:#102033;"
                )
            elif isinstance(widget, MonthYearSelector):
                widget.setMinimumHeight(32)
                widget.apply_panel_style()
            else:
                widget.setMinimumHeight(32)
                widget.setStyleSheet(panel_input_focus_style)
            details_grid.addWidget(widget, idx, 1)
        details_grid.setColumnMinimumWidth(0, 112 if self.compact_layout else 132)
        details_grid.setColumnStretch(1, 1)

        guidance = QWidget()
        guidance.setStyleSheet("background:transparent;")
        guidance_layout = QVBoxLayout(guidance)
        guidance_layout.setContentsMargins(0, 0, 0, 0)
        guidance_layout.setSpacing(8)
        left = QLabel("Clock-in examples: 18:00, 19:00, 20:00, 21:30\nEnter actual clock-out and break minutes, then click Calculate on that row.")
        right = QLabel("Night Shift +25% from 22:00-05:00   Over Time +25%\nOvertime exceeding 60 hours/month = +50% total\nWeekend allowance: 50円 per paid weekend hour\nEmployer Leave 60%: estimated company-caused leave allowance")
        for widget in (left, right):
            widget.setWordWrap(True)
            widget.setMinimumHeight(72)
            widget.setStyleSheet(f"background:{LABEL_BLUE}; border:1px solid #c4d8ea; border-radius:8px; padding:10px 12px; font-size:9pt; color:#17324d;")
            guidance_layout.addWidget(widget)
        sidebar_layout.addWidget(details)

        self.summary_values: dict[str, QLabel] = {}
        summary_panel = QWidget()
        summary_panel.setObjectName("panelCard")
        summary_panel.setStyleSheet(panel_style)
        summary_grid = QGridLayout(summary_panel)
        summary_grid.setContentsMargins(0, 0, 0, 0)
        summary_grid.setHorizontalSpacing(0)
        summary_grid.setVerticalSpacing(0)
        summary_title = QLabel("Monthly Totals")
        summary_title.setMinimumHeight(34)
        summary_title.setAlignment(Qt.AlignCenter)
        summary_title.setStyleSheet(panel_title_style)
        summary_grid.addWidget(summary_title, 0, 0, 1, 2)
        summary = ["Total Worked", "Regular Hour", "Over Time +25%", "Night Shift +25%", "Holiday +35%", "Weekend +50円/hr", "Paid Leave", "Employer Leave 60%", "Workdays", "Estimated Pay Total"]
        summary_display = {
            "Paid Leave": "Paid Leave<br><span style='font-size:8pt; font-weight:600;'>(yūkyū)</span>",
            "Employer Leave 60%": "Employer Leave 60%<br><span style='font-size:8pt; font-weight:600;'>(kyūgyō)</span>",
        }
        for idx, label in enumerate(summary, 1):
            lab = self.label(summary_display.get(label, label))
            if label in summary_display:
                lab.setMinimumHeight(44)
            val = QLabel("0")
            val.setAlignment(Qt.AlignCenter)
            val.setMinimumHeight(36)
            val.setWordWrap(True)
            value_background = "#ddf7e8" if label == "Estimated Pay Total" else "#f2f8fd"
            value_border = "#9fd7b6" if label == "Estimated Pay Total" else "#c8d9e8"
            val.setStyleSheet(
                f"background:{value_background}; border:0px; border-bottom:1px solid {value_border}; "
                "border-right:1px solid #c8d9e8; border-radius:0px; "
                "padding:8px 10px; font-weight:800; color:#102033;"
            )
            self.summary_values[label] = val
            summary_grid.addWidget(lab, idx, 0)
            summary_grid.addWidget(val, idx, 1)
        summary_grid.setColumnMinimumWidth(0, 130 if self.compact_layout else 152)
        summary_grid.setColumnStretch(1, 1)
        sidebar_layout.addWidget(summary_panel)
        sidebar_layout.addWidget(self.release_button)
        sidebar_layout.addStretch(1)
        sidebar_layout.addWidget(guidance)
        grid.addWidget(sidebar, 1, 0, 4, 1)

        table_area = QWidget()
        table_area.setStyleSheet("background:transparent;")
        table_layout = QVBoxLayout(table_area)
        table_margin = 8 if self.compact_layout else 14
        table_layout.setContentsMargins(table_margin, table_margin, table_margin, table_margin)
        table_layout.setSpacing(0)

        self.table = QTableWidget(31, 16)
        if self.compact_layout:
            self.table.setStyleSheet("font-size:8pt;")
        self.table.setMinimumWidth(0)
        self.table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.table.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.table.setViewportMargins(TABLE_CORNER_INSET, 0, 0, TABLE_CORNER_INSET)
        self.table.setMouseTracking(True)
        self.table.viewport().setMouseTracking(True)
        self.table.verticalScrollBar().setObjectName("timesheetVerticalScroll")
        self.table.verticalScrollBar().setProperty("hoverActive", False)
        self.table.viewport().installEventFilter(self)
        self.table.installEventFilter(self)
        self.table.verticalScrollBar().installEventFilter(self)
        headers = ["Date", "Day", "Status", "Time In", "Time Out", "Break Min", "Total Worked Hours", "Regular Hour", "Over Time", "Night Shift", "Weekend", "Holiday", "Estimated Pay", "Notes", "Calculate", "Reset"]
        header_cell_count = len(headers)
        self.header_labels = [self._table_header_label(text, idx, header_cell_count) for idx, text in enumerate(headers)]
        self.header_row = QWidget()
        self.header_row.setFixedHeight(self.table_header_height)
        self.header_row.setStyleSheet("background:#135f9d; border-top-left-radius:10px; border-top-right-radius:10px;")
        for label_widget in self.header_labels:
            label_widget.setParent(self.header_row)
        self.table.setHorizontalHeaderLabels(headers)
        self.table.verticalHeader().setVisible(False)
        self.table.setShowGrid(True)
        self.table.setAlternatingRowColors(True)
        self.table.setCornerButtonEnabled(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setWordWrap(True)
        self.table.setItemDelegateForColumn(13, NotesPreviewDelegate(self.table))
        self.table.horizontalHeader().setVisible(False)
        self.table.horizontalScrollBar().valueChanged.connect(self._sync_table_header_to_grid)
        self.table.cellChanged.connect(self._cell_changed)
        self.table.cellDoubleClicked.connect(self._double_clicked)
        table_layout.addWidget(self.header_row)
        table_layout.addWidget(self.table)
        grid.addWidget(table_area, 1, 1, 4, 15)
        self._apply_table_dimensions()
        QTimer.singleShot(0, self._apply_table_dimensions)

        self.totals_label = QLabel()
        self.totals_label.setStyleSheet(f"background:{LABEL_BLUE}; border:1px solid {GRID}; padding:8px; font-weight:700; color:#102033;")
        self.personal_notes = QTextEdit()
        self.month_end_check = QTextEdit()
        self.personal_notes.setPlaceholderText("PERSONAL NOTES")
        self.month_end_check.setPlaceholderText("MONTH-END CHECK")
        self.personal_notes.setMinimumHeight(92)
        self.month_end_check.setMinimumHeight(92)
        self.warning_label = QLabel()
        self.warning_label.setStyleSheet("color:#b45309; font-weight:600; padding:4px;")
        grid.setColumnStretch(0, 0)
        grid.setColumnStretch(1, 1)

    def label(self, text: str) -> QLabel:
        lab = QLabel(text)
        lab.setAlignment(Qt.AlignCenter)
        lab.setMinimumHeight(32)
        lab.setWordWrap(True)
        lab.setStyleSheet(
            "background:#e8f3fd; border:0px; border-bottom:1px solid #c8d9e8; "
            "border-left:1px solid #c8d9e8; border-right:1px solid #b8cede; "
            "border-radius:0px; padding:8px 10px; font-weight:800; color:#0b3158;"
        )
        return lab

    def _table_header_label(self, text: str, idx: int, count: int) -> QLabel:
        lab = TableHeaderLabel(text, idx < count - 1)
        lab.setAlignment(Qt.AlignCenter)
        lab.setFixedHeight(self.table_header_height)
        lab.setWordWrap(True)
        radius_left = "border-top-left-radius:10px;" if idx == 0 else "border-top-left-radius:0px;"
        radius_right = "border-top-right-radius:10px;" if idx == count - 1 else "border-top-right-radius:0px;"
        lab.setStyleSheet(
            "background:#135f9d; color:white; border:0px; "
            f"{radius_left} {radius_right} padding:4px 3px; font-weight:800;"
            + (" font-size:7pt;" if self.compact_layout else "")
        )
        return lab

    def _apply_table_dimensions(self) -> None:
        available = max(1, self.table.viewport().width() - 2)
        widths = TABLE_BASE_WIDTHS.copy()
        status_max_width = 132
        if sum(widths) < available:
            widths[13] += available - sum(widths)
        elif widths[2] > status_max_width:
            widths[13] += widths[2] - status_max_width
            widths[2] = status_max_width
        for col, width in enumerate(widths):
            self.table.setColumnWidth(col, width)
        self._sync_table_header_to_grid()
        self.table.setMinimumHeight(790)

    def _sync_table_header_to_grid(self) -> None:
        if not hasattr(self, "header_labels"):
            return
        header_widths = [self.table.columnWidth(col) for col in range(len(self.header_labels))]
        if not header_widths:
            return
        self.header_row.setFixedWidth(self.table.width())
        left = self.table.viewport().x()
        for col, width in enumerate(header_widths):
            x = left + self.table.columnViewportPosition(col)
            if col == 0:
                width += max(0, x)
                x = min(0, x)
            elif col == len(header_widths) - 1:
                width = max(width, self.header_row.width() - x)
            self.header_labels[col].setGeometry(x, 0, width, self.header_row.height())

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        if hasattr(self, "table"):
            self._apply_table_dimensions()

    def _set_timesheet_scrollbar_hover(self, active: bool) -> None:
        bar = self.table.verticalScrollBar()
        if bar.property("hoverActive") == active:
            return
        bar.setProperty("hoverActive", active)
        bar.style().unpolish(bar)
        bar.style().polish(bar)
        bar.update()

    def eventFilter(self, watched, event) -> bool:
        if hasattr(self, "table"):
            if event.type() == QEvent.KeyPress and watched.property("timesheetRow") is not None:
                row = int(watched.property("timesheetRow"))
                col = int(watched.property("timesheetColumn"))
                if not (isinstance(watched, QComboBox) and watched.view().isVisible()):
                    if self._navigate_table_from_key(row, col, event.key()):
                        event.accept()
                        return True
            bar = self.table.verticalScrollBar()
            viewport = self.table.viewport()
            if watched is viewport:
                if event.type() == QEvent.MouseMove:
                    x = event.position().x() if hasattr(event, "position") else event.pos().x()
                    self._set_timesheet_scrollbar_hover(x >= viewport.width() - 4)
                elif event.type() == QEvent.Leave and not bar.underMouse():
                    self._set_timesheet_scrollbar_hover(False)
                elif event.type() == QEvent.Resize:
                    QTimer.singleShot(0, self._apply_table_dimensions)
            elif watched is self.table and event.type() == QEvent.Resize:
                QTimer.singleShot(0, self._apply_table_dimensions)
            elif watched is bar:
                if event.type() in (QEvent.Enter, QEvent.MouseMove):
                    self._set_timesheet_scrollbar_hover(True)
                elif event.type() == QEvent.Leave and not viewport.underMouse():
                    self._set_timesheet_scrollbar_hover(False)
        return super().eventFilter(watched, event)

    def _navigate_table_from_key(self, row: int, col: int, key: int) -> bool:
        row_delta = {
            Qt.Key_Up: -1,
            Qt.Key_Down: 1,
            Qt.Key_PageUp: -10,
            Qt.Key_PageDown: 10,
        }.get(key)
        if row_delta is not None:
            target_row = max(0, min(self.table.rowCount() - 1, row + row_delta))
            target_col = col
        elif key == Qt.Key_Home:
            target_row, target_col = 0, col
        elif key == Qt.Key_End:
            target_row, target_col = self.table.rowCount() - 1, col
        elif key == Qt.Key_Left:
            target_row, target_col = row, max(0, col - 1)
        elif key == Qt.Key_Right:
            target_row, target_col = row, min(self.table.columnCount() - 1, col + 1)
        else:
            return False

        self.table.setCurrentCell(target_row, target_col)
        target_item = self.table.item(target_row, target_col)
        if target_item is not None:
            self.table.scrollToItem(target_item, QAbstractItemView.PositionAtCenter)

        target_widget = self.table.cellWidget(target_row, target_col)
        if target_widget is not None:
            focus_widget = target_widget.findChild(QComboBox) or target_widget.findChild(QPushButton)
            if focus_widget is not None:
                focus_widget.setFocus(Qt.TabFocusReason)
                return True
        self.table.setFocus(Qt.TabFocusReason)
        return True

    def set_contract_display(self, settings) -> None:
        self.wage_label.setText(yen(settings.base_hourly_wage))
        self.standard_label.setText(str(settings.standard_daily_hours))

    def build_month(self, year: int, month: int, saved: list[DailyInput], settings) -> None:
        self._loading = True
        self.table.setRowCount(monthrange(year, month)[1])
        saved_by_day = {row.work_date.day: row for row in saved}
        self.breaks_by_day = {day: row.breaks for day, row in saved_by_day.items()}
        monthly_inputs: list[DailyInput] = []
        for day in range(1, monthrange(year, month)[1] + 1):
            work_date = date(year, month, day)
            row = saved_by_day.get(day, DailyInput(work_date))
            if row.status == "Employer Leave 60%":
                row.status = "Employer Leave"
            monthly_inputs.append(row)
            day_color = "#f8d7da" if work_date.weekday() == 6 else "#e8eef6" if work_date.weekday() == 5 else LABEL_BLUE
            self.table.setItem(day - 1, 0, item(work_date.strftime("%d-%b"), day_color))
            self.table.setItem(day - 1, 1, item(work_date.strftime("%a"), day_color))
            self._set_combo(day - 1, 2, STATUSES, row.status)
            self.table.setItem(day - 1, 3, item(row.actual_in.strftime("%H:%M") if row.actual_in else "", INPUT_YELLOW, True))
            self.table.setItem(day - 1, 4, item(row.actual_out.strftime("%H:%M") if row.actual_out else "", INPUT_YELLOW, True))
            self.table.setItem(day - 1, 5, item("", INPUT_YELLOW, True))
            note_cell = item(row.notes, INPUT_YELLOW, False, Qt.AlignLeft | Qt.AlignVCenter)
            self.table.setItem(day - 1, 13, note_cell)
            self._set_calculate_button(day - 1)
            self._set_reset_button(day - 1)
            self.table.setRowHeight(day - 1, 48)
        results, totals = summarize_month(monthly_inputs, settings)
        self.rows_by_day = {row.work_date.day: (row, result) for row, result in results}
        for day, (_row, result) in self.rows_by_day.items():
            self._write_calculated(day - 1, result, settings)
        self._write_totals(totals, settings)
        self._loading = False

    def _set_combo(self, row: int, col: int, values: list[str], current: str) -> None:
        combo = QComboBox()
        combo.setProperty("timesheetRow", row)
        combo.setProperty("timesheetColumn", col)
        combo.installEventFilter(self)
        combo.addItems(values)
        combo.setCurrentText(current)
        combo.setStyleSheet(
            "QComboBox { background:#eef5fb; color:#102033; border:1px solid #c5d9ea; "
            "border-radius:8px; padding:6px 1px 6px 6px; "
            + ("font-size:8pt;" if self.compact_layout else "")
            + " }"
            "QComboBox:hover { border-color:#4d8bc0; }"
            "QComboBox::drop-down { border:0; width:1px; }"
            "QComboBox QAbstractItemView { background:#ffffff; color:#102033; border:1px solid #8fb2d4; "
            "border-radius:6px; padding:4px; selection-background-color:#d7ecff; selection-color:#071a3d; }"
        )
        combo.view().setStyleSheet(
            "QListView { background:#ffffff; color:#102033; border:1px solid #8fb2d4; "
            "selection-background-color:#d7ecff; selection-color:#071a3d; outline:0; }"
            "QListView::item { min-height:26px; padding:5px 8px; }"
        )
        combo.currentTextChanged.connect(lambda _=None, r=row, c=col: self.combo_changed(r, c))
        if col == 2:
            combo.setMinimumWidth(0)
            combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
            holder = QWidget()
            holder.setStyleSheet("background: transparent;")
            holder_layout = QHBoxLayout(holder)
            holder_layout.setContentsMargins(3, 0, 3, 0)
            holder_layout.setSpacing(0)
            holder_layout.addWidget(combo)
            self.table.setCellWidget(row, col, holder)
            return
        self.table.setCellWidget(row, col, combo)

    def _set_calculate_button(self, row: int) -> None:
        button = QPushButton("Calculate")
        button.setProperty("timesheetRow", row)
        button.setProperty("timesheetColumn", 14)
        button.installEventFilter(self)
        button.setStyleSheet("background:#16803c; color:white; padding:5px 7px; border:0; border-radius:7px; font-weight:800;")
        button.clicked.connect(lambda _=False, r=row: self.calculate_row_clicked(r))
        self.table.setCellWidget(row, 14, button)

    def _set_reset_button(self, row: int) -> None:
        button = QPushButton("Reset")
        button.setProperty("timesheetRow", row)
        button.setProperty("timesheetColumn", 15)
        button.installEventFilter(self)
        button.setStyleSheet("background:#b91c1c; color:white; padding:5px 7px; border:0; border-radius:7px; font-weight:800;")
        button.clicked.connect(lambda _=False, r=row: self.reset_row_clicked(r))
        self.table.setCellWidget(row, 15, button)

    def calculate_row_clicked(self, row: int) -> None:
        window = self.window()
        if hasattr(window, "calculate_row"):
            window.calculate_row(row)

    def reset_row_clicked(self, row: int) -> None:
        window = self.window()
        if hasattr(window, "reset_row"):
            window.reset_row(row)

    def combo_changed(self, row: int, col: int) -> None:
        if self._loading:
            return
        window = self.window()
        if hasattr(window, "autosave_row"):
            window.autosave_row(row)

    def combo(self, row: int, col: int) -> str:
        combo = self.combo_widget(row, col)
        return combo.currentText() if combo else ""

    def combo_widget(self, row: int, col: int) -> QComboBox | None:
        widget = self.table.cellWidget(row, col)
        if isinstance(widget, QComboBox):
            return widget
        if widget:
            combo = widget.findChild(QComboBox)
            if isinstance(combo, QComboBox):
                return combo
        return None

    def parse_user_time(self, raw_text: str) -> time | None:
        text_value = raw_text.strip().upper().replace(" ", "")
        if not text_value:
            return None
        for fmt in ("%H:%M", "%H%M", "%I:%M%p", "%I%M%p", "%I%p"):
            try:
                return datetime.strptime(text_value, fmt).time().replace(second=0, microsecond=0)
            except ValueError:
                pass
        if ":" in text_value:
            hour_text, minute_text = text_value.split(":", 1)
            if hour_text.isdigit() and minute_text.isdigit():
                hour = int(hour_text)
                minute = int(minute_text)
                if 0 <= hour <= 23 and 0 <= minute <= 59:
                    return time(hour, minute)
        if text_value.isdigit():
            hour = int(text_value)
            if 0 <= hour <= 23:
                return time(hour, 0)
        raise ValueError(f"Invalid time: {raw_text}. Use 24-hour format like 20:30 or AM/PM like 8:30 PM.")

    def daily_input(self, year: int, month: int, day: int) -> DailyInput:

        def text(col: int) -> str:
            table_item = self.table.item(day - 1, col)
            return table_item.text() if table_item else ""

        break_hours = None
        if not self.breaks_by_day.get(day):
            try:
                raw = text(5).strip()
                break_hours = (Decimal(raw) / Decimal("60")) if raw else None
            except InvalidOperation:
                break_hours = None
        actual_in = self.parse_user_time(text(3))
        actual_out = self.parse_user_time(text(4))
        status = self.combo(day - 1, 2)
        if not status and (actual_in or actual_out):
            status = "Work"
        return DailyInput(
            work_date=date(year, month, day),
            status=status,
            schedule_ref="",
            actual_in=actual_in,
            actual_out=actual_out,
            breaks=self.breaks_by_day.get(day, []),
            total_break_hours=break_hours,
            notes=text(13),
        )

    def all_inputs(self, year: int, month: int) -> list[DailyInput]:
        return [self.daily_input(year, month, day) for day in range(1, self.table.rowCount() + 1)]

    def _money_for_minutes(self, minutes: int, hourly_rate: Decimal) -> Decimal:
        return Decimal(minutes) * hourly_rate / Decimal("60")

    def _overtime_pay_for_minutes(self, overtime_minutes: int, over_60_minutes: int, settings) -> Decimal:
        base_pay = self._money_for_minutes(overtime_minutes, settings.base_hourly_wage)
        overtime_premium = base_pay * settings.overtime_premium
        over_60_extra = self._money_for_minutes(over_60_minutes, settings.base_hourly_wage) * (settings.over_60_total_premium - settings.overtime_premium)
        return base_pay + overtime_premium + over_60_extra

    def _calculation_note(self, result: DailyResult) -> str:
        if result.employer_leave_allowance:
            return f"Employer Leave 60%={yen(result.employer_leave_allowance)} = {yen(result.total_pay_display)}"
        if result.paid_leave_pay:
            return f"Paid Leave={yen(result.paid_leave_pay)} = {yen(result.total_pay_display)}"
        if result.worked_minutes <= 0:
            return ""
        parts = [f"Base {h(result.worked_minutes)}={yen(result.base_pay)}"]
        if result.overtime_premium_pay:
            parts.append(f"Over Time +25%={yen(result.overtime_premium_pay)}")
        if result.over_60_extra_pay:
            parts.append(f"Over 60h extra={yen(result.over_60_extra_pay)}")
        if result.late_night_pay:
            parts.append(f"Night Shift +25%={yen(result.late_night_pay)}")
        if result.holiday_premium_pay:
            parts.append(f"Holiday +35%={yen(result.holiday_premium_pay)}")
        if result.saturday_allowance:
            parts.append(f"Weekend +50/hr={yen(result.saturday_allowance)}")
        return " + ".join(parts) + f" = {yen(result.total_pay_display)}"

    def _write_calculated(self, row: int, result: DailyResult, settings) -> None:
        regular_pay = self._money_for_minutes(result.regular_minutes, settings.base_hourly_wage)
        overtime_pay = self._money_for_minutes(result.overtime_minutes, settings.base_hourly_wage) + result.overtime_premium_pay + result.over_60_extra_pay
        values = [
            m(result.break_minutes),
            h(result.worked_minutes),
            hours_and_yen(result.regular_minutes, regular_pay),
            hours_and_yen(result.overtime_minutes, overtime_pay),
            hours_and_yen(result.late_night_minutes, result.late_night_pay),
            h(result.saturday_minutes),
            h(result.holiday_minutes),
            yen(result.total_pay_display),
        ]
        for col, value, color in zip([5, 6, 7, 8, 9, 10, 11, 12], values, [INPUT_YELLOW, CALC_BLUE, CALC_BLUE, CALC_BLUE, CALC_BLUE, CALC_BLUE, CALC_BLUE, SALARY_GREEN]):
            self.table.blockSignals(True)
            self.table.setItem(row, col, item(value, color, col == 5))
            self.table.blockSignals(False)
    def _write_totals(self, totals: MonthlyTotals, settings) -> None:
        self.summary_values["Total Worked"].setText(h(totals.worked_minutes))
        regular_pay = self._money_for_minutes(totals.regular_minutes, settings.base_hourly_wage)
        overtime_pay = self._overtime_pay_for_minutes(totals.overtime_minutes, totals.over_60_minutes, settings)
        late_night_pay = self._money_for_minutes(totals.late_night_minutes, settings.base_hourly_wage) * settings.late_night_premium
        self.summary_values["Regular Hour"].setText(hours_and_yen(totals.regular_minutes, regular_pay))
        self.summary_values["Over Time +25%"].setText(hours_and_yen(totals.overtime_minutes, overtime_pay))
        self.summary_values["Night Shift +25%"].setText(hours_and_yen(totals.late_night_minutes, late_night_pay))
        self.summary_values["Holiday +35%"].setText(h(totals.holiday_minutes))
        self.summary_values["Weekend +50円/hr"].setText(h(totals.saturday_minutes))
        if "Paid Leave" in self.summary_values:
            self.summary_values["Paid Leave"].setText(yen(totals.paid_leave_pay))
        if "Employer Leave 60%" in self.summary_values:
            self.summary_values["Employer Leave 60%"].setText(yen(totals.employer_leave_allowance))
        self.summary_values["Workdays"].setText(str(totals.workdays))
        self.summary_values["Estimated Pay Total"].setText(yen(totals.total_pay))
        self.totals_label.setText(
            f"MONTHLY TOTALS   Total Worked {h(totals.worked_minutes)}   Over Time {h(totals.overtime_minutes)}   "
            f"Night Shift {h(totals.late_night_minutes)}   Weekend {h(totals.saturday_minutes)}   Holiday {h(totals.holiday_minutes)}   "
            f"Estimated Monthly Salary {yen(totals.total_pay)}"
        )
        self.warning_label.setText("  ".join(totals.warnings))

    def _cell_changed(self, row: int, col: int) -> None:
        if self._loading:
            return
        if col in (3, 4, 5, 13):
            if col == 5:
                self.breaks_by_day.pop(row + 1, None)
            if col == 13:
                note_cell = self.table.item(row, col)
                if note_cell is not None:
                    self.table.viewport().update()
            window = self.window()
            if hasattr(window, "autosave_row"):
                window.autosave_row(row)
            return

    def _double_clicked(self, row: int, col: int) -> None:
        if col == 13:
            self._open_notes_editor(row)
            return
        window = self.window()
        if hasattr(window, "sheet_double_clicked"):
            window.sheet_double_clicked(row, col)

    def _open_notes_editor(self, row: int) -> None:
        cell = self.table.item(row, 13)
        if cell is None:
            cell = item("", INPUT_YELLOW, False, Qt.AlignLeft | Qt.AlignVCenter)
            self.table.setItem(row, 13, cell)

        dialog = QDialog(self)
        dialog.setWindowTitle(f"Notes - Day {row + 1}")
        dialog.setModal(True)
        dialog.resize(460, 300)
        dialog.setStyleSheet(
            """
            QDialog {
                background: #f8fbff;
            }
            QLabel {
                color: #002b55;
                font-weight: 700;
                font-size: 11pt;
            }
            QTextEdit {
                background: #ffffff;
                border: 1px solid #8fb0cc;
                border-radius: 8px;
                padding: 10px;
                selection-background-color: #1f6fb2;
                font-size: 11pt;
            }
            QPushButton {
                background: #155c99;
                color: white;
                border: 1px solid #0d4778;
                border-radius: 7px;
                padding: 8px 18px;
                font-weight: 700;
            }
            QPushButton:hover {
                background: #1c6fb7;
            }
            QPushButton:pressed {
                background: #0d4778;
            }
            """
        )

        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(10)

        title = QLabel("Notes")
        editor = QTextEdit()
        editor.setPlaceholderText("Write your note here...")
        editor.setPlainText(cell.text())
        editor.setFocus()

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)

        layout.addWidget(title)
        layout.addWidget(editor)
        layout.addWidget(buttons)

        if dialog.exec():
            note_text = editor.toPlainText().strip()
            cell.setText(note_text)
            self.table.viewport().update()
