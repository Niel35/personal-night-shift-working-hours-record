import sys

from PySide6.QtCore import QEvent, Qt
from PySide6.QtGui import QKeyEvent
from PySide6.QtWidgets import QApplication

from app.monthly_sheet import COMPACT_SCREEN_MAX_WIDTH, TABLE_BASE_WIDTHS, MonthlySheet, uses_compact_layout


def test_macbook_logical_widths_use_compact_layout():
    assert uses_compact_layout(1280)
    assert uses_compact_layout(1440)
    assert uses_compact_layout(1512)
    assert uses_compact_layout(1600)


def test_large_desktop_keeps_standard_layout():
    assert not uses_compact_layout(COMPACT_SCREEN_MAX_WIDTH + 1)
    assert not uses_compact_layout(1920)


def test_compact_table_keeps_readable_column_widths_and_scrolls():
    app = QApplication.instance() or QApplication(sys.argv)
    sheet = MonthlySheet()
    sheet.resize(1100, 800)
    sheet.show()
    app.processEvents()
    sheet._apply_table_dimensions()

    widths = [sheet.table.columnWidth(col) for col in range(sheet.table.columnCount())]
    assert widths == TABLE_BASE_WIDTHS
    assert sum(widths) > sheet.table.viewport().width()
    assert sheet.table.horizontalScrollBar().maximum() == sum(widths) - sheet.table.viewport().width()
    assert widths[1] >= 50
    assert widths[14] >= 102
    assert widths[15] >= 80


def test_arrow_keys_move_between_status_rows():
    app = QApplication.instance() or QApplication(sys.argv)
    sheet = MonthlySheet()
    sheet.show()
    sheet._set_combo(0, 2, ["", "Work", "Employer Leave"], "Work")
    sheet._set_combo(1, 2, ["", "Work", "Employer Leave"], "Employer Leave")
    first_combo = sheet.combo_widget(0, 2)
    second_combo = sheet.combo_widget(1, 2)
    assert first_combo is not None
    assert second_combo is not None

    first_combo.setFocus()
    app.processEvents()
    QApplication.sendEvent(first_combo, QKeyEvent(QEvent.KeyPress, Qt.Key_Down, Qt.NoModifier))
    app.processEvents()

    assert sheet.table.currentRow() == 1
    assert sheet.table.currentColumn() == 2
    assert second_combo.hasFocus()
