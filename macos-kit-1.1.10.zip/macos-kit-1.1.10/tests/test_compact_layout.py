import sys

import app.monthly_sheet as monthly_sheet
from PySide6.QtCore import QEvent, QPoint, Qt
from PySide6.QtGui import QKeyEvent
from PySide6.QtWidgets import QApplication, QLabel, QPushButton

from app.main_window import MainWindow
from app.monthly_sheet import (
    COMPACT_SCREEN_MAX_WIDTH,
    COMPACT_TABLE_WIDTHS,
    TARGET_DISPLAY_HEIGHT_MM,
    TARGET_DISPLAY_HEIGHT_RATIO,
    TARGET_DISPLAY_WIDTH_MM,
    TARGET_CONTROL_SIDE_GAP,
    TARGET_STATUS_COLUMN_WIDTH,
    TARGET_TABLE_ROW_HEIGHT,
    MonthlySheet,
    is_target_display,
    uses_compact_layout,
)
from database.database import TimesheetDatabase


def test_macbook_logical_widths_use_compact_layout():
    assert uses_compact_layout(1280)
    assert uses_compact_layout(1440)
    assert uses_compact_layout(1512)
    assert uses_compact_layout(1600)


def test_large_desktop_keeps_standard_layout():
    assert not uses_compact_layout(COMPACT_SCREEN_MAX_WIDTH + 1)
    assert not uses_compact_layout(1920)


def test_301_by_195_mm_display_uses_dedicated_compact_profile():
    assert TARGET_DISPLAY_HEIGHT_RATIO == 0.6478
    assert round(TARGET_DISPLAY_HEIGHT_MM, 4) == 194.9878
    assert TARGET_DISPLAY_HEIGHT_MM == TARGET_DISPLAY_WIDTH_MM * TARGET_DISPLAY_HEIGHT_RATIO
    assert is_target_display(301, 195)
    assert is_target_display(195, 301)
    assert uses_compact_layout(1800, 301, 195)
    assert not is_target_display(345, 215)


def test_compact_table_keeps_readable_column_widths_and_scrolls():
    app = QApplication.instance() or QApplication(sys.argv)
    sheet = MonthlySheet()
    sheet.resize(1100, 800)
    sheet.show()
    app.processEvents()
    sheet._apply_table_dimensions()

    widths = [sheet.table.columnWidth(col) for col in range(sheet.table.columnCount())]
    assert widths == COMPACT_TABLE_WIDTHS
    assert sum(widths) > sheet.table.viewport().width()
    assert sheet.table.horizontalScrollBar().maximum() == sum(widths) - sheet.table.viewport().width()
    assert widths[2] >= 96
    assert widths[14] >= 76
    assert widths[15] >= 58


def test_fourteen_inch_macbook_fits_all_columns_without_horizontal_scroll():
    app = QApplication.instance() or QApplication(sys.argv)
    sheet = MonthlySheet()
    sheet.resize(1512, 900)
    sheet.show()
    app.processEvents()
    sheet._apply_table_dimensions()
    app.processEvents()

    assert sheet.table.viewport().width() >= sum(COMPACT_TABLE_WIDTHS)
    assert sheet.table.horizontalScrollBar().maximum() == 0


def test_target_display_shows_complete_app_without_scrollbars(monkeypatch, tmp_path):
    monkeypatch.setattr(monthly_sheet, "is_target_display", lambda *_args: True)
    monkeypatch.setattr(monthly_sheet, "uses_compact_layout", lambda *_args: True)
    app = QApplication.instance() or QApplication(sys.argv)
    window = MainWindow(TimesheetDatabase(tmp_path / "full-screen.db"))
    window.resize(1512, round(1512 * TARGET_DISPLAY_HEIGHT_RATIO))
    window.show()
    app.processEvents()

    assert window.sheet.target_display
    assert not window.statusBar().isVisible()
    assert window.scroll.verticalScrollBarPolicy() == Qt.ScrollBarAlwaysOff
    assert window.sheet.table.verticalScrollBarPolicy() == Qt.ScrollBarAlwaysOff
    assert window.scroll.verticalScrollBar().maximum() == 0
    assert window.sheet.table.verticalScrollBar().maximum() == 0
    assert window.sheet.table.columnWidth(2) == TARGET_STATUS_COLUMN_WIDTH
    assert window.sheet.release_button.text() == "New Update"
    total_worked_header = window.sheet.header_labels[6]
    assert total_worked_header.text() == "Total Worked Hours"
    assert not total_worked_header.wordWrap()
    details_title = next(
        label
        for label in window.sheet.findChildren(QLabel)
        if label.text() == "Worker / Contract Details"
    )
    summary_title = next(
        label
        for label in window.sheet.findChildren(QLabel)
        if label.text() == "Monthly Totals"
    )
    details_panel = details_title.parentWidget()
    summary_panel = summary_title.parentWidget()
    panel_gap = summary_panel.geometry().top() - details_panel.geometry().bottom() - 1
    assert abs(panel_gap - window.sheet.details_summary_gap_px) <= 1
    assert 24 <= panel_gap <= 26
    assert window.sheet.header_row.height() == details_title.height()
    status_combo = window.sheet.combo_widget(0, 2)
    assert status_combo is not None
    status_holder = status_combo.parentWidget()
    left_gap = status_combo.geometry().left()
    right_gap = status_holder.width() - status_combo.geometry().right() - 1
    top_gap = status_combo.geometry().top()
    bottom_gap = status_holder.height() - status_combo.geometry().bottom() - 1
    assert abs(left_gap - right_gap) <= 1
    assert abs(top_gap - bottom_gap) <= 1
    assert abs(left_gap - TARGET_CONTROL_SIDE_GAP) <= 1
    assert abs(right_gap - TARGET_CONTROL_SIDE_GAP) <= 1
    assert abs(top_gap - TARGET_CONTROL_SIDE_GAP) <= 1
    assert abs(bottom_gap - TARGET_CONTROL_SIDE_GAP) <= 1
    assert status_combo.width() == status_holder.width() - left_gap - right_gap
    for column in (14, 15):
        action_holder = window.sheet.table.cellWidget(0, column)
        action_button = action_holder.findChild(QPushButton)
        assert action_button is not None
        action_left_gap = action_button.geometry().left()
        action_right_gap = action_holder.width() - action_button.geometry().right() - 1
        action_top_gap = action_button.geometry().top()
        action_bottom_gap = action_holder.height() - action_button.geometry().bottom() - 1
        assert abs(action_left_gap - action_right_gap) <= 1
        assert abs(action_top_gap - action_bottom_gap) <= 1
        assert abs(action_left_gap - TARGET_CONTROL_SIDE_GAP) <= 1
        assert abs(action_right_gap - TARGET_CONTROL_SIDE_GAP) <= 1
        assert abs(action_top_gap - TARGET_CONTROL_SIDE_GAP) <= 1
        assert abs(action_bottom_gap - TARGET_CONTROL_SIDE_GAP) <= 1
    details_top = details_title.mapTo(window.sheet, QPoint(0, 0)).y()
    table_top = window.sheet.header_row.mapTo(window.sheet, QPoint(0, 0)).y()
    assert details_top == table_top
    row_heights = [
        window.sheet.table.rowHeight(row)
        for row in range(window.sheet.table.rowCount())
    ]
    assert min(row_heights) >= TARGET_TABLE_ROW_HEIGHT
    assert abs(sum(row_heights) - window.sheet.table.viewport().height()) <= 1
    window.close()


def test_arrow_keys_move_between_status_rows():
    app = QApplication.instance() or QApplication(sys.argv)
    sheet = MonthlySheet()
    sheet.show()
    sheet._set_combo(0, 2, ["", "Work", "Employer Leave"], "Work")
    sheet._set_combo(1, 2, ["", "Work", "Employer Leave"], "Employer Leave")
    first_combo = sheet.combo_widget(0, 2)
    second_combo = sheet.combo_widget(1, 2)
    assert first_combo is not None
    assert second_combo is not None

    first_combo.setFocus()
    app.processEvents()
    QApplication.sendEvent(first_combo, QKeyEvent(QEvent.KeyPress, Qt.Key_Down, Qt.NoModifier))
    app.processEvents()

    assert sheet.table.currentRow() == 1
    assert sheet.table.currentColumn() == 2
    assert second_combo.hasFocus()
