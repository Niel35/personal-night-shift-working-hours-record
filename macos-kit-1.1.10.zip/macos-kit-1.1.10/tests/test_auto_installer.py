from pathlib import Path

import zipfile

import pytest

from app.updater import (
    UpdateError,
    create_macos_installer_script,
    create_windows_installer_script,
    validate_update_archive,
)


def test_windows_installer_script_replaces_and_relaunches(tmp_path: Path) -> None:
    update = tmp_path / "update.zip"
    install_dir = tmp_path / "install"
    exe = install_dir / "PersonalNightShiftWorkingHoursRecord.exe"
    install_dir.mkdir()
    update.write_text("zip", encoding="utf-8")
    exe.write_text("exe", encoding="utf-8")

    script = create_windows_installer_script(update, install_dir, exe, 12345, "1.1.6")
    text = script.read_text(encoding="utf-8")

    assert "Expand-Archive" in text
    assert "robocopy $sourceDir $installDir /MIR" in text
    assert "$backupDir" in text
    assert "Move-Item -LiteralPath $backupDir -Destination $installDir" in text
    assert "Start-Process -FilePath $relaunchPath" in text


def test_macos_installer_script_replaces_and_reopens_app(tmp_path: Path) -> None:
    update = tmp_path / "update.zip"
    app = tmp_path / "Personal Night-Shift Working Hours Record.app"
    update.write_text("zip", encoding="utf-8")

    script = create_macos_installer_script(update, app, 12345, "1.1.6")
    text = script.read_text(encoding="utf-8")

    assert "/usr/bin/ditto -x -k" in text
    assert 'mv "$app_path" "$backup_app"' in text
    assert 'mv "$staged_app" "$app_path"' in text
    assert "Update failed; restoring the previous app." in text
    assert "CFBundleShortVersionString" in text
    assert '/usr/bin/open "$app_path"' in text


def test_validate_update_archive_accepts_safe_zip(tmp_path: Path) -> None:
    update = tmp_path / "update.zip"
    with zipfile.ZipFile(update, "w") as archive:
        archive.writestr("Personal App.app/Contents/MacOS/App", "binary")

    assert validate_update_archive(update) == len("binary")


def test_validate_update_archive_rejects_invalid_zip(tmp_path: Path) -> None:
    update = tmp_path / "update.zip"
    update.write_text("not a zip", encoding="utf-8")

    with pytest.raises(UpdateError, match="valid ZIP"):
        validate_update_archive(update)


def test_validate_update_archive_rejects_path_traversal(tmp_path: Path) -> None:
    update = tmp_path / "update.zip"
    with zipfile.ZipFile(update, "w") as archive:
        archive.writestr("../outside.txt", "unsafe")

    with pytest.raises(UpdateError, match="unsafe file path"):
        validate_update_archive(update)
