from __future__ import annotations

from calendar import monthrange
from datetime import date
from decimal import Decimal
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from calculations.models import ContractSettings, DailyInput, DailyResult, MonthlyTotals
from calculations.formatting import hours_minutes

NAVY = "102033"
HEADER = "5B9BD5"
LABEL = "DDEBF7"
INPUT = "FFF2CC"
CALC = "DDEBF7"
SALARY = "E2F0D9"
GRID = "8EA9C1"


def h(minutes: int) -> str:
    return hours_minutes(minutes)


def yen(value: Decimal) -> str:
    return f"{value.quantize(Decimal('0.01')):,.2f} 円"


def money_for_minutes(minutes: int, hourly_rate: Decimal) -> Decimal:
    return Decimal(minutes) * hourly_rate / Decimal("60")


def overtime_pay_for_minutes(overtime_minutes: int, over_60_minutes: int, settings: ContractSettings) -> Decimal:
    base_pay = money_for_minutes(overtime_minutes, settings.base_hourly_wage)
    overtime_premium = base_pay * settings.overtime_premium
    over_60_extra = money_for_minutes(over_60_minutes, settings.base_hourly_wage) * (settings.over_60_total_premium - settings.overtime_premium)
    return base_pay + overtime_premium + over_60_extra


def hours_and_yen(minutes: int, amount: Decimal) -> str:
    return f"{h(minutes)}\n{yen(amount)}"


def export_month_excel(
    path: str | Path,
    year: int,
    month: int,
    rows_by_day: dict[int, tuple[DailyInput, DailyResult]],
    totals: MonthlyTotals,
    settings: ContractSettings,
    notes: dict[str, str],
) -> Path:
    target = Path(path)
    wb = Workbook()
    ws = wb.active
    ws.title = "A4 Timesheet"
    ws.merge_cells("A1:N1")
    ws["A1"] = "PERSONAL NIGHT-SHIFT WORKING HOURS RECORD"
    ws["A1"].font = Font(color="FFFFFF", bold=True, size=16)
    ws["A1"].fill = PatternFill("solid", fgColor=NAVY)
    ws["A1"].alignment = Alignment(horizontal="center")

    info = [("Name", notes.get("name", "")), ("Record Month", f"{year}-{month:02d}"), ("NP No.", notes.get("np_no", "4026")), ("Work / Project", notes.get("work_project", ""))]
    col = 1
    for label, value in info:
        ws.cell(2, col, label)
        ws.cell(2, col + 1, value)
        ws.cell(2, col).fill = PatternFill("solid", fgColor=LABEL)
        ws.cell(2, col + 1).fill = PatternFill("solid", fgColor=INPUT)
        col += 4
    contract = [("Hourly Wage", yen(settings.base_hourly_wage)), ("Standard Hrs", str(settings.standard_daily_hours)), ("OT Premium", "25%; 50% after 60h")]
    col = 1
    for label, value in contract:
        ws.cell(3, col, label)
        ws.cell(3, col + 1, value)
        ws.cell(3, col).fill = PatternFill("solid", fgColor=LABEL)
        ws.cell(3, col + 1).fill = PatternFill("solid", fgColor=INPUT)
        col += 5
    ws.merge_cells("A4:G4")
    ws["A4"] = "ENTER THE ACTUAL CLOCK-IN: 18:00, 19:00, 20:00, 21:30, etc. Enter the actual clock-out and actual break for that day."
    ws.merge_cells("H4:O4")
    ws["H4"] = "Night +25% 22:00-05:00. OT +25%. Over 60h/month = +50% total. Weekend allowance 50円 per paid weekend hour."
    for cell in ws[4]:
        cell.fill = PatternFill("solid", fgColor=LABEL)

    regular_total_pay = money_for_minutes(totals.regular_minutes, settings.base_hourly_wage)
    overtime_total_pay = overtime_pay_for_minutes(totals.overtime_minutes, totals.over_60_minutes, settings)
    late_night_total_pay = money_for_minutes(totals.late_night_minutes, settings.base_hourly_wage) * settings.late_night_premium
    summary = [
        ("Total Worked", h(totals.worked_minutes)), ("Regular", hours_and_yen(totals.regular_minutes, regular_total_pay)), ("OT +25%", hours_and_yen(totals.overtime_minutes, overtime_total_pay)),
        ("Night +25%", hours_and_yen(totals.late_night_minutes, late_night_total_pay)), ("Holiday +35%", h(totals.holiday_minutes)),
        ("Weekend +50円/hr", h(totals.saturday_minutes)), ("Workdays", totals.workdays), ("Estimated Pay", yen(totals.total_pay)),
    ]
    for idx, (label, value) in enumerate(summary):
        cell = ws.cell(5, idx * 2 + 1, label)
        value_cell = ws.cell(5, idx * 2 + 2, value)
        cell.fill = PatternFill("solid", fgColor=LABEL)
        value_cell.fill = PatternFill("solid", fgColor=SALARY if label == "Estimated Pay" else CALC)

    headers = ["Date", "Day", "Status", "Actual In", "Actual Out", "Break Min", "Total Worked Hours", "Regular", "OT", "Night", "Weekend", "Holiday", "Estimated Pay", "Notes"]
    for c, header in enumerate(headers, 1):
        cell = ws.cell(7, c, header)
        cell.value = header
        cell.font = Font(color="FFFFFF", bold=True)
        cell.fill = PatternFill("solid", fgColor=HEADER)
        cell.alignment = Alignment(horizontal="center")
    row_num = 8
    for day in range(1, monthrange(year, month)[1] + 1):
        work_date = date(year, month, day)
        row, result = rows_by_day.get(day, (DailyInput(work_date), DailyResult()))
        regular_pay = money_for_minutes(result.regular_minutes, settings.base_hourly_wage)
        overtime_pay = money_for_minutes(result.overtime_minutes, settings.base_hourly_wage) + result.overtime_premium_pay + result.over_60_extra_pay
        values = [
            work_date.strftime("%d-%b"), work_date.strftime("%a"), row.status,
            row.actual_in.strftime("%H:%M") if row.actual_in else "", row.actual_out.strftime("%H:%M") if row.actual_out else "",
            result.break_minutes, h(result.worked_minutes), hours_and_yen(result.regular_minutes, regular_pay),
            hours_and_yen(result.overtime_minutes, overtime_pay), hours_and_yen(result.late_night_minutes, result.late_night_pay),
            h(result.saturday_minutes), h(result.holiday_minutes), yen(result.total_pay_display), row.notes,
        ]
        for c, value in enumerate(values, 1):
            cell = ws.cell(row_num, c, value)
            if c in (3, 4, 5, 6, 14):
                cell.fill = PatternFill("solid", fgColor=INPUT)
            elif c == 13:
                cell.fill = PatternFill("solid", fgColor=SALARY)
            elif c in (7, 8, 9, 10, 11, 12):
                cell.fill = PatternFill("solid", fgColor=CALC)
        ws.row_dimensions[row_num].height = 32
        row_num += 1
    ws.cell(row_num, 1, "MONTHLY TOTALS").fill = PatternFill("solid", fgColor=LABEL)
    for c, value in enumerate(["", "", "", "", "", "", h(totals.worked_minutes), hours_and_yen(totals.regular_minutes, regular_total_pay), hours_and_yen(totals.overtime_minutes, overtime_total_pay), hours_and_yen(totals.late_night_minutes, late_night_total_pay), h(totals.saturday_minutes), h(totals.holiday_minutes), yen(totals.total_pay), ""], 1):
        ws.cell(row_num, c, value)
        ws.cell(row_num, c).fill = PatternFill("solid", fgColor=SALARY if c == 13 else LABEL)
    ws.row_dimensions[row_num].height = 32

    row_num += 2
    ws.merge_cells(start_row=row_num, start_column=1, end_row=row_num + 3, end_column=7)
    ws.cell(row_num, 1, "PERSONAL NOTES\n" + notes.get("personal_notes", ""))
    ws.merge_cells(start_row=row_num, start_column=8, end_row=row_num + 3, end_column=14)
    ws.cell(row_num, 8, "MONTH-END CHECK\n" + notes.get("month_end_check", ""))

    thin = Side(style="thin", color=GRID)
    for row_cells in ws.iter_rows(min_row=1, max_row=row_num + 3, min_col=1, max_col=14):
        for cell in row_cells:
            cell.border = Border(left=thin, right=thin, top=thin, bottom=thin)
            cell.alignment = Alignment(vertical="center", wrap_text=True)
    widths = [10, 8, 13, 10, 10, 8, 16, 9, 8, 8, 8, 9, 14, 22]
    for idx, width in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(idx)].width = width
    ws.page_setup.orientation = "landscape"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 1
    wb.save(target)
    return target
