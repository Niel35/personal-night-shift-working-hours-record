from __future__ import annotations

from calendar import monthrange
from datetime import date
from decimal import Decimal
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from calculations.models import ContractSettings, DailyInput, DailyResult, MonthlyTotals
from calculations.formatting import hours_minutes

PDF_FONT = "HeiseiKakuGo-W5"
pdfmetrics.registerFont(UnicodeCIDFont(PDF_FONT))


def h(minutes: int) -> str:
    return hours_minutes(minutes)


def yen(value: Decimal) -> str:
    return f"{value.quantize(Decimal('0.01')):,.2f} 円"


def money_for_minutes(minutes: int, hourly_rate: Decimal) -> Decimal:
    return Decimal(minutes) * hourly_rate / Decimal("60")


def overtime_pay_for_minutes(overtime_minutes: int, over_60_minutes: int, settings: ContractSettings) -> Decimal:
    base_pay = money_for_minutes(overtime_minutes, settings.base_hourly_wage)
    overtime_premium = base_pay * settings.overtime_premium
    over_60_extra = money_for_minutes(over_60_minutes, settings.base_hourly_wage) * (settings.over_60_total_premium - settings.overtime_premium)
    return base_pay + overtime_premium + over_60_extra


def hours_and_yen(minutes: int, amount: Decimal) -> str:
    return f"{h(minutes)}\n{yen(amount)}"


def export_month_pdf(
    path: str | Path,
    year: int,
    month: int,
    rows_by_day: dict[int, tuple[DailyInput, DailyResult]],
    totals: MonthlyTotals,
    settings: ContractSettings,
    notes: dict[str, str],
) -> Path:
    target = Path(path)
    doc = SimpleDocTemplate(str(target), pagesize=landscape(A4), leftMargin=12, rightMargin=12, topMargin=10, bottomMargin=10)
    styles = getSampleStyleSheet()
    story = []
    title = Table([["PERSONAL NIGHT-SHIFT WORKING HOURS RECORD"]], colWidths=[810])
    title.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#102033")), ("TEXTCOLOR", (0, 0), (-1, -1), colors.white), ("ALIGN", (0, 0), (-1, -1), "CENTER"), ("FONTNAME", (0, 0), (-1, -1), PDF_FONT), ("FONTSIZE", (0, 0), (-1, -1), 15)]))
    story.append(title)
    info = [["Name", notes.get("name", ""), "Record Month", f"{year}-{month:02d}", "NP No.", notes.get("np_no", "4026"), "Work / Project", notes.get("work_project", "")]]
    story.append(Table(info, colWidths=[50, 120, 85, 80, 55, 60, 95, 265]))
    story.append(Table([["Hourly Wage", yen(settings.base_hourly_wage), "Standard Hrs", str(settings.standard_daily_hours), "OT Premium", "25%; 50% after 60 hours"]], colWidths=[75, 90, 85, 55, 75, 430]))
    story.append(Table([["ENTER THE ACTUAL CLOCK-IN: 18:00, 19:00, 20:00, 21:30, etc. Enter actual clock-out and break.", "Night +25% 22:00-05:00. OT +25%. Over 60h/month = +50% total. Weekend allowance 50円/hr."]], colWidths=[405, 405]))
    regular_total_pay = money_for_minutes(totals.regular_minutes, settings.base_hourly_wage)
    overtime_total_pay = overtime_pay_for_minutes(totals.overtime_minutes, totals.over_60_minutes, settings)
    late_night_total_pay = money_for_minutes(totals.late_night_minutes, settings.base_hourly_wage) * settings.late_night_premium
    story.append(Table([["Total Worked", h(totals.worked_minutes), "Regular", hours_and_yen(totals.regular_minutes, regular_total_pay), "OT +25%", hours_and_yen(totals.overtime_minutes, overtime_total_pay), "Night +25%", hours_and_yen(totals.late_night_minutes, late_night_total_pay), "Holiday +35%", h(totals.holiday_minutes), "Weekend +50円/hr", h(totals.saturday_minutes), "Workdays", totals.workdays, "Estimated Pay", yen(totals.total_pay)]], colWidths=[58, 45, 45, 45, 50, 45, 60, 45, 65, 45, 75, 45, 55, 35, 75, 67]))
    data = [["Date", "Day", "Status", "In", "Out", "Break Min", "Total Worked", "Regular", "OT", "Night", "Weekend", "Holiday", "Estimated Pay", "Notes"]]
    for day in range(1, monthrange(year, month)[1] + 1):
        work_date = date(year, month, day)
        row, result = rows_by_day.get(day, (DailyInput(work_date), DailyResult()))
        regular_pay = money_for_minutes(result.regular_minutes, settings.base_hourly_wage)
        overtime_pay = money_for_minutes(result.overtime_minutes, settings.base_hourly_wage) + result.overtime_premium_pay + result.over_60_extra_pay
        data.append([
            work_date.strftime("%d-%b"), work_date.strftime("%a"), row.status,
            row.actual_in.strftime("%H:%M") if row.actual_in else "", row.actual_out.strftime("%H:%M") if row.actual_out else "",
            str(result.break_minutes), h(result.worked_minutes), hours_and_yen(result.regular_minutes, regular_pay),
            hours_and_yen(result.overtime_minutes, overtime_pay), hours_and_yen(result.late_night_minutes, result.late_night_pay),
            h(result.saturday_minutes), h(result.holiday_minutes), yen(result.total_pay_display), row.notes[:24],
        ])
    data.append(["MONTHLY TOTALS", "", "", "", "", "", h(totals.worked_minutes), hours_and_yen(totals.regular_minutes, regular_total_pay), hours_and_yen(totals.overtime_minutes, overtime_total_pay), hours_and_yen(totals.late_night_minutes, late_night_total_pay), h(totals.saturday_minutes), h(totals.holiday_minutes), yen(totals.total_pay), ""])
    table = Table(data, repeatRows=1, colWidths=[45, 33, 55, 37, 37, 38, 42, 42, 34, 37, 33, 45, 70, 222])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#5B9BD5")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, -1), PDF_FONT),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#8EA9C1")),
        ("FONTSIZE", (0, 0), (-1, -1), 6.7),
        ("BACKGROUND", (2, 1), (5, -2), colors.HexColor("#FFF2CC")),
        ("BACKGROUND", (6, 1), (11, -1), colors.HexColor("#DDEBF7")),
        ("BACKGROUND", (12, 1), (12, -1), colors.HexColor("#E2F0D9")),
        ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#DDEBF7")),
    ]))
    story.append(table)
    notes_table = Table([["PERSONAL NOTES", "MONTH-END CHECK"], [notes.get("personal_notes", ""), notes.get("month_end_check", "")], ["Personal estimate only. Official company attendance records and payslips control final salary.", ""]], colWidths=[405, 405])
    notes_table.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#8EA9C1")), ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#DDEBF7")), ("FONTNAME", (0, 0), (-1, -1), PDF_FONT), ("FONTSIZE", (0, 0), (-1, -1), 7)]))
    story.append(Spacer(1, 4))
    story.append(notes_table)
    for flowable in story[1:4]:
        flowable.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#8EA9C1")), ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#DDEBF7")), ("FONTNAME", (0, 0), (-1, -1), PDF_FONT), ("FONTSIZE", (0, 0), (-1, -1), 7)]))
    doc.build(story)
    return target
