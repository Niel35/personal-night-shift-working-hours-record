# -*- mode: python ; coding: utf-8 -*-

from app.app_info import APP_VERSION

a = Analysis(
    ["main.py"],
    pathex=[],
    binaries=[],
    datas=[("resources", "resources"), ("sample_data", "sample_data")],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="PersonalNightShiftWorkingHoursRecord",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    icon="resources/official_app_icon.icns",
    disable_windowed_traceback=False,
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="PersonalNightShiftWorkingHoursRecord",
)
app = BUNDLE(
    coll,
    name="Personal Night-Shift Working Hours Record.app",
    icon="resources/official_app_icon.icns",
    bundle_identifier="com.personalnightshift.workinghoursrecord",
    info_plist={
        "CFBundleDisplayName": "Personal Night-Shift Working Hours Record",
        "CFBundleName": "Personal Night-Shift Working Hours Record",
        "CFBundleShortVersionString": APP_VERSION,
        "CFBundleVersion": APP_VERSION,
        "NSHighResolutionCapable": True,
    },
)
